uiv.factory('uiViewerDatasource', [
    'ViewerImageLoader',
    'ViewerImageStore',
    'ViewerDocumentStore',
    'ViewerThumbStore',
    'ViewerModel',
    '$q',
    'ViewerEvents',
    'ViewerNotification',
    'ViewerSettingService',
    'ViewerSetting',
    '$timeout',
    'viewerConst',
    'ViewerAnnotationStore',
    'ViewerCommentStore',
    'pageDirectiveElementStore',
    function(ViewerImageLoader, ViewerImageStore, ViewerDocumentStore, ViewerThumbStore, ViewerModel, $q, ViewerEvents, ViewerNotification, ViewerSettingService, ViewerSetting, $timeout, viewerConst, ViewerAnnotationStore, ViewerCommentStore, pageDirectiveElementStore) {

        return function dataSource(param) {
            var
                pageSettings,
                viewerSetting = ViewerSettingService.getViewerSettings(),
                documentToSelect = null;

            //focused variables
            var currentFocusedDocId = '';
            var oldFocusedDocId = '';
            var currentFocusedPageId = '';
            var oldFocusedPageId = '';
            var that = this;

            //Initialize datasource
            ViewerImageLoader.setImageAPI(param.getImageAPI);
            ViewerImageLoader.setThread(4);

            var pageStore = new ViewerImageStore("PAGE", 10);
            var thumbStore = new ViewerThumbStore("THUMB", 50);
            var documentStore = new ViewerDocumentStore("DOCUMENT", 50);
            var annotationStore = new ViewerAnnotationStore("ANNOTATION", 10);
            var commentStore = new ViewerCommentStore("COMMENT", 10);
            var pageDirElementStore = new pageDirectiveElementStore("PAGEDIR", 10);

            ViewerImageLoader.setPageStore(pageStore);
            ViewerImageLoader.setThumbStore(thumbStore);


            /**
             * check image from thumb and page storage
             */
             this.getPageImageFromStorage = function(id,resolution){
               var pageData=false;
               if(resolution==="LOW"){
                pageData=(thumbStore.isDataAvailable(id))?{data: thumbStore.getData(id)}:false;
               }else {
                 pageData=(pageStore.isDataAvailable(id))?{data: pageStore.getData(id)}:false;
               }
               return pageData;
             };


             this.getPageImage = function(id, type, status, isForcefully, isPriority,resolution) {
                 var deferred = $q.defer();
                 type=(resolution==="LOW")?viewerConst.displayType.THUMBNAIL:viewerConst.displayType.PAGE;
                 ViewerImageLoader.loadPage(id, type, status, isForcefully, isPriority).then(function(result) {
                     //add data to store
                     pageStore.addData(id, result);
                     //reset Error
                     var pageObj = documentStore.getPageById(id);
                     if (pageObj) {
                         pageObj.resetErrorMessage(type);
                     }
                     //resolve for viewer
                     deferred.resolve({
                         data: result
                     });
                 }, function(error) {
                     if (error && error.data) {
                         error.data.type = type;
                         var pageObj = documentStore.getPageById(id);
                         if (pageObj) {
                             pageObj.setErrorMessage(error);
                         }
                         console.log('Error - $getImage$ while getting page image by id');
                     }
                 });
                 return deferred.promise;
             };

            /**
             * Provide image object to viewer.
             */
            this.getImage = function(id, type, status, isForcefully, isPriority) {

                var deferred = $q.defer();

                if (type === viewerConst.displayType.PAGE) {
                    if (pageStore.isDataAvailable(id)) {
                        deferred.resolve({
                            data: pageStore.getData(id)
                        });
                    } else {
                        ViewerImageLoader.loadPage(id, type, status, isForcefully, isPriority).then(function(result) {
                            //add data to store
                            pageStore.addData(id, result);
                            //reset Error
                            var pageObj = documentStore.getPageById(id);
                            if (pageObj) {
                                pageObj.resetErrorMessage(type);
                            }
                            //resolve for viewer
                            deferred.resolve({
                                data: result
                            });
                        }, function(error) {
                            if (error && error.data) {
                                error.data.type = type;
                                var pageObj = documentStore.getPageById(id);
                                if (pageObj) {
                                    pageObj.setErrorMessage(error);
                                }
                                console.log('Error - $getImage$ while getting page image by id');
                            }
                        });
                    }
                } else if (type === viewerConst.displayType.THUMBNAIL) {
                    if (thumbStore.isDataAvailable(id)) {
                        deferred.resolve({
                            data: thumbStore.getData(id)
                        });
                    } else {
                        ViewerImageLoader.loadPage(id, type, status, isForcefully, isPriority).then(function(result) {
                            //add data to store
                            thumbStore.addData(id, result);
                            //reset Error
                            var pageObj = documentStore.getPageById(id);
                            if (pageObj) {
                                pageObj.resetErrorMessage(type);
                            }
                            //resolve for viewer
                            deferred.resolve({
                                data: result
                            });
                        }, function(error) {
                            if (error && error.data) {
                                error.data.type = type;
                                var pageObj = documentStore.getPageById(id);
                                if (pageObj) {
                                    pageObj.setErrorMessage(error);
                                }
                                console.log('Error - $getImage$ while getting thumb image by id');
                            }
                        });
                    }
                }
                return deferred.promise;
            };

            /**
             * add docuemnt object from 3rd party.
             */
             this.addDocument = function(id, doc, index) {

                 //check doc object is valid type of document or not
                 if (!documentStore.isDataAvailable(id)) {
                     if (documentStore.getDocuments().length === viewerConst.VIEWER_MAX_DOC_ALLOCATION) {
                         if (!confirm(viewerConst.ADD_DOCUMENT_CONFIRMATION)) {
                             return;
                         }
                     }
                     //add doc
                     documentStore.addData(id, doc, index);

                     //focus the document
                    ViewerEvents.notify(ViewerEvents.NEW_DOCUMENT_ADDED);
                     $timeout(function() {
                         that.setFocusedDocument(id, true);
                     });
                 } else {

                     //focus the document
                     this.setFocusedDocument(id);
                     return new ViewerModel.Error({
                         code: viewerSetting.errorCodes.DOCUMENT_ALREADY_AVAILABLE,
                         message: viewerSetting.errorMessages[viewerSetting.errorCodes.DOCUMENT_ALREADY_AVAILABLE]
                     });
                 }
             };

             /**
              * add multiple docuemnts object from 3rd party.
              */
            this.addMultipleDocuments = function(data, docId) {
                if (data && data.length) {

                    //add multiple docs to storage
                    documentStore.addMultipleData(data);
                    ViewerSettingService.isMulitpleDocumentAdded = true;

                    //broadcast
                    ViewerEvents.notify(ViewerEvents.NEW_DOCUMENT_ADDED);

                    //focus the document, if the asked docId is present in the viewerStorage else take the first document from the strage
                    documentToSelect = (docId && this.getDocumentById(docId)) ? docId : data[0].id;
                    this.setFocusedDocument(documentToSelect, true);
                } else {
                    //INVALID_DOCUMENT
                    //document change call back if no documents available to change the state
                   this.clearImageViewer();
                }
            }

            /**
             * clears all the viewer data
             */
            this.clearImageViewer = function(isForcefully) {
                //deep clears viewer
                if (isForcefully) {
                    this.undoCutThumbs();
                }
                //set global value to maitain the viewer state
                ViewerSettingService.setIsViewerClearedForcufully(isForcefully);

                //clear old data
                oldFocusedDocId = '';
                currentFocusedDocId = '';
                documentStore.clearData();

                //avoids changing the state if pages has been cut to maintain paste over any set of new documents
                if (!this.getCutThumbsList().length) {
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.DISABLED);
                }

                //settings for page number and total count
                ViewerSettingService.setCurrentPageText(null);
                ViewerSettingService.setCurrentDocTotalPages(null);

                // triggers event to notify the viewer changes
                ViewerEvents.notify(ViewerEvents.NEW_DOCUMENT_ADDED);
                ViewerEvents.notify(ViewerEvents.DOCUMENT_CHANGED);

                //clears the focused page id
                this.setFocusedPageId('');
            };

            /**
             * remove docuemnt object by id from 3rd party and viewer.
             */
            this.removeDocument = function(id) {
                var deletedDoc = documentStore.getData(id);

                //removes specific document
                var newFocusedDoc = documentStore.removeData(deletedDoc);

                //remove all thumb local stored elements.
                if ( !this.getDocuments().length ) {
                    currentFocusedDocId = null;
                    oldFocusedDocId = null;

                    //settings for page number and total count
                    ViewerSettingService.setCurrentDocTotalPages(null);
                    ViewerSettingService.setCurrentPageText(null);

                    //updates viewer state
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.DISABLED);

                    // triggers event to notify the viewer changes
                    ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
                } else {
                    //sets new focused document
                    this.setFocusedDocument(newFocusedDoc.id, true);
                }

                //sets focused page and updates the new list
                var focusedPageId = newFocusedDoc ? newFocusedDoc.getFocusedPage().id : '';

                // triggers event to notify the viewer changes
                ViewerEvents.notify(ViewerEvents.NEW_DOCUMENT_ADDED);
                ViewerEvents.notify(ViewerEvents.PAGE_CHANGED, focusedPageId);
            };

            /**
             * Provides selected thumbs object to viewer.
             */
            this.getSelectedPages = function() {
                return documentStore.getSelectedPages();
            };

            /**
             * Provides selected pages based on the document id.
             */
            this.getSelectedPagesByDocId = function(docId) {
                return documentStore.getSelectedPagesByDocId(docId);
            };

            /**
             * Modify the selection property of thumb object.
             */
            this.setSelectedThumb = function(docObj, pageId, isMultiThumbSelected, isReorder) {
                ViewerSettingService.setIsMultiThumbSelected(isMultiThumbSelected);
                this.setFocusedDocId(docObj.id);

                //highlight the selected thumb
                documentStore.setSelectedThumb(currentFocusedDocId, oldFocusedDocId, pageId, isMultiThumbSelected, isReorder);

                //settings for selected page number and total doc count
                ViewerSettingService.setCurrentPageText(docObj.getPageById(pageId).pageNumber);
                ViewerSettingService.setCurrentDocTotalPages(docObj.pages.length);

                //validates if thumb selected within same document or not
                if (currentFocusedDocId !== oldFocusedDocId) {
                    ViewerEvents.notify(ViewerEvents.DOCUMENT_CHANGED, currentFocusedDocId);
                }

                //sets focused page id
                this.setFocusedPageId(docObj.getFocusedPage().id);

                // triggers event to notify the page change
                ViewerEvents.notify(ViewerEvents.PAGE_CHANGED, docObj.getFocusedPage().id);
            };

            /**
             * select document as focused
             * @param {document object} id [description]
             */
            this.setFocusedDocument = function setFocusedDocument(newDocId, isFromApplication) {
                //undo multiselect
                if (!this.getDocumentById(newDocId)) {
                    return;
                }
                ViewerSettingService.setIsMultiThumbSelected(false);

                //update instance variable
                this.setFocusedDocId(newDocId);

                //update focused property in storage
                if (newDocId !== this.getOldFocusedDocId()) {
                    documentStore.clearSelectedThumbs();
                    var docObj = documentStore.setFocusedDocument(newDocId, this.getOldFocusedDocId());

                    //for document with no focused page
                    if (!docObj.getFocusedPage()) {
                        //update page properties
                        docObj.focusPageByIndex(0);
                        documentStore.manageSelectedPageIds(false, docObj.getFocusedPage().id);

                        //settings for handling shortcuts
                        ViewerSettingService.setShortCutFocusedPage(docObj.getFocusedPage());
                        ViewerSettingService.setPreviousFocusedDoc(docObj);
                        ViewerSettingService.setShortCutState('ctrl');
                    }

                    //Update settings properties
                    ViewerSettingService.setCurrentDocTotalPages(docObj.pages.length);
                    ViewerSettingService.setCurrentPageText(1);

                    //broadcast
                    // triggers event to notify the document change
                    ViewerEvents.notify(ViewerEvents.DOCUMENT_CHANGED, docObj.id, isFromApplication);
                }
            };

            /**
             * sets page edit operations(cut/paste)
             */
            this.setThumbEditAction = function(action) {
                documentStore.setThumbEditAction(action);
            };

            /**
             * return cut thumbs
             */
            this.getCutThumbsList = function() {
                return documentStore.getCutThumbsList();
            };

            /**
             * validates the thumbs slected
             */
            this.validateEditOperationOnThumbSelection = function() {
                return documentStore.validateEditOperationOnThumbSelection();
            };

            /**
             * Provides all document objects to viewer.
             */
            this.getDocuments = function() {
                return documentStore.getDocuments();
            };

            /**
             * returns document index by id
             */
            this.getDocIndexById = function(id) {
                return documentStore.getDocIndexById(id);
            };

            /**
             * remove pages from documents.
             */
            this.deleteDocumentPages = function(docs, updatedDocs) {
                //sets boolean to notify whether multiple thumbs selected
                ViewerSettingService.setIsMultiThumbSelected(false);

                //deletes the selected pages
                documentStore.deleteDocumentPages(docs, updatedDocs);

                //gets focused document
                var focusedDoc =  this.getFocusedDocument();

                //delaying, since list preparation takes time
                $timeout(function() {
                    var focusedPage = focusedDoc.getFocusedPage();
                    if (focusedPage) {
                        //sets new focused page id
                        documentStore.setFocusedPageId(focusedPage.id);

                        //settings for selected page number and total doc count
                        ViewerSettingService.setCurrentPageText(focusedPage.pageNumber);
                        ViewerSettingService.setCurrentDocTotalPages(focusedDoc.pages.length);

                        //broadcast
                        // triggers event to notify the page change
                        ViewerEvents.notify(ViewerEvents.PAGE_CHANGED, focusedPage.id);
                    }
                });
            };

            /**
            *  sets page settings for a page
            */
            this.setPageSettings = function(settings) {
                documentStore.setPageSettings(settings);
                ViewerEvents.notify(ViewerEvents.ROTATION_CHANGED);
            };

            /**
             * returns selected document count
             */
            this.getSelectedThumbsCount = function getSelectedThumbsCount() {
                return documentStore.getSelectedPages().length;
            };

            /**
             * returns page by id
             */
            this.getPageById = function getPageById(pageId) {
                return documentStore.getPageById(pageId);
            };

            /**
            *  returns page settings for a page
            */
            this.getPageSettings = function() {
                return documentStore.getPageSettings();
            };

            /**
            *  returns the focused page id
            */
            this.getFocusedPageId = function() {
                return documentStore.getFocusedPageId();
            };

            /**
            *  sets the focused page id
            */
            this.setFocusedPageId = function(pageId) {
                documentStore.setFocusedPageId(pageId);

                //TODO: move to separate function
                var currViewerState = ViewerSettingService.getViewerState();
                var allDocs = this.getDocuments();
                var focusedDoc = this.getFocusedDocument();
                var focusedPage = (focusedDoc) ? this.getFocusedDocument().getFocusedPage() : null;

                //if document is not valid
                if (currViewerState === viewerConst.VIEW_STATE.DISABLE_EDIT) {
                    ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
                    return;
                }

                //if page not found
                if (focusedPage && (focusedPage.error.THUMBNAIL.isError || focusedPage.error.PAGE.isError)) {
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.CORRUPT_PAGE);
                    ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
                    return;
                }

                //if document is good
                if (allDocs.length) {
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.BASIC);
                } else { //if no documents available in viewer
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.DISABLED);
                }

                //notify viewer state change
                ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
            };

            /**
             * returns focused document
             */
            this.getFocusedDocument = function getFocusedDocument() {
                return this.getDocumentById(currentFocusedDocId);
            };

            /**
             * returns previously focused document
             */
            this.getOldFocusedDocument = function getOldFocusedDocument() {
                return this.getDocumentById(oldFocusedDocId);
            };

            /**
             * Provides index of focushed doc to viewer.
             */
            this.getFocusedDocIndex = function() {
                return documentStore.getFocusedDocIndex();
            };

            /**
             * Provides doc obj to viewer.
             */
            this.getDocumentById = function(id) {
                return documentStore.getData(id);
            };

            /**
             * provide focused doc id.
             */
            this.getFocusedDocId = function getFocusedDocId() {
                return currentFocusedDocId;
            };

            /**
             * provide old focused doc id.
             */
            this.getOldFocusedDocId = function getOldFocusedDocId() {
                return oldFocusedDocId;
            };

            /**
             * set focused doc id and current doc as old doc id.
             */
            this.setFocusedDocId = function setFocusedDocId(newDocId) {
                oldFocusedDocId = currentFocusedDocId;
                currentFocusedDocId = newDocId;
            };

            /**
             * clears all selection from all selected thumbnails
             */
            this.clearSelectedThumbs = function clearSelectedThumbs() {
                documentStore.clearSelectedThumbs();
            };

            /**
             * returns pages selected for reorder
             */
            this.getPagesForReorder = function() {
                return documentStore.getPagesForReorder();
            };

            /**
             * command to select scrolled page.
             */
            this.focusScrolledPage = function focusScrolledPage(pageObj) {
                //sets boolean to notify whether multiple thumbs selected
                if (ViewerSettingService.getIsMultiThumbSelected()) {
                    ViewerSettingService.setIsMultiThumbSelected(false);
                    return;
                }

                //error model for invalid page
                var error = new ViewerModel.Error({
                    code: viewerSetting.errorCodes.INVALID_PAGE,
                    message: viewerSetting.errorMessages[viewerSetting.errorCodes.INVALID_PAGE]
                });

                if (currentFocusedDocId !== "" && currentFocusedDocId !== null) {
                    var focusedPage = this.getDocumentById(currentFocusedDocId).getFocusedPage();
                    this.focusPage(pageObj, error, focusedPage, true, true);

                    //Handling shortcuts while page scroll
                    var prevPage = documentStore.getPreviousPage(pageObj);
                    var nextPage = documentStore.getNextPage(pageObj);

                    //gets the shortcut page direction using shift
                    var shortcutPageSelectionDir = ViewerSettingService.getPageSelectDirection();
                    if (!shortcutPageSelectionDir) {
                        return;
                    }

                    //to check if selection sequence breaks or not
                    var newlyFocusedPage = (shortcutPageSelectionDir === 'downwards') ? prevPage : nextPage;
                    if (newlyFocusedPage && !newlyFocusedPage.isSelected) {

                        //settings for handling shortcuts
                        ViewerSettingService.setShortCutFocusedPage(pageObj);
                        ViewerSettingService.setShortCutState('ctrl');
                    }
                }
            };

            /**
             * command to select next page.
             */
            this.focusNextPage = function focusNextPage() {

                //gets current focused page by doc id and selects next page
                var focusedPage = this.getDocumentById(currentFocusedDocId).getFocusedPage();
                var pageObj = documentStore.getNextPage(focusedPage);

                //if page is not present in the current doc and if user doesn't want continous navigation
                if (pageObj && (pageObj.docId !== focusedPage.docId) && !viewerSetting.actions.viewer.continousNavigation) {
                    return;
                }

                //error model for showing error if last page reached
                var error = new ViewerModel.Error({
                    code: viewerSetting.errorCodes.LAST_PAGE,
                    message: viewerSetting.errorMessages[viewerSetting.errorCodes.LAST_PAGE]
                });

                //clears all selected pages
                if (pageObj) {
                    documentStore.clearSelectedThumbs();
                }

                //sets shortcut focused page
                ViewerSettingService.setShortCutFocusedPage(pageObj ? pageObj : focusedPage);
                this.focusPage(pageObj, error, focusedPage, false);
            };

            /**
             * command to select prev page.
             */
            this.focusPrevPage = function focusPrevPage() {

                //gets current focused page by doc id and selects next page
                var focusedPage = this.getDocumentById(currentFocusedDocId).getFocusedPage();
                var pageObj = documentStore.getPreviousPage(focusedPage);

                //if page is not present in the current doc and if user doesn't want continous navigation
                if (pageObj && (pageObj.docId !== focusedPage.docId) && !viewerSetting.actions.viewer.continousNavigation) {
                    return;
                }
                //error model for showing error if first page reached
                var error = new ViewerModel.Error({
                    code: viewerSetting.errorCodes.FIRST_PAGE,
                    message: viewerSetting.errorMessages[viewerSetting.errorCodes.FIRST_PAGE]
                });

                //clears all selected pages
                if (pageObj) {
                    documentStore.clearSelectedThumbs();
                }

                //sets shortcut focused page
                ViewerSettingService.setShortCutFocusedPage(pageObj ? pageObj : focusedPage);
                this.focusPage(pageObj, error, focusedPage, true);
            };

            /**
            * command to select/deselect next page using shift key.
            */
            this.toggleNextPage = function toggleNextPage(focusedDoc, currPageIndex, shortCutFocusedPageIndex) {

                //gets current focused page by doc id and selects next page
                var focusedPage = this.getDocumentById(currentFocusedDocId).getFocusedPage();
                var pageObj = documentStore.getNextPage(focusedPage);

                //if page is not present in the current doc, show error
                if (pageObj && (pageObj.docId !== focusedPage.docId)) {

                    //error model for showing error if selection made across document
                    ViewerNotification.showError(new ViewerModel.Error({
                        code: viewerSetting.errorCodes.MULTISELECT_THUMB_RESTRICT,
                        message: viewerSetting.errorMessages[viewerSetting.errorCodes.MULTISELECT_THUMB_RESTRICT]
                    }));
                    return;
                }

                //toggle select/deselect thumb
                if (!pageObj || currPageIndex < shortCutFocusedPageIndex) {
                    var error = new ViewerModel.Error({
                        code: viewerSetting.errorCodes.LAST_PAGE,
                        message: viewerSetting.errorMessages[viewerSetting.errorCodes.LAST_PAGE]
                    });
                    this.focusPage(pageObj, error, focusedPage, false);
                    return;
                }

                //select thumb
                var nextPage = focusedDoc.pages[currPageIndex + 1];
                if (nextPage) {
                    this.setSelectedThumb(focusedDoc, nextPage.id, true);
                }
            };

            /**
            * command to select/deselect prev page using shift key.
            */
            this.togglePrevPage = function togglePrevPage(focusedDoc, currPageIndex, shortCutFocusedPageIndex) {

                //gets current focused page by doc id and selects next page
                var focusedPage = this.getDocumentById(currentFocusedDocId).getFocusedPage();
                var pageObj = documentStore.getPreviousPage(focusedPage);

                //if page is not present in the current doc, show error
                if (pageObj && (pageObj.docId !== focusedPage.docId)) {

                    //error model for showing error if selection made across document
                    ViewerNotification.showError(new ViewerModel.Error({
                        code: viewerSetting.errorCodes.MULTISELECT_THUMB_RESTRICT,
                        message: viewerSetting.errorMessages[viewerSetting.errorCodes.MULTISELECT_THUMB_RESTRICT]
                    }));
                    return;
                }

                //toggle select/deselect thumb
                if (!pageObj || currPageIndex > shortCutFocusedPageIndex) {
                    var error = new ViewerModel.Error({
                        code: viewerSetting.errorCodes.FIRST_PAGE,
                        message: viewerSetting.errorMessages[viewerSetting.errorCodes.FIRST_PAGE]
                    });
                    this.focusPage(pageObj, error, focusedPage, true);
                    return;
                }

                //select thumb
                var prevPage = focusedDoc.pages[currPageIndex - 1];
                if (prevPage) {
                    this.setSelectedThumb(focusedDoc, prevPage.id, true);
                }
            };

            /**
             * focus the selected page
             */
            this.focusPage = function focusPage(newPage, error, oldPage, isPrev, isPageScrolled) {

                //sets boolean to notify whether multiple thumbs selected
                ViewerSettingService.setIsMultiThumbSelected(false);
                var focusedPage = (oldPage) ? oldPage : this.getDocumentById(currentFocusedDocId).getFocusedPage();
                if (newPage) {

                    //checks if previous and current focused doc id's are different
                    if (this.getFocusedDocId() !== newPage.docId) {
                        this.setFocusedDocument(newPage.docId);
                        if (isPrev) {
                            documentStore.setFocusedPage(newPage, this.getFocusedDocument().getFocusedPage());
                        }

                        //setting the shortcut focused page
                        ViewerSettingService.setShortCutFocusedPage(newPage);
                        ViewerSettingService.setPreviousFocusedDoc(this.getDocumentById(newPage.docId));
                    } else {
                        documentStore.setFocusedPage(newPage, focusedPage);
                    }
                    var focusedDoc = this.getFocusedDocument();

                    //sets focused page numbe and total document count
                    ViewerSettingService.setCurrentPageText(newPage.pageNumber);
                    ViewerSettingService.setCurrentDocTotalPages(focusedDoc.pages.length);

                    //gets focused doc obj and sets the doc id
                    var focusedPageObj = focusedDoc.getFocusedPage();
                    this.setFocusedPageId(focusedPageObj.id);

                    if (focusedPageObj) {
                        //if scroll made by user, else for auto scroll
                        if (isPageScrolled) {
                            ViewerEvents.notify(ViewerEvents.NAV_TO_THUMB, focusedPageObj.id);
                        } else {
                            ViewerEvents.notify(ViewerEvents.PAGE_CHANGED, focusedPageObj.id);
                        }
                    } else {
                        this.jumpToPage(newPage.pageNumber);
                    }
                } else {
                    if (error) {
                        ViewerNotification.showError(error);
                    }
                }
            };

            /**
             *  commant to navigate to the given page number
             */
            this.jumpToPage = function jumpToPage(pageNum) {
                ViewerEvents.notify(ViewerEvents.JUMP_TO_PAGE, {pageNum : pageNum, postResetThumbnailView: this.postResetThumbnailView});
            };

            /**
             *  callback function which executes after jump to page
             */
            this.postResetThumbnailView = function(pageNum) {
                //gets focused doc obj and page obj
                var focusedDoc = that.getFocusedDocument();
                var pageObj = focusedDoc.getPageByPageNumber(pageNum);

                if (!pageObj) {
                    //gets current focused page if invalid page number provided
                    pageObj = focusedDoc.getPageById(that.getFocusedPageId());

                    //error model for showing invalid page error
                    var error = new ViewerModel.Error({
                        code: viewerSetting.errorCodes.INVALID_PAGE,
                        message: viewerSetting.errorMessages[viewerSetting.errorCodes.INVALID_PAGE]
                    });

                    //delays, as error message is not binding immediately
                    $timeout(function() {
                        ViewerNotification.showError(error);
                    });
                }
                $timeout(function() {
                    //set focused page and page id
                    documentStore.setFocusedPage(pageObj, focusedDoc.getFocusedPage());
                    that.setFocusedPageId(pageObj.id);

                    //settings for handling shortcuts
                    ViewerSettingService.setShortCutFocusedPage(focusedDoc.getFocusedPage());
                    ViewerSettingService.setPreviousFocusedDoc(focusedDoc);
                    ViewerSettingService.setShortCutState('ctrl');
                });

                //sets current focused page number and total docs count
                ViewerSettingService.setCurrentPageText(pageObj.pageNumber);
                ViewerSettingService.setCurrentDocTotalPages(focusedDoc.pages.length);

                //triggrs event to notify the page change
                ViewerEvents.notify(ViewerEvents.PAGE_CHANGED, pageObj.id, true);
            };

            /**
            *  Provides comments
            */
            this.getComments = function () {
                return commentStore.getComments();
            };

            /**
            *  add comment
            */
            this.addComment = function (commentObj) {
                commentStore.addComment(commentObj);
            };

            /**
            *  add annotation
            */
            this.addAnnotation = function (annotationObj, isPushTop) {
                annotationStore.addAnnotation(annotationObj, isPushTop);
            };

            /**
            *  delete annotation
            */
            this.deleteAnnotation = function (annotationId) {
                annotationStore.deleteAnnotation(annotationId);
            };

            /**
            *  Provides annotations list in the viewer
            */
            this.getAnnotations = function () {
                return annotationStore.getAnnotations();
            };

            /**
            *  Provides annotations list for the given page
            */
            this.getAnnotationByPageId = function (pageId) {
                return annotationStore.getAnnotationByPageId(pageId);
            };

            /**
            *  Clears annotations list
            */
            this.resetAnnotations = function () {
                return annotationStore.resetAnnotations();
            };
            /*
            *  add reply to comment
            */
            this.addReplyToComment = function (responeData) {
                annotationStore.addReplyToComment(responeData);
            };

            /**
            *  delete comment
            */
            this.deleteComment = function (comment) {
                annotationStore.deleteComment(comment);
            };

            /**
            *  reorder pages
            */
            this.reorderPages = function reorderPages(data, pagesForReorder) {
                documentStore.reorderPages(data, pagesForReorder);
                currentFocusedDocId = this.getDocuments()[data.toDoc].id;
                var fromDocObj = this.getDocuments()[data.fromDoc];
                oldFocusedDocId = fromDocObj ? fromDocObj.id : null;
            };

            /**
            *  removes the cut thumbs
            */
            this.removeCutDocumentsFromList = function removeCutDocumentsFromList() {
                documentStore.removeCutDocumentsFromList();
            };

            /**
            *  undo all the cut thumbs
            */
            this.undoCutThumbs = function undoCutThumbs() {
                documentStore.undoCutThumbs();
            };

            /**
            *  undo page reorder
            */
            this.undoReorderChanges = function undoReorderChanges() {
                var reorderModel = documentStore.undoReorderChanges();
                var fromDocObj = reorderModel.fromDocObj ? reorderModel.fromDocObj : this.getFocusedDocument();
                if (!fromDocObj) { return; }
                this.setFocusedDocId(fromDocObj.id);
                var focusedPage = reorderModel.focusedPageObj;
                if (!focusedPage) { return; }
                this.setFocusedPageId(focusedPage.id);
            }

            /**
            *  updates the existing document
            */
            this.updateDocuments = function updateDocuments(response) {
                documentStore.updateDocuments(response);
            };

            /**
            *  triggers error event to display error in viewer from 3rd part application
            */
            this.showError = function(errorObj) {
                ViewerNotification.showError(errorObj);
            };

            /**
            *  adding page directive element to store
            */
            this.addElement = function addElement(id, pageDirElement) {
                pageDirElementStore.addElement(id, pageDirElement);
            };

            /**
            *  get page directive element by pageId
            */
            this.getPageDirElementById = function getPageDirElementById(pageId) {
                return pageDirElementStore.getPageDirElementById(pageId);
            };

            /**
            *  delete page directive element by pageId
            */
            this.deletePageDirElement = function deletePageDirElement(pageId) {
                pageDirElementStore.deletePageDirElement(pageId);
            };

            /**
            *  get all page directive elements
            */
            this.getAllPageDirElements = function getAllPageDirElements() {
                return pageDirElementStore.getAllPageDirElements();
            };

            /**
            *  get all page directive as object
            */
            this.getPageDirObjects = function getPageDirObjects() {
                return pageDirElementStore.getPageDirObjects();
            };

            /**
            *  reset all page directive element
            */
            this.resetAllPageDirElements = function resetAllPageDirElements() {
                pageDirElementStore.resetAllPageDirElements();
            };

            /**
            *  cancels old page request if requests and not completed
            */
            this.cancelOldPageRequest = function cancelOldPageRequest(listOfVisibleKeysArr) {
                ViewerImageLoader.cancelOldPageRequest(listOfVisibleKeysArr);
            };

            /**
            *  cancels old thumb request if requests and not completed
            */
            this.cancelOldThumbRequest = function cancelOldThumbRequest(listOfVisibleKeysArr) {
                ViewerImageLoader.cancelOldThumbRequest(listOfVisibleKeysArr);
            };

            /**
            *  sets next document as focused
            */
            this.setNextDocumentFocus = function setNextDocumentFocus(docId) {
                this.setFocusedDocument(documentStore.getNextDocId(docId), true);
            };

            /**
            *  sets prev document as focused
            */
            this.setPrevDocumentFocus = function setPrevDocumentFocus(docId) {
                this.setFocusedDocument(documentStore.getPrevDocId(docId), true);
            };

            /**
            *  triggers viewer resize event from 3rd part application
            */
            this.notifyViewerResized = function notifyViewerResized() {
                ViewerEvents.notify(ViewerEvents.VIEWER_RESIZED, true);
            };

            /**
            *  triggers viewer state change event from 3rd part application
            */
            this.notifyViewerStateChnaged = function notifyViewerStateChnaged(stateId) {
                ViewerSettingService.setViewerState(stateId);

                //setFocusedPageId func internally changes the viewer state
                this.setFocusedPageId(this.getFocusedPageId());
            };

        };
    }
]);
