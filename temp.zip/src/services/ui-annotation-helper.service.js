uiv.service('AnnotationHelperService', ['ViewerUtilitis', 'ViewerModel', 'viewerConst', 'ViewerSettingService',
    function(ViewerUtilitis, ViewerModel, viewerConst, ViewerSettingService) {
        var vm = this;

        /**
        * [buildBoxTemplate description]
        * @return {[type]} boxTemplateString [description]
        */
        this.buildBoxTemplate = function buildBoxTemplate() {
            var boxTemplateString = '<div class="container box-template" id="box-template" style="position: absolute; width: 200px; height: 140px; padding: 0px; z-index: 1">'+
                                        '<button type="button" id="closeIcon" class="pull-right" ng-click="onCancelAnnotation();">'+
                                            '<i aria-hidden="true" class="fa fa-times-circle"></i>'+
                                            '<span class="sr-only">Close</span>'+
                                        '</button>'+
                                        '<form role="form">'+
                                            '<div class="form-group">'+
                                                '<div ng-if="isAnnotationText()" style="padding-bottom: 5px;">'+
                                                    '<input type="text" class="form-control annotation-text-textbox" ng-model="annotationText.val" ng-enter="event.preventDefault();" placeholder="Please write here" style="position: absolute;top: -30px;left: 0;width:150px"/>'+
                                                '</div>'+
                                                '<textarea class="annotation-comment-text" ng-model="annotationComments" placeholder="Comments" maxlength="500" style="width:180px; height:60px;">'+
                                                '</textarea>'+
                                            '</div>'+
                                            '<div class="box-template-footer">'+
                                                '<button class="btn pull-left btn-default rfng-button" ng-click="onCancelAnnotation()" ng-disabled="!canSaveAnnotation">Cancel</button>'+
                                                '<button type="submit" class="btn pull-right btn-primary rfng-button" ng-click="onSaveAnnotation()" ng-disabled="!canSaveAnnotation">Save</button>'+
                                            '</div>'+
                                        '</form>'+
                                    '</div>';
            return boxTemplateString;
        };


        /**
        * [getTransformationString description]
        * @return {[type]} [description]
        */
        this.getTransformationString = function getTransformationString(settings) {
            var ts,
                ih = settings.imageHeight,
                iw = settings.imageWidth,
                scale = settings.scale,
                rotation = settings.rotation;

            switch (rotation) {
                case 0:
                    ts = 's' + scale + ',' + scale + ',0,0r' + rotation + ',0,0t0,0';
                    break;
                case 90:
                    ts = 's' + scale + ',' + scale + ',0,0r' + rotation + ',0,0t0,-' + ih;
                    break;
                case 180:
                    ts = 's' + scale + ',' + scale + ',0,0r' + rotation + ',0,0t-' + iw + ',-' + ih;
                    break;
                case 270:
                    ts = 's' + scale + ',' + scale + ',0,0r' + rotation + ',0,0t-' + iw + ',0';
                    break;
            }
            return ts;
        };

        /**
        * [getOriginalBbox description]
        * @param  {[type]} [description]
        * @return {[type]} [description]
        */
        var getOriginalBbox = function getOriginalBbox(shape, settings) {
            var pageSettingsObject = settings;
            var svg = {
                width: pageSettingsObject.imageWidth * pageSettingsObject.scale,
                height: pageSettingsObject.imageHeight * pageSettingsObject.scale
            };
            var rs = 1 / pageSettingsObject.scale;

            var transformString, trR, trS, trT;
            switch (pageSettingsObject.rotation) {
                case 0:
                    transformString = 's' + rs + ',' + rs + ',0,0r' + pageSettingsObject.rotation + ',0,0t0,0';
                    break;
                case 90:
                    trR = 'r-' + pageSettingsObject.rotation + ',0,0';
                    trS = 's' + rs + ',' + rs + ',0,0';
                    trT = 't-' + svg.height + ',0';
                    transformString = trR + trS + trT;
                    break;
                case 180:
                    transformString = 's' + rs + ',' + rs + ',0,0r' + pageSettingsObject.rotation + ',0,0t-' + svg.width + ',-' + svg.height;
                    break;
                case 270:
                    trR = 'r-' + pageSettingsObject.rotation + ',0,0';
                    trS = 's' + rs + ',' + rs + ',0,0';
                    trT = 't0,-' + svg.width;
                    transformString = trR + trS + trT;
                    break;
            }
            shape.transform(transformString);
            //shape.attr({ x: 0 });
            return shape.getBBox();
        };

        /**
        * [getBboxInFullScale description]
        * @param  {[type]}  [description]
        * @return {[type]}  [description]
        */
        this.getBboxInFullScale = function getBboxInFullScale(paper, box, settings) {
            var tempShape = paper.rect(box.x, box.y, box.w, box.h).attr({
                'stroke-width': 0
            });
            var drawnElementBbox = tempShape.getBBox();
            var bbox = getOriginalBbox(tempShape, settings);
            bbox.scaledBbox = drawnElementBbox;
            tempShape.remove();
            return bbox;
        };

        /**
        * [applyFreeTransform description]
        * @param  {[type]} rapahelPaper, settings, newDrawnElement, drawnElementBbox, transformString [description]
        */
        this.applyFreeTransform = function(paper, settings, newDrawnElement, drawnElementBbox, transformString) {
            //TODO need to be uncommented for edit annotation
            /*var drawnElementFreeTransform = paper.freeTransform(newDrawnElement, {
                attrs: {
                    fill: 'white',
                    stroke: '#f00',
                    rotate: settings.rotation
                },
                drag: true,
                keepRatio: ['axisX', 'axisY'],
                size: 5,
                scale: ['bboxCorners', 'bboxSides'],
                rotate: false,
                draw: ['bbox']
            });

            //apply transformation
            var tMatrix = ViewerUtilitis.tranformStringToMatrix(transformString);
            drawnElementFreeTransform.attrs.center.x = drawnElementBbox.cx; //scaledBox.cx;
            drawnElementFreeTransform.attrs.center.y = drawnElementBbox.cy; //scaledBox.cy;
            drawnElementFreeTransform.attrs.scale.x = tMatrix.scale.x;
            drawnElementFreeTransform.attrs.scale.y = tMatrix.scale.y;
            drawnElementFreeTransform.apply();
            return drawnElementFreeTransform;*/
            return null;
        };

        /**
        * [drawCommentAnnotation description]
        * @param  {[type]} rapahelPaper, bbox, iconsize [description]
        * @return {[type]} drawn element [description]
        */
        this.drawCommentAnnotation = function drawCommentAnnotation(paper, bbox, iconSize) {
            var drawnElement = paper.image('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAApgAAAKYB3X3/OAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAHQSURBVEiJtdW/a1NRFAfwz60BQTRTbS1CCw6C4uDkHyAVyaCDWRwFN8VJdBIdHXQQHPwHBEHsmoLiIkIXdRMJgkWoYhCVVFBB7HXIqby85lkT0wNnePee8/2eX/e8lHO2lVL7F6OUUh3TodBBJ+e8uqlzznmDBnEDd7CCXKErYdNAbSDWAPAm2iWgd2jhemgrzoo2bTQrCVDHozD+jls4islBkYXPJOZxO3xyYNT7CDCFF2FwHzNVoH8hmwnfHFhTRYJWXNxEGha8QJJwI7Ba6xPaiIPFUYEHEC0GZgMW4mNujARzgbmQ8Brbcs77Np3pISSl9Aa/JrAH3XGCh3wQD/O5XjqzYyxRwiqWJvA4GJtjjP40dmFJpPFN79kfGkP0e/FRr+zT64dno0xdHPsP8AN4G1jny6viMtbwExdVLK8K4DquRoBruPDnrmQ4j/cRwbli00p2sziBK3iAz+GzjJN9tgOiuRvG++P7uN7IfY30v9i4tpdxCdvLeH0/nJTSbpzCE3RTSvdiIn7oLbCd0cBO6Eu9nfOqcp4qon9YiPQZDo7c+FKTi2l3cW2YZlcS4HAB+CnOYMc4XnXKOUsp1XAE7Zzzp8p6jiApMtgy+Q23RDwBt/OWXQAAAABJRU5ErkJggg==', bbox.x, bbox.y, iconSize, iconSize);
            return drawnElement;
        };

        /**
        * [drawUnderlineAnnotation description]
        * @param  {[type]} rapahelPaper, bbox, settings [description]
        * @return {[type]} drawn element [description]
        */
        this.drawUnderlineAnnotation = function drawUnderlineAnnotation(paper, bbox, settings) {
            var drawnElement;
            switch (settings.rotation) {
                case 0:
                    drawnElement = paper.path('M' + bbox.x + ' ' + bbox.y2 + ' L' + bbox.x2 + ' ' + bbox.y2);
                    break;
                case 90:
                    drawnElement = paper.path('M' + bbox.x2 + ' ' + bbox.y + ' L' + bbox.x2 + ' ' + bbox.y2);
                    break;
                case 180:
                    drawnElement = paper.path('M' + bbox.x + ' ' + bbox.y + ' L' + bbox.x2 + ' ' + bbox.y);
                    break;
                case 270:
                    drawnElement = paper.path('M' + bbox.x + ' ' + bbox.y + ' L' + bbox.x + ' ' + bbox.y2);
                    break;
            }
            return drawnElement;
        };

        /**
        * [drawTextAnnotation description]
        * @param  {[type]} rapahelPaper, bbox, settings [description]
        * @return {[type]} drawn element [description]
        */
        this.drawTextAnnotation = function drawTextAnnotation(paper, bbox, settings) {
            var drawnElement;
            switch (settings.rotation) {
                case 0:
                    drawnElement = paper.text(bbox.x + 40, bbox.y + 10, 'Text');
                    break;
                case 90:
                    drawnElement = paper.text(bbox.x + 40, bbox.y + 10, 'Text');
                    break;
                case 180:
                    drawnElement = paper.text(bbox.x + 40, bbox.y + 10, 'Text');
                    break;
                case 270:
                    drawnElement = paper.text(bbox.x + 40, bbox.y + 10, 'Text');
                    break;
            }
            return drawnElement;
        };

        /**
        * [drawStrikeoutAnnotation description]
        * @param  {[type]} rapahelPaper, bbox, settings [description]
        * @return {[type]} drawn element [description]
        */
        this.drawStrikeoutAnnotation = function drawStrikeoutAnnotation(paper, bbox, settings) {
            var drawnElement;
            switch (settings.rotation) {
                case 0:
                    drawnElement = paper.path('M' + bbox.x + ' ' + bbox.cy + ' L' + bbox.x2 + ' ' + bbox.cy);
                    break;
                case 90:
                    drawnElement = paper.path('M' + bbox.cx + ' ' + bbox.y + ' L' + bbox.cx + ' ' + bbox.y2);
                    break;
                case 180:
                    drawnElement = paper.path('M' + bbox.x + ' ' + bbox.cy + ' L' + bbox.x2 + ' ' + bbox.cy);
                    break;
                case 270:
                    drawnElement = paper.path('M' + bbox.cx + ' ' + bbox.y + ' L' + bbox.cx + ' ' + bbox.y2);
                    break;
            }
            return drawnElement;
        };

        /**
        * [drawEraseAnnotation description]
        * @param  {[type]} rapahelPaper, bbox [description]
        * @return {[type]} drawn element [description]
        */
        this.drawEraseAnnotation = function drawEraseAnnotation(paper, bbox) {
            var drawnElement = paper.rect(bbox.x, bbox.y, bbox.x2 - bbox.x, bbox.y2 - bbox.y).attr({
                'fill': '#e6e6ff',
                'stroke-width': 0
            });
            return drawnElement;
        };

        /**
        * [drawRedactionAnnotation description]
        * @param  {[type]} rapahelPaper, bbox [description]
        * @return {[type]} drawn element [description]
        */
        this.drawRedactionAnnotation = function drawRedactionAnnotation(paper, bbox) {
            var drawnElement = paper.rect(bbox.x, bbox.y, bbox.x2 - bbox.x, bbox.y2 - bbox.y).attr({
                'fill': '#000000',
                'stroke-width': 0
            });
            return drawnElement;
        };

        /**
        * [drawHighlightAnnotation description]
        * @param  {[type]} rapahelPaper, bbox [description]
        * @return {[type]} drawn element [description]
        */
        this.drawHighlightAnnotation = function drawHighlightAnnotation(paper, bbox) {
            var drawnElement = paper.rect(bbox.x, bbox.y, bbox.x2 - bbox.x, bbox.y2 - bbox.y).attr({
                'fill': '#FFFF00',
                'stroke-width': 0,
                'opacity': 0.3
            });
            return drawnElement;
        };

        /**
        * [removeSelfClosingTags description]
        * @param  {[type]} dom string [description]
        * @return {[type]} [description]
        */
        this.removeSelfClosingTags = function removeSelfClosingTags(xml) {
            var split = xml.split("/>");
            var newXml = "";
            for (var i = 0; i < split.length - 1;i++) {
                var edsplit = split[i].split("<");
                newXml += split[i] + "></" + edsplit[edsplit.length - 1].split(" ")[0] + ">";
            }
            return newXml + split[split.length-1];
        };

        /**
        * [constructAnnotationModel description]
        * @param  {[type]} rapahelPaper, bbox [description]
        * @return {[type]} drawn element [description]
        */
        this.constructAnnotationModel = function constructAnnotationModel(pageObj, commentModel, svgContainer, drawnElement, drawnElementFreeTransform) {
            var updatedDomString = this.removeSelfClosingTags(drawnElement.node.outerHTML);
            // var tmp = new Regex(@"(<"+drawnElement.type+"[^>]*)(s*/>)").Replace(tmp, "$1></"+ drawnElement.type +">");
            var annotationModel = new ViewerModel.Annotation({
                documentObjectId: pageObj.id,
                annotationType: viewerConst.ANNOTATION_TYPES[ViewerSettingService.getAnnotationTypeId()].label,
                content: ViewerUtilitis.htmlEscape(updatedDomString),
                comments: [commentModel],
                imageWidth: pageObj.getDimension().width,
                imageHeight: pageObj.getDimension().height,
                drawnElement: drawnElement,
                drawnElementFreeTransform: drawnElementFreeTransform
            });
            return annotationModel;
        };
    }
]);
