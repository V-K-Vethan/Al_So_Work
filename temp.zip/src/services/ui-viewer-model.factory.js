uiv.factory('ViewerModel', function(ViewerSettingService, viewerConst){

    var model =  {
        Error: function(param) {
            return {
                code: param.code,
                message: param.message,
                isError: true,
                data: param.data || {}
            };
        },
        Success: function(param) {
            return {
                code: param.code,
                message: param.message,
                data: param.data,
                isSuccess:  true
            };
        },
        Image: function(param) {
            return {
                id: param.id,
                type: param.type,
                data: param.data
            };
        },
        Page: function(param) {
           return {
                id: param.id,
                type: param.type,
                data: param.data,
                pageNumber: param.pageNumber,
                docId: param.docId,
                isSelected: false,
                isFocused: false,
                isRendered: false,
                rotation:0,
                dimension:null,
                isValidPage: param.isValidPage,
                resolution: param.resolution,
                isThumbRendered : false,
                isThumbInRange: false,
                isPageInRange: false,
                error: {
                        THUMBNAIL: {
                                    isError : false,
                                    errorMsg: null
                                },
                        PAGE: {
                                    isError : false,
                                    errorMsg: null
                                }
                    },
                updatedDtm: param.updatedDtm,
                focus: function focus(){
                    this.isFocused = true;
                    if (!ViewerSettingService.getIsMultiThumbSelected()) {
                        this.isSelected = true;
                    }
                },
                select: function select(){
                    this.isSelected = true;
                },
                unFocus: function unFocus(){
                    this.isFocused = false;
                    if (!ViewerSettingService.getIsMultiThumbSelected()) {
                        this.isSelected = false;
                    }
                },
                deSelect: function deSelect(){
                    this.isSelected = false;
                },
                rotateCW: function rotateCW(){
                    this.rotation += 90;
                    if(this.rotation === 360){
                        this.rotation = 0;
                    }
                },
                rotateACW: function rotateCW(){
                    this.rotation -= 90;
                    if(this.rotation === -360){
                        this.rotation = 0;
                    } else if(this.rotation === -270){
                        this.rotation = 90;
                    } else if(this.rotation === -180){
                        this.rotation = 180;
                    } else if(this.rotation === -90){
                        this.rotation = 270;
                    }
                },
                setRendered: function setRendered(isRendered){
                    this.isRendered = isRendered;
                },
                getRendered: function getRendered(){
                    return this.isRendered;
                },
                setDimension: function setDimension(dim){
                    this.dimension = {
                        width: dim.width,
                        height: dim.height
                    };
                },
                getDimension: function getDimension(){
                    return this.dimension;
                },
                setIsThumbRendered: function setIsThumbRendered(isRendered){
                    this.isThumbRendered = isRendered;
                },
                getIsThumbRendered: function getIsThumbRendered(){
                    return this.isThumbRendered;
                },
                getErrorMessage: function getErrorMessage() {
                    return this.error;
                },
                setErrorMessage: function setErrorMessage(error) {
                    if (error.data.type === viewerConst.displayType.THUMBNAIL) {
                        this.error.THUMBNAIL.isError = true;
                        this.error.THUMBNAIL.errorMsg = error.message;
                    } else {
                        this.error.PAGE.isError = true;
                        this.error.PAGE.errorMsg = error.message;
                    }
                },
                resetErrorMessage : function resetErrorMessage(type) {
                    if (type === viewerConst.displayType.THUMBNAIL) {
                        this.error.THUMBNAIL.isError = false;
                        this.error.THUMBNAIL.errorMsg = "";
                    } else {
                        this.error.PAGE.isError = false;
                        this.error.PAGE.errorMsg = "";
                    }
                }
            };
        },
        Document:  function(param) {
            return {
                id: param.id,
                name: param.name,
                pages: param.pages,
                isSelected: param.isSelected,
                isFocused: param.isFocused,
                isValidDoc : param.isValidDoc,
                updatedDtm: param.updatedDtm,
                status: param.status,
                getPageById: function(pageId) {
                    return _.where(this.pages, {'id': pageId})[0];
                },
                getPageByIndex: function(pageIndex) {
                    return this.pages[pageIndex];
                },
                getPageByPageNumber: function(pageNumber) {
                    return _.where(this.pages, {'pageNumber' : parseInt(pageNumber)})[0];
                },
                focusPageByIndex: function focusPageByIndex(index) {
                    var focusedPage = this.getFocusedPage();
                    if (focusedPage) {
                        focusedPage.unFocus();
                    }
                    this.pages[index].focus();
                },
                focusPageById: function focusPageById(pageId) {
                    var focusedPage = this.getFocusedPage();
                    if (focusedPage) {
                        focusedPage.unFocus();
                    }
                    this.getPageById(pageId).focus();
                },
                getFocusedPage: function getFocusedPage() {
                    //TODO: optimize this to avoid complete loop
                    return _.where(this.pages, 'isFocused')[0];
                },
                getSelectedPages : function getSelectedPages() {
                    return _.where(this.pages, 'isSelected');
                },
                focus: function focus(){
                    this.isFocused = true;
                    this.isSelected = true;
                },
                select: function select(){
                    this.isSelected = true;
                },
                unFocus: function unFocus(){
                    this.isFocused = false;
                    if (!ViewerSettingService.getIsMultiThumbSelected()) {
                        this.isSelected = false;
                    }
                    // this.isSelected = false;
                },
                deSelect: function deSelect(){
                    this.isSelected = false;
                }
            };
        },
        Annotation: function(param) {
            return {
                id : param.id,
                documentObjectId: param.documentObjectId,
                annotationType: param.annotationType,
                content: param.content,
                createdBy: param.createdBy,
                createdDtm: param.createdDtm,
                comments: param.comments,
                imageWidth: param.imageWidth,
                imageHeight: param.imageHeight,
                drawnElement: param.drawnElement,
                drawnElementFreeTransform: param.drawnElementFreeTransform
            };
        },
        Comment: function(param) {
            return {
                id : param.id,
                annotationId: param.annotationId,
                comment: param.comment,
                parentId: param.parentId,
                createdDtm : param.createdDtm,
                createdBy : param.createdBy,
                updatedDtm: param.updatedDtm ? param.updatedDtm : "",
                updatedBy: param.updatedBy ? param.updatedBy : "",
                isLeaf: param.isLeaf ? param.isLeaf : false,
                comments: param.comments ? param.comments : []
            };
        }
    };
    return model;
});
