"use strict";
uiv.service('ViewerSettingService', ['viewerConst','ViewerEvents',
    function(viewerConst, ViewerEvents) {
        //Info is there in datasource
            // currentPageId: null,
            // currentPageNo: null,
            // currentDocumentId: null,

        this.annotationTypeId = viewerConst.ANNOTATION_KEYS.POINTER;
        this.currentPageText = null;
        this.currentDocTotalPages = null;
        this.viewerState = viewerConst.VIEW_STATE.DISABLED;
        // this.viewPortWidth = 0;
        // this.viewPortHeight = 0;
        this.viewPortDimension = {width: 0, height: 0};
        this.pageFitType = viewerConst.PAGE_FIT_TYPE.FIT_TO_WIDTH;
        this.scale = 0;
        this.predefinedScale = viewerConst.COMMON_FUNCTION.RESIZE_KEYS.FIT_WIDTH;
        this.isThumbsSortable = false;
        this.isFreezed = true;
        this.isMultiThumbSelected = false;
        this.isMulitpleDocumentAdded = false;
        this.selectedThumbs = null;
        this.thumbViewLimit = 75;
        this.thumbRangeValue = 20;
        this.thumbInitialLimit = 0;
        this.pageViewLimit = 10;
        this.pageRangeValue = 5;
        this.isPageReordered = false;
        this.isThumbsPageChanged = false;
        this.setIsThumbnailVisible = false;

        this.setAnnotationTypeId = function setAnnotationTypeId(annotationTypeId) {
            this.annotationTypeId = annotationTypeId;
        };

        this.getAnnotationTypeId = function getAnnotationTypeId() {
            return this.annotationTypeId;
        };


        this.setCurrentPageText = function setCurrentPageText(currentPageText) {
            this.currentPageText = currentPageText;
        };

        this.getCurrentPageText = function getCurrentPageText() {
            return this.currentPageText;
        };

        this.setCurrentDocTotalPages = function setCurrentDocTotalPages(currentDocTotalPages) {
            this.currentDocTotalPages = currentDocTotalPages;
        };

        this.getCurrentDocTotalPages = function getCurrentDocTotalPages() {
            return this.currentDocTotalPages;
        };

        this.setViewerState = function setViewerState(viewerState) {
            this.viewerState = viewerState;
        };

        this.getViewerState = function getViewerState() {
            return this.viewerState;
        };

        this.setIsMultiThumbSelected = function (isMultiThumbSelected) {
            this.isMultiThumbSelected = isMultiThumbSelected;
        };

        this.getIsMultiThumbSelected = function () {
            return this.isMultiThumbSelected;
        };

        this.setReorderStatus = function(status) {
            this.reorderStatus = status;
        };

        this.getReorderStatus = function() {
            return this.reorderStatus;
        };

        this.setIsPageReordered = function(value) {
            this.isPageReordered = value;
        };

        this.getIsPageReordered = function() {
            return this.isPageReordered;
        };
        /**
         * [setViewPortDimension description]
         * @param {[type]} widthArg  [description]
         * @param {[type]} heightArg [description]
         */
        this.setViewPortDimension = function setViewPortDimension(widthArg, heightArg) {
            if (this.viewPortDimension.width !== widthArg || this.viewPortDimension.height !== heightArg){
                this.viewPortDimension = {width:widthArg, height: heightArg};
                // ViewerEvents.notify(ViewerEvents.VIEWER_RESIZED);
            }else{
                //No change in viewer dimenstion
            }
        };

        this.getViewPortDimension = function getViewPortDimension() {
            return this.viewPortDimension;
        };

        this.getSelectedThumbs = function getSelectedThumbs() {
            return this.selectedThumbs;
        }

        this.setSelectedThumbs = function setSelectedThumbs(thumbs) {
            this.selectedThumbs = thumbs;
        };

        this.setPageFitType = function setPageFitType(pageFitType) {
            this.pageFitType = pageFitType;
        };

        this.getPageFitType = function getPageFitType() {
            return this.pageFitType;
        };

        this.setScale = function setScale(scale) {
            this.scale = scale;
        };

        this.getScale = function getScale() {
            return this.scale;
        };

        this.setPredefinedScale = function setPredefinedScale(predefinedScale) {
            this.predefinedScale = predefinedScale;
        };

        this.getPredefinedScale = function getPredefinedScale() {
            return this.predefinedScale;
        };

        this.setIsThumbsSortable = function setThumbsSortable(isThumbsSortable) {
            this.isThumbsSortable = isThumbsSortable;
        };

        this.getIsThumbsSortable = function getThumbsSortable() {
            return this.isThumbsSortable;
        };

        this.setReorderFreezeOrUnfreezeState = function setReorderFreezeOrUnfreezeState(isFreezed) {
            this.isFreezed = isFreezed;
        };

        this.getReorderFreezeOrUnfreezeState = function getReorderFreezeOrUnfreezeState() {
            return this.isFreezed;
        };

        this.setIsThumbsPageChanged = function setIsThumbsPageChanged(isThumbsPageChanged) {
            this.isThumbsPageChanged = isThumbsPageChanged;
        };

        this.getIsThumbsPageChanged = function getIsThumbsPageChanged() {
            return this.isThumbsPageChanged;
        };

        this.setViewerSettings = function setViewerSettings(settings) {
            this.VS = settings;
        };

        this.getViewerSettings = function getViewerSettings() {
            return this.VS;
        };

        this.setPageSettings = function setPageSettings(pageSettingsObj) {
            this.pageSettings = pageSettingsObj;
        }
        this.getPageSettings = function getPageSettings() {
            return this.pageSettings;
        }

        this.getThumbViewLimit = function getThumbViewLimit() {
            return this.thumbViewLimit;
        }
        this.getInititalLimit = function getInititalLimit() {
            return this.thumbInitialLimit;
        }
        this.getThumbViewRange = function getThumbViewRange() {
            return this.thumbRangeValue;
        }

        this.getPageViewLimit = function getPageViewLimit() {
            return this.pageViewLimit;
        }
        this.getPageViewRange = function getPageViewRange() {
            return this.pageRangeValue;
        }

        this.setPreviousFocusedDoc = function setPreviousFocusedDocId(doc) {
            this.previousFocusedDoc = doc;
        };

        this.getPreviousFocusedDoc = function getPreviousFocusedDocId() {
            return this.previousFocusedDoc;
        };

        this.setShortCutFocusedPage = function setShortCutFocusedPage(page) {
            this.shortCutFocusedPage = page;
        };

        this.getShortCutFocusedPage = function getShortCutFocusedPage() {
            return this.shortCutFocusedPage;
        };

        this.setShortCutState = function setShortCutState(state) {
            this.shortCutState = state;
        };

        this.getShortCutState = function getShortCutState() {
            return this.shortCutState;
        };

        this.setPageSelectDirection = function setPageSelectDirection(direction) {
            this.pageSelectDirection = direction;
        };

        this.getPageSelectDirection = function getPageSelectDirection() {
            return this.pageSelectDirection;
        };

        this.setIsPreviousDataToClean = function setIsPreviousDataToClean(val) {
            this.isPreviousDataToClean = val;
        };

        this.getIsPreviousDataToClean = function getIsPreviousDataToClean() {
            return this.isPreviousDataToClean;
        };

        this.setIsViewerClearedForcufully = function setIsViewerClearedForcufully(val) {
            this.isViewerClearedForcufully = val;
        };

        this.getIsViewerClearedForcufully = function getIsViewerClearedForcufully() {
            return this.isViewerClearedForcufully;
        };

        this.setSelectedView = function setSelectedView(val) {
            this.lastSelectedView = this.selectedView;
            this.selectedView = val;
        };

        this.getSelectedView = function getSelectedView() {
            return this.selectedView;
        };

        this.getLastSelectedView = function getLastSelectedView() {
            return this.lastSelectedView;
        };

        this.setIsThumbnailPaneVisible = function setIsThumbnailPaneVisible(val) {
            this.isThumbnailPaneVisible = val;
        };

        this.getIsThumbnailPaneVisible = function getIsThumbnailPaneVisible() {
            return this.isThumbnailPaneVisible;
        };
        
        this.getViewerMenuNavigationMode = function() {
            return this.getViewerSettings().viewerNavigationMenuMode;
        };

        this.setLastVisitedMenuSize = function setLastVisitedMenuSize(size) {
            this.menuSize = size;
        };

        this.getLastVisitedMenuSize = function setLastVisitedMenuSize() {
            return this.menuSize;
        };

        // var viewerSettings = {
        //     annotationTypeId: viewerConst.ANNOTATION_KEYS.POINTER
        // };
        // return viewerSettings;
    }
]);
