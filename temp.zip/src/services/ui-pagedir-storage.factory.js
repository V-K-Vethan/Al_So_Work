uiv.factory('pageDirectiveElementStore', [function() {
    var storeObj,
    storeArr,
    name,
    size;

    var Storage = function(r_name, r_size) {
        name = r_name;
        size = r_size;
        init();
    };

    Storage.prototype.addElement = function(id, pageDirElement) {
        storeObj[id] = pageDirElement;
        storeArr.push(storeObj[id]);
    };

    Storage.prototype.getAllPageDirElements = function() {
        return storeArr;
    };

    Storage.prototype.getPageDirObjects = function() {
        return storeObj;
    };

    Storage.prototype.getPageDirElementById = function(pageId) {
        return storeObj[pageId];
    };

    Storage.prototype.deletePageDirElement = function(pageId) {
        delete storeObj[pageId];

        var toDeleteIndex = storeArr.map(function(obj) { return obj.attr('pageid'); }).indexOf(pageId);
        if (toDeleteIndex !== -1) {
            storeArr.splice(toDeleteIndex, 1);
        }
    };

    Storage.prototype.resetAllPageDirElements = function() {
        storeObj = {};
        storeArr = [];
    };

    Storage.prototype.resetPageDirElements = function() {
        storeObj = {};
        storeArr = [];
    };

    var init = function() {
        storeObj = {};
        storeArr = [];
    };

    return Storage;
}]);
