uiv.factory('ViewerAnnotationStore', [function() {
    var storeObj,
        storeArr,
        name,
        size;

    var Storage = function(r_name, r_size) {
        name = r_name;
        size = r_size;
        init();
    };

    Storage.prototype.addAnnotation = function(annotationModel, isPushTop) {

        var index = storeArr.map(function(obj) { return obj.id; }).indexOf(annotationModel.id);
        if (index === -1) {
            storeObj[annotationModel.id] = annotationModel;
            //New annotation should be pushed to the beginning whereas existing annotation comes in the sorted order(descending)
            isPushTop ? storeArr.unshift(storeObj[annotationModel.id]) : storeArr.push(storeObj[annotationModel.id]);
        }
    };

    Storage.prototype.getAnnotations = function() {
        return storeArr;
    };

    Storage.prototype.getAnnotationById = function(annotationId) {
        return _.filter(storeArr, function (obj) { return obj.id === annotationId; });
    };

    Storage.prototype.getAnnotationByPageId = function(pageId) {
        return _.filter(storeArr, function (obj) { return obj.documentObjectId === pageId; });
    };

    Storage.prototype.deleteAnnotation = function(id) {
        delete storeObj[id];

        var toDeleteIndex = storeArr.map(function(obj) { return obj.id; }).indexOf(id);
        if (toDeleteIndex !== -1) {
            storeArr.splice(toDeleteIndex, 1);
        }
    };

    Storage.prototype.resetAnnotations = function() {
        storeObj = {};
        storeArr = [];
    };

    Storage.prototype.addReplyToComment = function(responeData) {
        addObjectToArray(storeArr, responeData.parentId, responeData);
    };

    Storage.prototype.deleteComment = function(comment) {
        deleteCommentFromArray(storeArr, comment.parentId, comment.id);
    };

    var init = function() {
        storeObj = {};
        storeArr = [];
    };

    var addObjectToArray = function(obj, commentId, commentObj) {
        for (var k in obj)
        {
            if (typeof obj[k] == "object" && obj[k] !== null) {
                if(obj[k].id == commentId) {
                    if(!obj[k].comments) {
                        obj[k].comments = [];
                    }
                    obj[k].comments.push(commentObj);
                    obj[k] = angular.copy(obj[k]);
                    break;
                }
                if(k != "drawnElement" && k != "drawnElementFreeTransform") addObjectToArray(obj[k], commentId, commentObj);
            }else {
                //do something....
            }
        }
    };

    var deleteCommentFromArray = function(obj, parentId, commentId) {
        for (var k in obj)
        {
            if (typeof obj[k] == "object" && obj[k] !== null && k != "drawnElement" && k != "drawnElementFreeTransform") {
                if(obj[k].id == parentId) {
                    var index = getObjectIndexInArray(obj[k].comments, commentId);
                    obj[k].comments.splice(index,1);
                    obj[k] = angular.copy(obj[k]);
                    break;
                }
                deleteCommentFromArray(obj[k], parentId, commentId);
            }else {
                //do something....
            }
        }
    };

    var getObjectIndexInArray = function(array, id) {
        for(var i=0; i<array.length; i++) {
            if(array[i].id == id) return i;
        }

    }

    return Storage;
}]);
