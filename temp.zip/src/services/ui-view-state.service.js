"use strict";
uiv.service('ViewState', ['viewerConst', function(viewerConst) {

    this.currentState = viewerConst.VIEW_STATE.DISABLED;
    this.stateMatrix = [
        /*NEXT_PAGE*/       [ false , true,  true,  false, true , true ],
        /*PREV_PAGE*/       [ false , true,  true,  false, true , true ],
        /*PAGE_NO*/         [ false , true,  true,  false, true , true ],
        /*ZOOM_IN*/         [ false , true,  true,  false, true , true ],
        /*ZOOM_OUT*/        [ false , true,  true,  false, true , true ],
        /*PREDEFINED_ZOOM*/ [ false , true,  true,  false, true , true ],
        /*BEST_FIT*/        [ false , true,  true,  false, true , true ],
        /*FIT_TO_WIDTH*/    [ false , true,  true,  false, true , true ],
        /*ANTIALIAS*/       [ false , true,  true,  false, true , true ],
        /*THUMBNAIL*/       [ false , true,  true,  false, true , true ],
        /*ROTATE_LEFT*/     [ false , true,  true,  false, false, true ],
        /*ROTATE_RIGHT*/    [ false , true,  true,  false, false, true ],
        /*CUT*/             [ false , true,  true,  false, false, true ],
        /*COPY*/            [ false , true,  true,  false, false, true ],
        /*PASTE*/           [ false , true,  true,  false, true , true ],
        /*SPLIT*/           [ false , true,  true,  false, false, true ],
        /*DELETE*/          [ false , true,  true,  false, false, true ],
        /*FREEZE_REORDER*/  [ false , true,  true,  false, false, true ],
        /*DOWNLOAD*/        [ false , true,  true,  false, false, false],
        /*ANNOTATION*/      [ false , true,  true,  false, false, false],
        /*DEFAULT_THUMB*/   [ false , false, false, true , false, true ],
        /*DEFAULT_PAGE*/    [ false , false, false, true , false, true ],
        /*COMMENT*/         [ false , true,  true,  false, false, true ],
        /*META_DATA*/       [ false , true,  true,  true,  true,  true ],
    ];

    this.getUIElementState = function getUIElementState(uiElementId) {
        return this.stateMatrix[uiElementId][this.currentState];
    };

    // viewState.getUIElementState(constant.UI_ELEMENT.NEXT_PAGE);

}]);
