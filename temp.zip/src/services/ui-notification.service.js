"use strict";

uiv.service('ViewerNotification', ['viewerConst','ViewerEvents', function(viewerConst, ViewerEvents) {

    // format of errorObj
    // return {
    //     code: param.code,
    //     message: param.message,
    //     isError: true
    // };

    this.notificationObj = {
                type : viewerConst.NOTIFICATION_TYPE.DEFAULT,
                message: ''
    };

    this.getCurrentNotification = function getCurrentNotification() {
        return this.notificationObj;
    };

    this.showError = function showError(errorObj) {
        this.notificationObj.type = viewerConst.NOTIFICATION_TYPE.ERROR;
        this.notificationObj.message = errorObj.message;
        ViewerEvents.notify(ViewerEvents.SHOW_NOTIFICATION);
    };
    // format of successObj
    // return {
    //     code: param.code,
    //     message: param.message,
    //     data: param.data,
    //     isSuccess:  true
    // };
    this.showSuccess = function showError(successObj) {
        this.notificationObj.type = viewerConst.NOTIFICATION_TYPE.SUCCESS;
        this.notificationObj.message = successObj.message;
        ViewerEvents.notify(ViewerEvents.SHOW_NOTIFICATION);
    };

    this.showProgress = function showProgress(progressObj) {
        this.notificationObj.type = viewerConst.NOTIFICATION_TYPE.PROGRESS;
        this.notificationObj.message = progressObj.message;
        ViewerEvents.notify(ViewerEvents.SHOW_NOTIFICATION);
    };
}]);
