uiv.factory('ViewerImageStore', [function() {
    var storeObj = {},
        storeArr = [],
        name,
        size,
        zoomScale = 1,
        zoomScaleVariation = 0.2,
        minZoomScale = 0.2,
        predefinedZoom = "";

    var Storage = function(r_name, r_size) {
        name = r_name;
        size = r_size;
        init();
    };

    Storage.prototype.addData = function(id, data) {
        if (isLimitExceeded()) {
            shiftData();
        }

        //push data
        storeObj[id] = data;
        storeArr.push(storeObj[id]);
    };

    Storage.prototype.getData = function(id) {
        return storeObj[id];
    };

    Storage.prototype.getAllData = function() {
        return storeArr;
    };

    Storage.prototype.isDataAvailable = function(id) {
        return !!storeObj[id];
    };

    Storage.prototype.empty = function() {
        storeObj = {};
        storeArr = [];
    };

    var shiftData = function() {
        delete(storeObj[storeArr.shift()]);
    };

    var isLimitExceeded = function() {
    	return storeArr.length >= size;
    };

    var init = function() {
        storeObj = {};
        storeArr = [];
    };

    return Storage;
}]);
