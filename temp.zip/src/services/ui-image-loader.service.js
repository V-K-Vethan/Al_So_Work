uiv.service('ViewerImageLoader', ['$q', function($q) {
    var deferred = {},
        totalThread = 0,
        imageQueue = [],
        engagedThreads = 0,
        imageAPI,
        pageStore,
        thumbStore;

    this.cancelOldThumbRequest = function(listOfVisibleKeysArr) {
        for (var key in deferred) {
            if (key.indexOf(':THUMBNAIL') !== -1) {
                if (!_.contains(listOfVisibleKeysArr, key)) {
                    deferred[key].reject('reject');
                }
            }
        }
    };

    this.cancelOldPageRequest = function(listOfVisibleKeysArr) {
        for (var key in deferred) {
            if (key.indexOf(':PAGE') !== -1) {
                if (!_.contains(listOfVisibleKeysArr, key)) {
                    deferred[key].reject('reject');
                }
            }
        }
    };
    this.loadPage = function(imageId, imageType, status, isForcefully, isPriority) {
        var key = imageId + ":" + imageType;
        if (!deferred[key]) {
            deferred[key] = $q.defer();
            //add to queue
            if (isForcefully) {
                if (isPriority) {
                    imageQueue.splice(0, 0, {
                        id: imageId,
                        type: imageType,
                        status: status
                    });
                } else {
                    imageQueue.splice(2, 0, {
                        id: imageId,
                        type: imageType,
                        status: status
                    });
                }
            } else {
                imageQueue.push({
                    id: imageId,
                    type: imageType,
                    status: status
                });
            }
        }
        //execute
        execute();

        return deferred[key].promise;
    };

    this.setThread = function(totalThreadArg) {
        totalThread = totalThreadArg;
    };

    this.setImageAPI = function(imageAPIArg) {
        imageAPI = imageAPIArg;
    };

    this.getImageAPI = function(id, type) {
        return imageAPI(id, type);
    };

    this.setPageStore = function(pageStoreArg) {
        pageStore = pageStoreArg;
    };

    this.setThumbStore = function(thumbStoreArg) {
        thumbStore = thumbStoreArg;
    };

    this.empty = function() {
        deferred = {};
        totalThread = 0;
        imageQueue = [];
        engagedThreads = 0;
    };
    var execute = function(type) {
        if ((imageQueue.length > 0) && (engagedThreads < totalThread)) {
            engagedThreads++;
            var imageObj = imageQueue.shift();
            var key = imageObj.id + ":" + imageObj.type;
            imageAPI(imageObj.id, imageObj.type, imageObj.status).then(function(result) {
                //store
                deferred[key].resolve(result);
                delete(deferred[key]);
                engagedThreads--;
                execute();
            }, function(error) {
                deferred[key].reject(error);
                delete(deferred[key]);
                engagedThreads--;
                execute();
            });
        } else {
            //console.info("ui-image-loader.service.js : 30 :  threads full");
        }
    };
}]);
