uiv.service('PageRenderService', ['ViewerSettingService',
    function(ViewerSettingService) {
        var vm = this;

        /**
        * [getPrintedCanvas description]
        * @return {[type]} image, pageSettings [description]
        */
        this.getPrintedCanvas = function getPrintedCanvas(image, pageSettings) {
            var canvas = document.createElement('canvas');
            var context = canvas.getContext("2d");

            //update canvas size
            canvas.width = ((pageSettings.isPortrait) ? pageSettings.imageWidth : pageSettings.imageHeight) * pageSettings.scale;
            canvas.height = ((pageSettings.isPortrait) ? pageSettings.imageHeight : pageSettings.imageWidth) * pageSettings.scale;
            //Position for rotation
            switch (pageSettings.rotation) {
                case 0:
                    context.translate(0, 0);
                    break;
                case 90:
                    context.translate(canvas.width, 0);
                    break;
                case 270:
                    context.translate(0, canvas.height);
                    break;
                case 180:
                    context.translate(canvas.width, canvas.height);
                    break;
            }

            //Apply canvas properties
            context.rotate(pageSettings.rotation * Math.PI / 180);
            context.scale(pageSettings.scale, pageSettings.scale);
            context.drawImage(image,0,0, pageSettings.imageWidth ,pageSettings.imageHeight)

            return canvas;
        };

        /**
        * [updateContainerDimension description]
        * @return {[type]} [update size of all the containers as per canvas]
        */
        this.updateContainerDimension = function updateContainerDimension(pageScope, pageContainer, container, svgContainer) {
            var styleCss;
            // if (!pageScope.page.getRendered()) {
                var pageDimension = pageScope.page.getDimension();
                if (pageDimension !== null) {
                    var pageSettings = pageScope.settings || ViewerSettingService.getPageSettings();
                    pageSettings.scale = ViewerSettingService.getScale();
                    pageSettings.isPortrait = pageScope.page.rotation % 180 == 0;
                    if (pageSettings) {
                        var W = ((pageSettings.isPortrait) ? pageSettings.imageWidth : pageSettings.imageHeight) * pageSettings.scale;
                        var H = ((pageSettings.isPortrait) ? pageSettings.imageHeight : pageSettings.imageWidth) * pageSettings.scale;
                        styleCss = "width:" + W + "px;" + "height:" + H + "px;";
                        container.setAttribute("style", styleCss);
                        //creates smaller svg if page is not valid
                        if(pageScope.page.isValidPage) {
                            svgContainer.setAttribute("style", styleCss);
                        }
                        pageContainer.setAttribute("style", styleCss);
                    } else {
                        console.log("page settings not available");
                    }
                }
            // }
        };
    }
]);
