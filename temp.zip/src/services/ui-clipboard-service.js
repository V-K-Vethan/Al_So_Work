"use strict";
uiv.service('ViewerClipboardService', ['viewerConst','ViewerEvents',
    function(viewerConst, ViewerEvents) {

        this.setCutDocuments = function setCutDocuments(docs) {
            this.cutDocuments = docs;
        }
        this.getCutDocuments = function getCutDocuments() {
            return this.cutDocuments;
        };

        this.setCutPages = function setCutPages(pages) {
            this.cutPages = pages;
        }
        this.getCutPages = function getCutPages() {
            return this.cutPages;
        };
    }
]);
