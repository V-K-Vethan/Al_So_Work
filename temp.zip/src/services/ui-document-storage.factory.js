uiv.factory('ViewerDocumentStore', ['ViewerModel','$timeout', 'ViewerUtilitis', 'ViewerClipboardService', 'ViewerSettingService', function(ViewerModel, $timeout, ViewerUtilitis, ViewerClipboardService, ViewerSettingService) {

    var that = this,
        storeObj = {},
        storeArr = [],
        name,
        size,
        selectedDocumentId,
        tempDocumentId,
        thumbnailViewContainer,
        pageViewContainer,
        focusedPageId,
        pageSettings,
        selectedThumb = [],
        cutOrCopiedThumbs = [],
        tempStoreArr = [],
	    thumbsForReorder = [],
        focusedPageId,
        reorderModel,
        diffOfThumbsForReorder,

        //TODO: service(ui-viewState.service) to maintain view state
        lastFocusedDoc,
        lastFocusedThumb,
        controls = {
            nextPage: true,
            prevPage: true,
            pageNo: true,
            zoomIn: true,
            zoomOut: true,
            predefinedZoom: true,
            bestFit: true,
            fitToWidth: true,
            antialias: true,
            thumbNail: true,
            rotateLeft: true,
            rotateRight: true,
            cut: true,
            copy: true,
            paste: true,
            split: true,
            delete: true,
            freezeReorder: true,
            download: true,
            selectAnnotation: true,
            underline: true,
        };

    var DocStorage = function(r_name, r_size) {
        name = r_name;
        size = r_size;
        init();
    };

    DocStorage.prototype.addData = function(id, data, index) {
        if (isLimitExceeded()) {
            shiftData();
        }

        //push data
        storeObj[id] = data;
        if (typeof index === 'number') {
            storeArr.splice(index, 0, storeObj[id]);
            return;
        }
        storeArr.push(storeObj[id]);
    };

    DocStorage.prototype.clearData = function() {
        storeArr = [];
        storeObj = {};
    };

    DocStorage.prototype.addMultipleData = function(data) {
        this.clearData();
        _.each(data, function(doc) {
            storeObj[doc.id] = doc;
            doc.pageCount = doc.pages.length;
        })
        storeArr = data;
    };

    DocStorage.prototype.removeData = function(deletedDoc) {
        var deletedDocIndex = this.getDocIndexById(deletedDoc.id),
            totalDocsCount = this.getDocuments().length;

        if (deletedDoc.isFocused) {
            newFocusedDoc = (deletedDocIndex + 1 === totalDocsCount) ? this.getPreviousDocument() : this.getNextDocument();
        } else {
            newFocusedDoc = this.getFocusedDocument();
        }

        //remove document from documents array in document store
        delete storeObj[deletedDoc.id];
        storeArr.splice(deletedDocIndex, 1);
        return newFocusedDoc;
    };

    DocStorage.prototype.getData = function(id) {
        return storeObj[id];
    };

    DocStorage.prototype.getDocuments = function() {
        return storeArr;
    };

    DocStorage.prototype.getDocIndexById = function(id) {
        return _.indexOf(storeArr, storeObj[id]);
    };

    DocStorage.prototype.isDataAvailable = function(id) {
        return !!storeObj[id];
    };

    DocStorage.prototype.updateData = function(obj) {
        storeObj[obj.id] = obj;
    };

    DocStorage.prototype.empty = function() {
        storeObj = {};
        storeArr = [];
    };

    /**
     * provides collection of selected page objects
     * @return {[page object]} [description]
     */
    DocStorage.prototype.getSelectedPages = function() {
        var docs = [];
        var selectedDocs = getAllSelectedDocs();
        _.each(selectedDocs, function(obj) {
            docs.push(new ViewerModel.Document({
                id: obj.id,
                pages: _.where(obj.pages, 'isSelected')
            }));
        });
        //TODO: need to change the return as per description.
        return docs;
    };

    DocStorage.prototype.getSelectedPagesByDocId = function(docId) {
        return _.where(storeObj[docId].pages, 'isSelected');
    };

    DocStorage.prototype.setSelectedThumb = function(currDocId, oldDocId, pageId, isMultiThumbSelected, isReorder) {
        var currDoc = getDocById(currDocId);
        var oldDoc = getDocById(oldDocId);
        selectedDocumentId = currDocId;
        var pageObj = currDoc.getPageById(pageId);
        if (!isMultiThumbSelected) {
            isNewPageSelectedAfterCut = true;
            unselectAllThumbs();
            focusSelectedPage(currDoc, pageId);
        } else {
            if (currDocId !== oldDocId) {
                this.setFocusedDocument(currDocId, oldDocId);
            } else {
                currDoc.getFocusedPage().unFocus();
            }
            if (pageObj) {
                if (!isReorder) {
                    pageObj.isSelected = !pageObj.isSelected;
                }
                pageObj.focus();
                currDoc.isSelected = (currDoc.getSelectedPages().length) ? true : false;
            }
        }
        focusedPageId = pageId;
        if (pageObj) {
            if (pageObj.isSelected) {
                manageSelectedPageIds(isMultiThumbSelected, pageId);
            } else {
                removePageIdFromSelectedList(pageObj.id);
            }
        }
    };

    DocStorage.prototype.deleteDocumentPages = function(docs, updatedDocs) {
        var allPages = [];
        var focusedDocObj;
        var newFocusedPageObj;
        _.each(docs, function(doc, docIdex) {
            _.each(doc.pages, function(page, pageIndex) {
                if (page.isFocused) {
                    focusedDocObj = getDocById(page.docId);
                    var focusedPageIndex = _.indexOf(focusedDocObj.pages, page);
                    if (focusedPageIndex === (focusedDocObj.pages.length - 1)) {
                        newFocusedPageObj = focusedDocObj.pages[focusedPageIndex - 1];
                    } else {
                        newFocusedPageObj = focusedDocObj.pages[focusedPageIndex + 1];
                    }
                    newFocusedPageObj.focus();
                    manageSelectedPageIds(false, newFocusedPageObj.id);
                    //shortcut selections
                    ViewerSettingService.setShortCutFocusedPage(newFocusedPageObj);
                    ViewerSettingService.setPreviousFocusedDoc(focusedDocObj);
                    ViewerSettingService.setShortCutState('ctrl');
                }
                allPages = storeObj[doc.id].pages;
                var deleteIndex = _.indexOf(allPages, page);
                allPages.splice(deleteIndex, 1);
            });
            resetPageNumbersInOrder(allPages);
            var modifiedDoc = updatedDocs.data[docIdex].plain();
            updateDocuments({id: modifiedDoc.id, updatedDtm: modifiedDoc.modifiedDtm});
        });
    };

    DocStorage.prototype.undoCutThumbs = function() {
        undoCutThumbs();
    };

    DocStorage.prototype.getCutThumbsList = function() {
        return cutOrCopiedThumbs;
    };

    DocStorage.prototype.setThumbEditAction = function(action) {
        undoCutThumbs();
        var focusedDoc = getDocById(this.getSelectedPages()[0].id);
        _.each(thumbsForReorder, function(id) {
            var pageObj = focusedDoc.getPageById(id);
            if (!pageObj) { return; }
            pageObj.action = action;
            pageObj.isSelected = true;
            if (pageObj.action === 'cut') {
                cutOrCopiedThumbs.push(pageObj);
            }
        });
        if (action === 'cut') {
            tempStoreArr = $.extend(true, [], storeArr);
            ViewerClipboardService.setCutDocuments(focusedDoc);
            ViewerClipboardService.setCutPages(cutOrCopiedThumbs);
        } else {
            ViewerClipboardService.setCutDocuments(null);
            //deselects all selected page after paste and only pasted pages will be selected and focused
            deSelectPages();
        }
    };

    DocStorage.prototype.setFocusedDocument = function(newDocId, oldDocId) {
        //Update old doc property
        if (oldDocId) {
            var oldDoc = getDocById(oldDocId);
            if (oldDoc) {
                oldDoc.unFocus();
                var focusedPage = oldDoc.getFocusedPage();
                if (focusedPage) {
                    focusedPage.unFocus();
                }
            }
        }
        selectedDocumentId = newDocId;
        var newDoc = getDocById(newDocId);
        newDoc.focus();
        return newDoc;
    };

    DocStorage.prototype.setFocusedPage = function setFocusedPage(newFocusedPageObj, lastFocusedPageObj) {
        if (lastFocusedPageObj) {
            lastFocusedPageObj.unFocus();
            removePageIdFromSelectedList(lastFocusedPageObj.id);
        }
        if (newFocusedPageObj) {
            newFocusedPageObj.focus();
            var newDoc = getDocById(newFocusedPageObj.docId);
            if (newDoc) {
                newDoc.focus();
            }
            manageSelectedPageIds(true, newFocusedPageObj.id);
        }
    };

    DocStorage.prototype.getFocusedPageId = function() {
        return focusedPageId;
    };

    DocStorage.prototype.setFocusedPageId = function(pageId) {
        focusedPageId = pageId;
    };

    DocStorage.prototype.setReorderedPage = function(pages) {
        var focusedDoc = this.getFocusedDocument();
        _.each(pages, function(page) {
            var pageObj = _.where(focusedDoc.pages, {'id': page.id})[0];
            if (pageObj) {
                pageObj.pageNumber = page.sequenceNumber;
            }
        });
        storeObj[focusedDoc.id].pages = _.sortBy(focusedDoc.pages, 'pageNumber');
    };

    DocStorage.prototype.getFocusedDocument = function () {
        return storeObj[selectedDocumentId];
    };

    DocStorage.prototype.getPageById = function (pageId) {
        return getPageById(pageId);
    };

    DocStorage.prototype.setPropertyToFocusedThumbObj = function(thumbId, obj) {
        var thumbObj = _.where(_.where(storeArr, 'isFocused')[0].pages, {'id' : thumbId})[0];
        for (var key in obj) {
            thumbObj[key] = obj[key];
        }
    };

    DocStorage.prototype.getFocusedDocIndex = function () {
        var focusedDoc = this.getFocusedDocument();
        return _.indexOf(storeArr, focusedDoc);
    };

    DocStorage.prototype.getPreviousDocument = function () {
        return storeArr[this.getFocusedDocIndex() - 1];
    };

    DocStorage.prototype.getNextDocument = function () {
        return storeArr[this.getFocusedDocIndex() + 1];
    };

    //finds next page by pageId
    DocStorage.prototype.getNextPage = function (focusedPage) {
        var thumbObj = focusedPage;
        var focusedDoc = getDocById(focusedPage.docId);
        var totalPageCount = focusedDoc.pages.length;
        var focusedThumbIndex = _.indexOf(focusedDoc.pages, thumbObj);
        if (focusedThumbIndex < totalPageCount - 1) {
            return  focusedDoc.pages[focusedThumbIndex + 1];
        }
        var focusedDocIndex = _.indexOf(storeArr, focusedDoc);
        if (focusedDocIndex  < storeArr.length - 1) {
            var nextDocument = storeArr[focusedDocIndex + 1];
            return  nextDocument.pages[0];
        }
        return null;
    };
    //find prev page by pageId
    DocStorage.prototype.getPreviousPage = function (focusedPage) {
        var thumbObj = focusedPage;
        var focusedDoc = this.getData(focusedPage.docId);
        var focusedThumbIndex = _.indexOf(focusedDoc.pages, thumbObj);
        if (focusedThumbIndex > 0) {
            return focusedDoc.pages[focusedThumbIndex - 1];
        } else {
            var focusedDocIndex = _.indexOf(storeArr, focusedDoc);
            if (focusedDocIndex > 0) {
                var previousDocument = storeArr[focusedDocIndex -1];
                return previousDocument.pages[previousDocument.pages.length - 1];
            } else {
                return;
            }
        }
    };

    //TODO: analyse more on this
    DocStorage.prototype.validateEditOperationOnThumbSelection = function() {
        var canEdit = true;
        var selectedDocs = _.where(this.getDocuments(), 'isSelected');
        if (selectedDocs.length) {
            _.each(selectedDocs, function(doc) {
                var thumbnails = doc.pages;
                var isAllThumbSelected = (_.where(thumbnails, 'isSelected').length === thumbnails.length) ? true : false;
                if (thumbnails.length === 1 && canEdit) {
                    canEdit = false;
                }
                if (isAllThumbSelected) {
                    canEdit = false;
                }
            });
        } else {
            canEdit = false;
        }
        return canEdit;
    };

    //TODO: need to deprecate
    DocStorage.prototype.setPageSettings = function(settings) {
        pageSettings = settings;
    };
    //TODO: need to deprecate
    DocStorage.prototype.getPageSettings = function() {
        return pageSettings;
    };
    //TODO: need to deprecate
    DocStorage.prototype.getButtonControls = function (rPageViewContainer) {
        return controls;
    };

    DocStorage.prototype.getPagesForReorder = function() {
        return thumbsForReorder;
    };

    var isCutThumbNotAvailableInList = false;
    DocStorage.prototype.removeCutDocumentsFromList = function() {
        var cutDocument = ViewerClipboardService.getCutDocuments();
        var cutThumbIndex = storeArr.indexOf(cutDocument);
        if (isCutThumbNotAvailableInList) {
            storeArr.splice(storeArr.indexOf(cutDocument), 1);
            delete storeObj[cutDocument.id];
            isCutThumbNotAvailableInList = false;
        }
    };

    DocStorage.prototype.reorderPages = function (data, reorderPages) {
        diffOfThumbsForReorder = _.difference(thumbsForReorder, reorderPages);
        reorderModel = angular.copy(data);
        var toThumbIndex = data.toThumb;

        //for pages which has been cut out of available documents
        if (data.fromDoc === -1) {
            tempStoreArr = $.extend(true, [], storeArr);
            isCutThumbNotAvailableInList = true;
            var cutDocument = ViewerClipboardService.getCutDocuments();
            storeArr.push(cutDocument);
            storeObj[cutDocument.id] = cutDocument;
            data.fromDoc = storeArr.indexOf(cutDocument);
        }

        //for cut paste, else part for drag and drop
        if (reorderPages) {
            if ((data.fromDoc === data.toDoc) && (data.toThumb > data.fromThumb)) {
                toThumbIndex = toThumbIndex - 1;
            }
            thumbsForReorder = reorderPages;
        } else {
            tempStoreArr = $.extend(true, [], storeArr);

            data.toThumb = (data.toThumb === 0) ? 0 : _.where(storeArr[data.toDoc].pages, storeArr[data.toDoc].viewablePages[data.toThumb -1 ])[0].pageNumber;
            data.fromThumb = _.where(storeArr[data.fromDoc].pages, storeArr[data.fromDoc].viewablePages[data.fromThumb -1 ])[0].pageNumber;
            toThumbIndex = data.toThumb;
            if ((data.fromDoc === data.toDoc) && (data.toThumb > data.fromThumb)) {
                toThumbIndex = toThumbIndex + data.selectedPages.length - 1;
            }
        }
       for (var i = 0; i < data.selectedPages.length; i++) {
           var obj = {};
           for (var j = 0; pages = storeArr[data.fromDoc].pages, j < pages.length; j++){
               if (pages[j].id == thumbsForReorder[i]) {
                   obj = storeArr[data.fromDoc].pages.splice(j,1);
                   break;
               }
           }
           if (obj[0]) {
               obj[0].docId = storeArr[data.toDoc].id;
               storeArr[data.toDoc].pages.splice(toThumbIndex,0,obj[0]);
               if ((data.fromDoc !== data.toDoc) || (data.fromDoc === data.toDoc) && (data.toThumb <= data.fromThumb) ) {
                   toThumbIndex++;
               }
           }
       }
       if (data.fromDoc == data.toDoc) {
           resetPageNumbersInOrder(storeArr[data.fromDoc].pages, reorderModel);
       } else {
           resetPageNumbersInOrder(storeArr[data.fromDoc].pages, reorderModel);
           resetPageNumbersInOrder(storeArr[data.toDoc].pages, reorderModel);
       }
       var focusedPage = storeArr[data.toDoc].getPageById(thumbsForReorder[thumbsForReorder.length - 1]);
       var focusedPageId = focusedPage ? focusedPage.id : this.getFocusedDocument().getFocusedPage().id;
       this.setSelectedThumb(storeArr[data.toDoc].id, storeArr[data.fromDoc].id, focusedPageId, true, true);
   };

    DocStorage.prototype.undoReorderChanges = function () {
        storeArr = tempStoreArr;
        _.each(storeArr, function(doc) {
            storeObj[doc.id] = doc;
        });
        var fromDocObj = storeArr[reorderModel.fromDoc];
        var toDocObj = storeArr[reorderModel.toDoc];
        selectedDocumentId = fromDocObj ? fromDocObj.id : toDocObj.id;
        var focusedPageObj = fromDocObj ? fromDocObj.getFocusedPage() : toDocObj.pages[reorderModel.toThumb - 1];
        undoCutThumbs();
        return {'fromDocObj' : fromDocObj, 'toDocObj': toDocObj, 'focusedPageObj' : focusedPageObj};
    };

    DocStorage.prototype.updateDocuments = function (updatedDoc) {
        updateDocuments(updatedDoc);
    };


    DocStorage.prototype.clearSelectedThumbs = function () {
        unselectAllThumbs();
    };

    DocStorage.prototype.manageSelectedPageIds = function(isMultiSelected, pageId) {
        manageSelectedPageIds(isMultiSelected, pageId);
    };

    DocStorage.prototype.getNextDocId = function(docId) {
        var curDocIndex = this.getFocusedDocIndex();
        if (storeArr[curDocIndex + 1]) {
            return storeArr[curDocIndex + 1].id;
        }
    };

    DocStorage.prototype.getPrevDocId = function(docId) {
        var curDocIndex = this.getFocusedDocIndex();
        if (storeArr[curDocIndex - 1]) {
            return storeArr[curDocIndex - 1].id;
        }
    };

    //**********************************************Private functions *******************************************//
    var getPageById = function(pageId) {
        var pageObj;
        _.each(storeArr, function(doc) {
            var page = _.where(doc.pages, {'id' : pageId})[0];
            if (page) {
                pageObj = page;
            }
        });
        return pageObj;
    };

    var deSelectPages = function deSelectPages() {
        _.each(diffOfThumbsForReorder, function(pageId) {
            var page = getPageById(pageId)
            if (page) {
                page.deSelect();
            }
        });
    };

    var updateClonedStoreArray = function(docs) {
        for (var i = 0; i < docs.length; i++) {
            var obj = _.where(cloneStoreArr, {'id': docs[i].id})[0];
            obj.pageCount = obj.pageCount - docs[i].pages.length;
        }
    };

    var removePageIdFromSelectedList = function(pageId) {
        var thumbRemvIndex = _.indexOf(thumbsForReorder, pageId);
        if (thumbRemvIndex !== -1) {
            thumbsForReorder.splice(thumbRemvIndex, 1);
        }
    };

    var undoCutThumbs = function() {
        _.each(storeArr, function (obj) {
            _.each(obj.pages, function(page) {
                page.action = undefined; // clears action from all thumb obj
            });
        });
        cutOrCopiedThumbs = [];
        ViewerClipboardService.setCutDocuments(null);
    };


    var updateDocuments = function(updatedDoc) {
        var docObj = getDocById(updatedDoc.id);
        if (docObj) {
            docObj = ViewerUtilitis.mergeRecursive(docObj, updatedDoc);
        }
    };

    var getAllSelectedDocs = function() {
        return _.where(storeArr, 'isSelected');
    };

    var resetPageNumbersInOrder = function (pages, reorderModel) {
        for (var i = 0, len = pages.length; i < len; i++ ) {
            pages[i].pageNumber = i + 1;
        }
    };

    var getDocById = function(docId) {
        return storeObj[docId];
    };

    var focusSelectedPage = function(doc, pageId) {
        doc.focusPageById(pageId);
        var focusedPageObj = doc.getFocusedPage();
        focusedPageObj.select();
        doc.focus();
        doc.select();
    };

    var unselectAllThumbs = function() {
        thumbsForReorder = [];
        _.each(storeArr, function (obj) {
            obj.deSelect(); // clears selection from all doc Obj
            obj.unFocus(); // clears focus from all doc Obj
            _.each(obj.pages, function(page) {
                page.deSelect() //clears selection fron all thumb Obj
                page.unFocus();
                // page.action = undefined; // clears acton from all thumb obj
            });
        });
    };

    var clearDocSelections = function() {
        var selectedDocs = getAllSelectedDocs();
        _.each(selectedDocs, function(obj) {
            obj.deSelect();
        });
    };

    var shiftData = function() {
        delete(storeObj[storeArr.shift()]);
    };

    var isLimitExceeded = function() {
    	return storeArr.length >= size;
    };

    var resetFocusToLastPage = function(docIndex) {
        for(var i=0; pages = storeArr[docIndex].pages, i<pages.length; i++) {
            pages[i].isFocused = false;
            pages[i].isSelected = false;
        }
    };

    //To manage the selected thumbnail ids for reorder process.
    var manageSelectedPageIds = function(isMultiSelected, pageId){
        if(isMultiSelected){
            var index = thumbsForReorder.indexOf(pageId);
            if(index > -1) {
                thumbsForReorder.splice(index);
            }
            thumbsForReorder.push(pageId);
        }else{
            thumbsForReorder = [];
            thumbsForReorder.push(pageId);
        }
    };

    var init = function() {
        storeObj = {};
        storeArr = [];
    };

    return DocStorage;
}]);
