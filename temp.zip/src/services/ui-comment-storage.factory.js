uiv.factory('ViewerCommentStore', [function() {
    var storeObj,
        storeArr,
        name,
        size;

    var Storage = function(r_name, r_size) {
        name = r_name;
        size = r_size;
        init();
    };

    Storage.prototype.addComment = function(commentModel) {
        storeArr.push(commentModel);
    };

    Storage.prototype.getComments = function() {
        return storeArr;
    };

    var init = function() {
        storeObj = {};
        storeArr = [];
    };

    return Storage;
}]);
