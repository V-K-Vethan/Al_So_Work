uiv.directive('uiDocumentTab', ['$templateCache', '$timeout', 'ViewerEvents', 'ViewerSettingService', 'viewerConst', function($templateCache, $timeout, ViewerEvents, ViewerSettingService, viewerConst) {
    return {
        restrict: 'E',
        require: '^uiViewer',
        replace: true,
        scope: {
            // allDocuments: '=',
            // selectedDocument: '='
        },
        template: function () {
            return $templateCache.get('../src/views/ui-document-tab.html');
        },
        link: function (scope, element, attrs, uiViewerCtrl) {

            var viewerDS;
            var viewerControls;
            var onNewDocumentAdded;
            var onDocumentChange;
            var removeDoc = function (toDeleteDoc, toFocusDoc, index) {
                // if (toFocusDoc) {//if toFocusDoc is undefined, it denotes removing doc is the last doc, so no need to change the tab
                //     viewerDS.setFocusedDocument(toFocusDoc.id);
                // }
                viewerDS.removeDocument(toDeleteDoc.id, index);
                //if all docs removed, make all the button controls disabled
                ViewerSettingService.setCurrentPageText(null);
                ViewerSettingService.setCurrentDocTotalPages(null);
                //clear the selected doc, if all the docs are removed
                uiViewerCtrl.clearSelectedDocument();
            };
            scope.onLeft = function onLeft() {
                var outrContainer = element.find('#tabContainer');
                var tabbableLine = element.find('.tabbable-line');
                // outrContainer.stop().animate({left: '+=100px'}, 250);
                if (tabbableLine.width() > outrContainer.width())  {
                    var positionLeft = tabbableLine.position().left + 100;
                    tabbableLine.css("left", positionLeft);
                    if (tabbableLine.position().left > 0) {
                        tabbableLine.css("left", "0");
                    }
                }
            };

            scope.onRight = function onRight() {
                var outrContainer = element.find('#tabContainer');
                var tabbableLine = element.find('.tabbable-line');
                if (tabbableLine.width() > outrContainer.width())  {
                    var positionLeft = tabbableLine.position().left - 100;
                    tabbableLine.css("left", positionLeft);
                    var maxMovableArea = tabbableLine.width() - outrContainer.width();
                    if (tabbableLine.position().left < -maxMovableArea) {
                        tabbableLine.css("left", -maxMovableArea);
                    }
                }
            };

            /**
             * on click on tab this function invoked
             * @param {document object} currentSelectedDoc
             */
            scope.setFocusedDocument = function (doc) {
                viewerDS.setFocusedDocument(doc.id, true);
            };

            scope.removeDocument = function (doc) {
                viewerDS.removeDocument(doc.id);
            };

            var onNewDocumentAddedCallback = function onNewDocumentAddedCallback() {
                $timeout(function() {
                    scope.allDocuments = [];
                    scope.allDocuments = viewerDS.getDocuments();
                });
            };

            var onDocumentChangeCallback = function onDocumentChangeCallback(event, docId) {
                scope.focusedDoc = viewerDS.getFocusedDocument();
            };

            var init = function init() {
                viewerDS = uiViewerCtrl.getDataSource();
                scope.isMultipleDocumentAdded = ViewerSettingService.isMulitpleDocumentAdded;
                scope.allDocuments = viewerDS.getDocuments();
                scope.focusedDoc = viewerDS.getFocusedDocument();
                viewerEventsScope = ViewerEvents.getViewerScope();
                onNewDocumentAdded = viewerEventsScope.$on(ViewerEvents.NEW_DOCUMENT_ADDED, onNewDocumentAddedCallback);
                onDocumentChange = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChangeCallback);
                scope.$on('$destroy', function () {
                    onNewDocumentAdded();
                    onDocumentChange();
                });
            };
            init();
        }
    };
}]);
