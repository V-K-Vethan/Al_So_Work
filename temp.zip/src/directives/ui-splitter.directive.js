uiv.directive('bgSplitter', ['ViewerEvents', 'ViewerSettingService',
function(ViewerEvents, ViewerSettingService) {
    return {
        restrict: 'E',
        replace: true,
        require: '^uiViewer',
        transclude: true,
        scope: {
            orientation: '@'
        },
        template: '<div class="split-panes {{orientation}}" ng-transclude></div>',
        controller: ['$scope', function($scope) {
            $scope.panes = [];

            this.addPane = function(pane) {
                if ($scope.panes.length > 1) {
                    throw 'splitters can only have two panes';
                }
                $scope.panes.push(pane);
                return $scope.panes.length;
            };
        }],
        link: function(scope, element, attrs, uiViewerCtrl) {
            var viewerEventsScope,
                handler = angular.element('<div class="split-handler"></div>'),
                pane1 = scope.panes[0],
                pane2 = scope.panes[1],
                vertical = scope.orientation === 'vertical',
                pane1Min = pane1.minSize, // provided fixed position
                pane1Max = pane1.maxSize,
                pane2Min = pane2.minSize || 0,
                pane1Size = pane1.size,
                drag = false,
                onViewerResized,
                VS = uiViewerCtrl.getViewerSettings();

            pane1.elem.after(handler);

            element.bind('mousemove', function(ev) {
                if (!drag) {
                    return;
                }

                var bounds = element[0].getBoundingClientRect();
                var pos = 0;

                if (vertical) {

                    var height = bounds.bottom - bounds.top;
                    pos = ev.clientY - bounds.top;

                    if (pos < pane1Min || pos > pane1Max) {
                        return;
                    }
                    if (height - pos < pane2Min) {
                        return;
                    }

                    handler.css('top', pos + 'px');
                    pane1.elem.css('height', pos + 'px');
                    pane2.elem.css('top', pos + 'px');
                } else {
                    var width = bounds.right - bounds.left;
                    pos = ev.clientX - bounds.left;

                    if (pos < pane1Min || pos > pane1Max) {
                        return;
                    }
                    if (width - pos < pane2Min) {
                        return;
                    }

                    handler.css('left', pos + 'px');
                    pane1.elem.css('width', pos + 'px');
                    pane2.elem.css('left', pos + 'px');
                }
            });

            handler.bind('mousedown', function(ev) {
                ev.preventDefault();
                drag = true;
            });


            angular.element(document).bind('mouseup', function(ev) {
                if (drag) {
                    ViewerEvents.notify(ViewerEvents.VIEWER_RESIZED);
                    drag = false;
                }
            });

            var onViewerResizedCallback = function onViewerResizedCallback() {
                var selectedViewObj = VS.VIEWER_NAV_MENU[ViewerSettingService.getSelectedView()];
                pane1Min = selectedViewObj.minSize; 
                pane1Max = selectedViewObj.maxSize;
            };

            viewerEventsScope = ViewerEvents.getViewerScope();
            onViewerResized = viewerEventsScope.$on(ViewerEvents.VIEWER_RESIZED, onViewerResizedCallback);

            scope.$on('$destroy', function () {
                onViewerResized();
            });
        }
    };
}]);
uiv.directive('bgPane', function() {
    return {
        restrict: 'E',
        require: '^?bgSplitter',
        replace: true,
        transclude: true,
        scope: {
            minSize: '=',
            maxSize: '='
        },
        controller: ['$scope', function($scope) {

        }],
        template: '<div class="split-pane{{index}}" ng-transclude></div>',
        link: function(scope, element, attrs, bgSplitterCtrl) {
            scope.elem = element;
            scope.index = bgSplitterCtrl.addPane(scope);
        }
    };
});
