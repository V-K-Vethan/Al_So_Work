uiv.directive('repeater', ["$timeout",function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last) {
                $timeout(function () {
                    scope.$emit(attr.ngRepeatFinished);
                });
            }
        }
    };
}]);
