uiv.directive('uiPageDoc', [
    '$document',
    '$compile',
    '$parse',
    '$timeout',
    function($document, $compile, $parse, $timeouts) {

        return {
            restrict: 'E',
            require: '^uiViewer',
            scope: {
                doc: '=',
                docIndex: '='
            },
            templateUrl:"../src/views/ui-page-doc.html",
            link: function(scope, element, attrs, uiViewerCtrl){
                //get viewer datasource
                var viewerDS = uiViewerCtrl.getDataSource();

            }
        };
    }
]);
