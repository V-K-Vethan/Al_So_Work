"use strict";

uiv.directive('uiSidePanelNavigation', ['$templateCache', '$compile', 'viewerConst','ViewerEvents', 'ViewState', 'ViewerSettingService', '$timeout', function($templateCache, $compile, viewerConst, ViewerEvents, ViewState, ViewerSettingService, $timeout) {
    return {
        restrict: 'E',
        require: '^uiViewer',
        template: function () {
            return $templateCache.get('../src/views/ui-side-panel-navigation.html');
        },
        link: function (scope, element, attrs, uiViewerCtrl) {

            var
                viewerDS,
                viewerEventsScope,
                onViewerResized,
                onDocumentChange,
                VS,
                viewerStateChanged,
                onNewDocumentAdded,
                onUpdateNavViewSize,
                currentSelectedViewSettings,
                viewSizes = {},
                isToggleView = false;

            scope.setThumbnailVisibility = function () {
                var menuMode = viewerConst.viewerMenuMode;
                scope.minSize = VS.VIEWER_NAV_MENU[scope.leftSectionSelectedView].minSize;
                scope.maxSize = VS.VIEWER_NAV_MENU[scope.leftSectionSelectedView].maxSize;
                switch(currentSelectedViewSettings.mode) {
                    case menuMode.DEFAULT_SIZE: 
                        updateViewContainer(currentSelectedViewSettings.size);
                        break;
                    case menuMode.LAST_VISITED_WIDTH:
                        updateViewContainer(viewSizes[scope.leftSectionSelectedView])
                        break;
                    case menuMode.FULL_SCREEN:
                        updateViewContainer($('.split-panes').width());
                        break;
                    case menuMode.WIDTH_FROM_OTHER: 
                        updateViewContainer(viewSizes[ViewerSettingService.getLastSelectedView()]);
                        break;
                    default:
                        updateViewContainer(currentSelectedViewSettings.size)
                        break;
                }
            };

            var updateViewContainer = function updateViewContainer(size) {
                $('.split-pane1').css('width', size + 'px');
                $('.split-handler').css('left', size + 'px');
                $('.split-pane2').css('left', size + 'px');
            };

            var toggleViewContainer = function toggleViewContainer() {
                isToggleView = !isToggleView;
                if (isToggleView) {
                    updateViewContainer(viewSizes[scope.leftSectionSelectedView]);
                } else {
                    updateViewContainer(0);
                }
            };

            var onViewerResizedCallback = function onViewerResizedCallback() {
                if ($('.split-pane1').width() === 0) {
                    $('#thumb-menu-dir, .thumViewContainer .thumb-expand-icon').hide();
                } else {
                    $('#thumb-menu-dir, .thumViewContainer .thumb-expand-icon').show();
                    viewSizes[scope.leftSectionSelectedView] = $('.split-pane1').width();
                }
            };

            var onDocumentChangeCallback = function onDocumentChangeCallback() { };

            var onUpdateNavViewSizeCallback = function onUpdateNavViewSizeCallback(event, size) {
                updateViewContainer(size);
            };

            var updateViewState = function updateViewState() {
                var currentState = ViewerSettingService.getViewerState();
                scope.isCommentView = ViewState.stateMatrix[viewerConst.UI_ELEMENTS.COMMENT][currentState] && VS.actions.viewer.comment;
                scope.isMetaDataView = ViewState.stateMatrix[viewerConst.UI_ELEMENTS.META_DATA][currentState];
            };

            scope.changeView = function (view) {
                currentSelectedViewSettings = VS.VIEWER_NAV_MENU[view];
                if (scope.leftSectionSelectedView === view) {
                    toggleViewContainer();
                } else {
                    uiViewerCtrl.onViewChange(view, scope.leftSectionSelectedView);
                    scope.leftSectionSelectedView = view;
                    ViewerSettingService.setSelectedView(scope.leftSectionSelectedView);
                    scope.setThumbnailVisibility();
                }
                ViewerEvents.notify(ViewerEvents.VIEWER_RESIZED);
            };

            var onNewDocumentAddedCallback = function() {
                var docs = viewerDS.getDocuments();
                isToggleView = false;
                if (ViewerSettingService.getIsViewerClearedForcufully()) {
                    scope.leftSectionSelectedView = scope.leftSectionAvailableViews.THUMBNAIL;
                    scope.sidePaneSelectedButton = 1;
                    scope.changeView(scope.leftSectionSelectedView);
                    return;
                }

                if (!docs.length) { return; }
                scope.changeView(scope.leftSectionSelectedView);
            };

            var init = function init() {
                scope.isMetaDataView = false;
                scope.isCommentView = false;
                //get viewer datasource
                viewerDS = uiViewerCtrl.getDataSource();
                //get viewer settings
                VS = uiViewerCtrl.getViewerSettings();
                //navigation view settings
                scope.leftSectionAvailableViews = viewerConst.NAV_VIEWS;
                scope.leftSectionSelectedView = scope.leftSectionAvailableViews.THUMBNAIL;
                currentSelectedViewSettings = VS.VIEWER_NAV_MENU[scope.leftSectionSelectedView];
                ViewerSettingService.setSelectedView(scope.leftSectionSelectedView);
                //assigns default view sizes
                for (var item in VS.VIEWER_NAV_MENU) {
                    viewSizes[item] = VS.VIEWER_NAV_MENU[item].size;
                }

                //defines min and miximun splitter view
                scope.minSize = VS.VIEWER_NAV_MENU[scope.leftSectionSelectedView].minSize;
                scope.maxSize = VS.VIEWER_NAV_MENU[scope.leftSectionSelectedView].maxSize;
                //waits for container to render
                $timeout(function() {
                    scope.setThumbnailVisibility();
                });
                //get viewer scope for event handling
                viewerEventsScope = ViewerEvents.getViewerScope();
                onViewerResized = viewerEventsScope.$on(ViewerEvents.VIEWER_RESIZED, onViewerResizedCallback);
                onDocumentChange = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChangeCallback);
                viewerStateChanged = viewerEventsScope.$on(ViewerEvents.VIEWER_STATE_CHANGED, updateViewState);
                onNewDocumentAdded = viewerEventsScope.$on(ViewerEvents.NEW_DOCUMENT_ADDED, onNewDocumentAddedCallback);
                onUpdateNavViewSize = viewerEventsScope.$on(ViewerEvents.UPDATE_NAV_VIEW_SIZE, onUpdateNavViewSizeCallback);
                scope.$on('destroy', function() {
                    onViewerResized();
                    onDocumentChange();
                    viewerStateChanged();
                    onNewDocumentAdded();
                    onUpdateNavViewSize();
                });
            };

            init();
        }
    };
}]);
