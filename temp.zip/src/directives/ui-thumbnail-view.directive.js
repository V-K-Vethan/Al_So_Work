uiv.directive('uiThumbnailView', ['$document', '$compile', '$parse', '$timeout', 'ViewerEvents',
    'ViewerModel', 'uiViewerDatasource', 'ViewerSettingService', 'viewerConst', 'ViewState',
    function($document, $compile, $parse, $timeout, ViewerEvents, ViewerModel, uiViewerDatasource, ViewerSettingService, viewerConst, ViewState) {

        return {
            restrict: 'E',
            require: '^uiViewer',
            transclude: true,
            scope: {
                thumbHeaderIcon: "="
            },
            templateUrl: "../src/views/ui-thumbnail-view.html",
            controller: function($scope) {
                this.addThumbnail = function(thumbnailElement) {
                    $scope.thumbChildren[thumbnailElement.scope().thumb.id] = thumbnailElement;
                };
                this.getThumbChildren = function() {
                    return $scope.thumbChildren;
                };
            },
            link: function(scope, element, attrs, uiViewerCtrl) {

                var viewerScope,
                    viewerDS,
                    scrollTimer,
                    thumbnailViewContainer,
                    allThumbs,
                    thumbViewContTop,
                    thumbViewContBottom,
                    thumbMenu,
                    tempFocusedDocId,
                    viewerEventsScope,
                    pageChange,
                    showThumbnails,
                    setReorderState,
                    onDocumentChange,
                    pageViewContainer,
                    onNewDocumentAdded,
                    initialLimit,
                    thumbLimit,
                    thumbRangeValue,
                    isDocSelectedFromOutside,
                    onNavToThumb,
                    onDeletePages,
                    onThhumbSortablityChange,
                    allPages = [],
                    viewablePages = [],
                    tempScrollPosition,
                    thumbColsCount,
                    isDeletePagesDone,
                    selectedView, 
                    VS;

                var onLeftPanelScroll = function(event) {
                    if (scrollTimer) {
                        $timeout.cancel(scrollTimer);
                    }
                    scrollTimer = $timeout(function() {
                        showThumbnailsInRange(event, true);
                    }, 500);
                };

                scope.showFullThumbnailView = function showFullThumbnailView() {
                    ViewerEvents.notify(ViewerEvents.THUMBNAIL_PANEL_OPENED);
                };

                scope.maximizeThumbailViewer = function() {

                };

                scope.minimizeThumbailViewer = function() {

                };

                scope.focusPage = function(page) {
                    window.location.hash = page;
                };

                scope.manageThumbBox = function(element) {
                    updateThumbViewContainer(element);
                    ViewerEvents.notify(ViewerEvents.VIEWER_RESIZED);
                };

                scope.giveSize = function(size) {
                    scope.$apply(function(){
                        scope.headerSize = size;
                    });
                };

                var updateThumbViewContainer = function updateThumbViewContainer(element) {
                    var selectedViewObj = VS.VIEWER_NAV_MENU[ViewerSettingService.getSelectedView()];
                    var defaultSize = selectedViewObj.size;
                    var minSize = selectedViewObj.minSize;
                    if (element && (element.target.getAttribute("class")).indexOf("fa fa-caret-right") > -1) {
                        selectedView = "fullSize";
                        ViewerEvents.notify(ViewerEvents.UPDATE_NAV_VIEW_SIZE, $('.split-panes').width());
                        scope.thumbHeaderIcon = "left";
                    } else if(element && (element.target.getAttribute("class")).indexOf("fa fa-caret-left") > -1) {
                        ViewerEvents.notify(ViewerEvents.UPDATE_NAV_VIEW_SIZE, defaultSize);
                        scope.thumbHeaderIcon = "right";
                        selectedView = "defaultSize";
                    } else {
                       var pane1Width = $(".split-pane1").width();
                       scope.thumbHeaderIcon = pane1Width && pane1Width <= minSize + 2 ? "right" : "left";
                       // selectedView = "";
                    }
                }; 

                //TODO: move it to utils service
                //// {24,22}
                var isInRange = function(dom, top, bottom) {
                    var posT = dom.position().top ;
                    var posB = dom.position().top + dom.height();
                    return (posT <= top && posB >= top) // thumb on upper boundary
                            || (posT >= top && posB <= bottom) // thumb within boundary
                            || (posT <= top && posB >= bottom) // thumb exceed boundary
                            || (posT <= bottom && posB >= bottom); // thum on bootom boundary
                };

                var isInPrefetchRange = function(dom, top, bottom) {
                    var top = top - dom.height() * 10;
                    var bottom = bottom + dom.height() * 10;
                    return isInRange(dom, top, bottom);
                };

                var showThumbnailsInRange = function(event, isForcefully) {
                    //update container dimension
                    var thumbsInRangeArr = [];
                    updateThumbContDimension();
                    if (thumbnailViewContainer.outerWidth() < 5) {
                        return;
                    }
                    tempScrollPosition = thumbnailViewContainer.scrollTop();
                    var startThumbScope, lastThumbScope;
                    var thumbs = element.find("ui-thumbnail");
                    for (var i = 0, len = thumbs.length; i < len; i++) {
                        var thumbDir = scope.thumbChildren[$(thumbs[i]).attr('thumbId')];
                        var thumb = thumbDir.find('.thumb-contr');
                        var thumbScope = thumbDir.isolateScope();
                        if (thumbScope) {
                            if (isInRange(thumb, thumbViewContTop, thumbViewContBottom)) {
                                if (!startThumbScope) {
                                    startThumbScope = thumbScope;
                                }
                                lastThumbScope = thumbScope;
                            }
                            if (isInPrefetchRange(thumb, thumbViewContTop, thumbViewContBottom) && thumbScope.thumb.isValidPage) {
                                var isPriority = thumbScope.thumb.isFocused ? true : false;
                                thumbsInRangeArr.push(thumbScope.thumb.id + ":THUMBNAIL");
                                thumbScope.thumb.isThumbInRange = true;
                                thumbScope.showThumbImage(isForcefully, isPriority);
                            } else {
                                //unload canvas
                                if(thumbScope.thumb.isValidPage) {
                                    thumbScope.thumb.isThumbInRange = false;
                                    thumbScope.unloadThumbImage();
                                }
                            }
                        }
                    };
                    viewerDS.cancelOldThumbRequest(thumbsInRangeArr);
                    if (startThumbScope && lastThumbScope) {
                        loadAdvanceThumbnails(startThumbScope.thumb, lastThumbScope.thumb);
                        startThumbScope = "";
                    }
                };

                var onDocumentChangeCallback = function onDocumentChangeCallback(event, docId, isFromApplication) {
                    isDocSelectedFromOutside = isFromApplication;
                    var focusedDocId = viewerDS.getFocusedDocId();
                    var focusedDoc = viewerDS.getFocusedDocument();
                    if (focusedDoc) {
                        if (!tempFocusedDocId) {
                            tempFocusedDocId = focusedDocId;
                        }
                        if (tempFocusedDocId !== focusedDocId) {
                            var previousDocId = viewerDS.getOldFocusedDocId();
                            tempFocusedDocId = focusedDocId;
                        }
                    }
                    var docObj = viewerDS.getDocumentById(docId);
                    if (isFromApplication) {
                        updateFocusedThumb(docObj.pages[0]);
                        onJumpToPageCallback(null, {pageNum : docObj.pages[0].pageNumber, postResetThumbnailView: viewerDS.postResetThumbnailView} );
                    }
                    //Trigger callback of 3rd party
                    uiViewerCtrl.onDocumentChange(focusedDocId, previousDocId);
                    updateViewState();
                };

                var updateFocusedThumb = function updateFocusedThumb(pageObj) {
                    var selectedPageIndex = _.indexOf(allPages, pageObj);
                    if (!_.where(viewablePages, pageObj)[0]) {
                        initialLimit = (selectedPageIndex > 0) ? (selectedPageIndex - 1) : 0
                        thumbLimit = initialLimit + ViewerSettingService.getThumbViewLimit();
                        updateThumbnails();
                    }
                };

                var onPageChangedCallback = function onPageChangedCallback(event, pageId, isJumpToPage) {
                    $timeout(function() {
                        navToThumb(pageId, false, isJumpToPage);
                    });
                };

                var onNavToThumbCallback = function onNavToThumbCallback(event, pageId) {
                    if (isDocSelectedFromOutside) {
                        isDocSelectedFromOutside = false;
                        return;
                    }
                    var focusedPageObj = _.where(viewablePages, {'id' : pageId})[0];
                    if (focusedPageObj) {
                        navToThumb(pageId, false);
                    } else {
                        $timeout(function() {
                            onJumpToPageCallback(null, {pageNum : viewerDS.getFocusedDocument().getFocusedPage().pageNumber, postResetThumbnailView: viewerDS.postResetThumbnailView});
                        });
                    }
                };

                //Navigation to thumb and page
                var navToThumb = function navToThumb(pageId, isNavToDoc, isJumpToPage) {
                    var thumbDir = scope.thumbChildren[pageId];
                    if (!thumbDir) { return; }
                    var thumb = thumbDir.find('.thumb-contr');
                        var selectedThumb = $(thumbnailViewContainer.find('.thumb[thumb-id="' + pageId + '"]'));
                        //scroll to page
                        if (selectedThumb.length) {
                            //scroll to thumb - > document level, scrolling to first thumb in a doc
                            if (isDocSelectedFromOutside) {
                                var selectedDocIndex = _.indexOf(thumbnailViewContainer.find(".thumb-wrapper"), selectedThumb.parents('.thumb-wrapper')[0]);
                                var selectedThumbPos = thumbnailViewContainer.scrollTop() + selectedThumb.parents('.thumb-wrapper').position().top;
                                var scrollPos = ( selectedDocIndex > 0 ) ? (selectedThumbPos - (selectedThumb.height() + 25)) : selectedThumbPos;
                                thumbnailViewContainer.scrollTop(scrollPos);
                                isDocSelectedFromOutside = false;
                                showThumbnailsInRange(null, true);
                                return;
                            }
                            //scroll to thumb - > thumb level, scrolling to current thumb
                            if (selectedThumb.position().top < 0) {
                                thumbnailViewContainer.scrollTop(selectedThumb.position().top + thumbnailViewContainer.scrollTop());
                            } else if ((selectedThumb.position().top > thumbnailViewContainer.height() - selectedThumb.height())) {
                                thumbnailViewContainer.scrollTop(selectedThumb.position().top + thumbnailViewContainer.scrollTop() - thumbnailViewContainer.height() + selectedThumb.height() + 20);
                            } else {
                                if ((isJumpToPage && (selectedThumb.position().top < 0 || (selectedThumb.position().top > thumbnailViewContainer.height() - selectedThumb.height()))) || isDocSelectedFromOutside) {
                                    thumbnailViewContainer.scrollTop(selectedThumb.position().top + thumbnailViewContainer.scrollTop());
                                }
                            }
                        }
                        showThumbnailsInRange(null, true);
                };

                var onNewDocumentAddedCallback = function onNewDocumentAddedCallback(){
                    scope.allDocuments  = [];
                    scope.viewableDocuments = [];
                    scope.allDocuments  = viewerDS.getDocuments();
                    initialLimit = ViewerSettingService.getInititalLimit();
                    thumbLimit = ViewerSettingService.getThumbViewLimit();
                    allPages = _.flatten(_.pluck(scope.allDocuments, 'pages'));
                    updateThumbnails();
                };

                var updateThumbnails = function updateThumbnails() {
                    var thumbViewLimit = ViewerSettingService.getThumbViewLimit();
                    //reassigns the start and end limit, if thumbLimit index crosses the no of pages available
                    if ((initialLimit > 0) && (allPages.length - initialLimit) < thumbViewLimit) {
                        initialLimit = (allPages.length) - thumbViewLimit;
                        thumbLimit = (allPages.length);
                    }
                    viewablePages = allPages.slice(initialLimit, thumbLimit);
                    thumbColsCount = Math.floor($('.thumb-wrapper').width() / ($('.thumb').width() + 12));
                    refineViewablePages();
                    ViewerSettingService.setIsThumbsPageChanged(true);
                    loadInitialThumbnails();
                };

                var refineViewablePages = function refineViewablePages() {
                    try {
                        if (thumbColsCount === 0 || (thumbLimit === allPages.length)) {
                            return;
                        }
                        var firstThumb = viewablePages[0];
                        var firstThumbIndex = _.indexOf(allPages, firstThumb);
                        if (firstThumbIndex > 0) {
                            var modVal = ((firstThumb.pageNumber - 1) % thumbColsCount);
                            var shiftAmount = modVal;
                            initialLimit = (firstThumbIndex - shiftAmount);
                            thumbLimit = initialLimit + ViewerSettingService.getThumbViewLimit();
                            viewablePages = allPages.slice(initialLimit, thumbLimit);
                        }
                    } catch(e) {
                        console.log(e);
                    }
                };

                var clearOldFocusedPage = function clearOldFocusedPage(pages) {
                    var focusedPageId = viewerDS.getFocusedPageId();
                    var focusedPage = _.where(pages, 'isFocused')[0];
                    if (focusedPage && (focusedPage.id !== focusedPageId))  {
                        focusedPage.unFocus();
                    }
                }

                var loadInitialThumbnails = function loadInitialThumbnails() {
                    scope.viewableDocuments = [];
                    var docIds = _.uniq(_.pluck(viewablePages, 'docId'));
                    _.each(docIds, function(id) {
                        var docObj = viewerDS.getDocumentById(id);
                        if (!docObj) { return; }
                        docObj.viewablePages = _.where(viewablePages, {'docId': id});
                        if (!isDeletePagesDone) {
                            clearOldFocusedPage(docObj.pages);
                        }
                        scope.viewableDocuments.push(docObj);
                    });
                    isDeletePagesDone = false;
                }

                var loadAdvanceThumbnails = function loadAdvanceThumbnails(startThumb, endThumb) {
                    var startThumbIndexOfAllPages = _.indexOf(allPages, startThumb),
                        endThumbIndexOfAllPages = _.indexOf(allPages, endThumb);
                    if (endThumbIndexOfAllPages === (allPages.length - 1) || startThumbIndexOfAllPages === 0) {
                        return;
                    }
                    if (thumbnailViewContainer.scrollTop() < 35) {
                        initialLimit = (initialLimit < thumbRangeValue) ? 0 : initialLimit - thumbRangeValue;
                        thumbLimit = (initialLimit < thumbRangeValue) ? initialLimit + ViewerSettingService.getThumbViewLimit() : thumbLimit - thumbRangeValue;
                        updateThumbnails();
                        var selectedThumb = $(thumbnailViewContainer.find('.thumb[thumb-id="' + startThumb.id + '"]'));
                        $timeout(function() {
                            thumbnailViewContainer.scrollTop(thumbnailViewContainer.scrollTop() + selectedThumb.position().top);
                        });
                        return;
                    }
                    if ((thumbnailViewContainer.scrollTop() + thumbnailViewContainer.innerHeight() + 10) >= thumbnailViewContainer[0].scrollHeight) {
                        var pageObj = allPages[initialLimit + thumbRangeValue];
                        if (!pageObj) {
                            return;
                        }
                        var pageId = allPages[initialLimit + thumbRangeValue].id;
                        var rTH1 =  $(thumbnailViewContainer.find('.thumb[thumb-id="' + pageId + '"]'));
                        var rTH2 = $(thumbnailViewContainer.find('.thumb[thumb-id="' + allPages[initialLimit].id + '"]'));
                        if (!rTH1.length || !rTH2.length) { return; }
                        var height = (pageId) ? rTH1.position().top - rTH2.position().top : 0;
                        initialLimit = initialLimit + thumbRangeValue;
                        thumbLimit = thumbLimit + thumbRangeValue;
                        updateThumbnails();
                        thumbnailViewContainer.scrollTop(thumbnailViewContainer.scrollTop() - height);
                        return;
                    }
                };

                var onJumpToPageCallback = function onJumpToPageCallback(event, obj) {
                    var focusedDoc = viewerDS.getFocusedDocument();
                    if (!_.where(focusedDoc.viewablePages, { 'pageNumber' : parseInt(obj.pageNum)})[0]) {
                        var docObj = _.where(viewerDS.getDocuments(), {'id' : focusedDoc.id})[0];
                        if (!docObj) { return; }
                        var pageObj = docObj.pages[obj.pageNum - 1 ];
                        if (pageObj) {
                            var selectedPageIndex = _.indexOf(allPages, _.where(allPages, {'id' : pageObj.id})[0]);
                            initialLimit = (selectedPageIndex > 0) ? (selectedPageIndex - 1) : 0
                            thumbLimit = initialLimit + ViewerSettingService.getThumbViewLimit();
                            updateThumbnails();
                        }
                    }
                    obj.postResetThumbnailView(obj.pageNum);
                };

                var onViewerResizedCallback = function onViewerResizedCallback(event, isFromApplication) {
                    updateThumbnails();
                    showThumbnailsInRange(event, true);
                    $timeout(function() {
                        var tempSelectedView = ($('#ui-viewer-container').width() < $('.split-pane1').width()) ? 'fullSize' : '';
                        if ((selectedView === "fullSize" || tempSelectedView) && 
                            ViewerSettingService.getSelectedView() === 'thumbnail' &&
                            $('.split-pane1').width() != 0) {
                            ViewerEvents.notify(ViewerEvents.UPDATE_NAV_VIEW_SIZE, $('.split-panes').width());
                        } else {
                            updateThumbViewContainer();
                        }
                        navToThumb(viewerDS.getFocusedPageId(), false);
                    });
                };

                var onLoadThumbs = function(event) {
                    if (scrollTimer) {
                        $timeout.cancel(scrollTimer);
                    }
                    scrollTimer = $timeout(function() {
                        showThumbnailsInRange(event, true);
                    }, 500);
                };

                var onDeletePagesCallback = function(event, deletedDocs) {
                    isDeletePagesDone = true;
                    var deletePages = _.flatten(_.pluck(deletedDocs, 'pages'));
                    _.each(deletePages, function(page) {
                        allPages.splice(_.indexOf(allPages, page), 1);
                    });
                    updateThumbnails();
                };

                var onThhumbSortablityChangeCallback = function onThhumbSortablityChangeCallback(event, isValidSortOccured) {
                    // scope.allDocuments  = [];
                    scope.allDocuments  = viewerDS.getDocuments();
                    var focusedDoc = viewerDS.getFocusedDocument();
                    // clears the entire list if reorder done on out of boundary limit
                    if (ViewerSettingService.getIsThumbsPageChanged()) {
                        $timeout(function() {
                            scope.viewableDocuments = [];
                        });
                    } else if (ViewerSettingService.getIsPreviousDataToClean()) {
                        //triggers the ng-repeat after modification in list, otherwise list is not getting refreshed after sort
                        scope.viewableDocuments.splice(scope.viewableDocuments.indexOf(focusedDoc), 1);
                    }
                    $timeout(function() {
                        allPages = _.flatten(_.pluck(scope.allDocuments, 'pages'));
                        updateThumbnails();
                        var focusedPage = focusedDoc.getFocusedPage();
                        if (!focusedPage) { return; }
                        onJumpToPageCallback(null, {pageNum : focusedPage.pageNumber, postResetThumbnailView: viewerDS.postResetThumbnailView});
                        $timeout(function () {
                            showThumbnailsInRange(null, true);
                        });

                    });

                };

                /**
                 * [updateThumbContDimension description]
                 * @return {[type]} [description]
                 */
                var updateThumbContDimension = function updateThumbContDimension(){
                    thumbViewContTop = thumbnailViewContainer.position().top;
                    thumbViewContBottom = thumbViewContTop + thumbnailViewContainer.outerHeight();
                };

                var updateViewState = function updateViewState() {
                    var currentState = ViewerSettingService.getViewerState();
                    // scope.controls["invalidDocument"] = ViewState.stateMatrix[viewerConst.UI_ELEMENTS.INVALID_DOCUMENT][currentState]
                };

                var init = function init() {
                    //get viewer scope
                    viewerScope = ViewerEvents.getViewerScope();
                    //get viewer datasource
                    viewerDS = uiViewerCtrl.getDataSource();
                    //get viewer settings
                    VS = uiViewerCtrl.getViewerSettings();
                    scope.thumbChildren = {};
                    scope.allDocuments  = viewerDS.getDocuments();
                    thumbnailViewContainer = $(element[0].querySelector('.thumbview'));
                    allThumbs = thumbnailViewContainer.find('.thumb');
                    updateThumbContDimension();
                    scope.thumbHeaderIcon = "right";
                    thumbMenu = thumbnailViewContainer.find('.menu');
                    //setting the thumb view container in datasource
                    thumbnailViewContainer.on('scroll', onLeftPanelScroll);
                    //Listeners
                    initialLimit = ViewerSettingService.getInititalLimit();
                    thumbLimit = ViewerSettingService.getThumbViewLimit();
                    thumbRangeValue = ViewerSettingService.getThumbViewRange();
                    viewerEventsScope = ViewerEvents.getViewerScope();
                    showThumbnails  = scope.$on('onLoadThumbs', onLoadThumbs);
                    onDocumentChange = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChangeCallback);
                    onPageChanged = viewerEventsScope.$on(ViewerEvents.PAGE_CHANGED, onPageChangedCallback);
                    onNewDocumentAdded = viewerEventsScope.$on(ViewerEvents.NEW_DOCUMENT_ADDED, onNewDocumentAddedCallback);
                    onViewerResized = viewerEventsScope.$on(ViewerEvents.VIEWER_RESIZED, onViewerResizedCallback);
                    onJumpToPage = viewerEventsScope.$on(ViewerEvents.JUMP_TO_PAGE, onJumpToPageCallback);
                    onNavToThumb = viewerEventsScope.$on(ViewerEvents.NAV_TO_THUMB, onNavToThumbCallback);
                    onDeletePages = viewerEventsScope.$on(ViewerEvents.DELETE_PAGES_DONE, onDeletePagesCallback);
                    onThhumbSortablityChange = viewerEventsScope.$on(ViewerEvents.THUMB_SORTABILITY_CHNAGED, onThhumbSortablityChangeCallback);

                    scope.$on('$destroy', function () {
                        showThumbnails();
                        // setReorderState();
                        onDocumentChange();
                        onPageChanged();
                        onNewDocumentAdded();
                        onViewerResized();
                        onJumpToPage();
                        onNavToThumb();
                        onDeletePages();
                        onThhumbSortablityChange();
                    });
                };

                init();
            }
        };
    }
]);
