uiv.directive('uiStampbar', ['$templateCache', function($templateCache) {
    return {
        restrict: 'E',
        template: function () {
            return $templateCache.get('../src/views/ui-stampbar.html');
        },
        link: function (scope, element) {

        }
    };
}]);