uiv.directive('uiToolbar', ['$templateCache', 'ViewerSettingService', 'viewerConst', 'ViewState','ViewerEvents',
    function($templateCache, ViewerSettingService, viewerConst, ViewState, ViewerEvents) {
    return {
        restrict: 'E',
        require: '^uiViewer',
        replace: true,
        template: function () {
            return $templateCache.get('../src/views/ui-toolbar.html');
        },
        link: function (scope, element, attr, uiViewerCtrl) {

            var onDocumentChange,
                viewerDS,
                VS,
                viewerStateChanged;

            scope.annotationUnderLine = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.UNDERLINE;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationEnterText = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.TEXT;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationPointer = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.POINTER;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationComment = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.COMMENT;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationText = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.TEXT;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationStrikeOut = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.STRIKEOUT;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationErase = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.ERASE;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationRedaction = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.REDACTION;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            scope.annotationHighlight = function () {
                ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.HIGHLIGHT;
                scope.annotationTypeId = ViewerSettingService.annotationTypeId;
                ViewerEvents.notify(ViewerEvents.CANCEL_ANNOTATION);
            };

            var onDocumentChangeCallback = function onDocumentChangeCallback() { };

            var updateViewState = function updateViewState() {
                var currentState = ViewerSettingService.getViewerState();
                scope.controls = {
                    annotation : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.ANNOTATION][currentState] && VS.actions.business.annotation && VS.actions.business.annotation.create,
                };
                if (!scope.controls.annotation) {//if annotation disabled, set it to no selection eventhough if some other annotation is selected
                    ViewerSettingService.annotationTypeId = viewerConst.ANNOTATION_KEYS.NOSELECTION;
                    scope.annotationTypeId = viewerConst.ANNOTATION_KEYS.NOSELECTION;//no selection of annotation in toolbar menu
                }
            };

            var init = function init() {
                viewerDS = uiViewerCtrl.getDataSource();
                VS = uiViewerCtrl.getViewerSettings();
                var viewerEventsScope = ViewerEvents.getViewerScope();
                scope.annotationTypeId = viewerConst.ANNOTATION_KEYS.NOSELECTION;//no selection of annotation in toolbar menu
                scope.annotationKeys  = viewerConst.ANNOTATION_KEYS;
                updateViewState();
                onDocumentChange = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChangeCallback);
                viewerStateChanged = viewerEventsScope.$on(ViewerEvents.VIEWER_STATE_CHANGED, updateViewState);
                scope.$on('$destroy', function() {
                    onDocumentChange();
                    viewerStateChanged();
                });
            };

            init();
        }
    };
}]);
