uiv.directive('uiPredefinedZooms', ['$templateCache', 'viewerConst', 'ViewerSettingService', 'ViewerEvents', 'ViewState', 'ViewerEvents', '$document',
    function($templateCache, viewerConst, ViewerSettingService, ViewerEvents, ViewState, ViewerEvents, $document) {
        return {
            restrict: 'A',
            require: '^uiCommonFunction',
            scope: {
                state: '=',
                scale: '@'
            },
            template: function() {
                return $templateCache.get('../src/views/ui-predefined-zooms.html');
            },
            link: function(scope, element, attr, commonFuncCtrl) {

                var resizeOptionKeys;

                var disableAllOptions = function disableAllOptions() {
                    _.each(scope.resizeOptions, function(option) {
                        scope.selectedOption = option;
                        scope.selectedOption.isSelected = false;
                    });
                };

                var fitToWidthAndBestFit = function fitToWidthAndBestFit(id) {
                    disableAllOptions();
                    if (id === viewerConst.PAGE_FIT_TYPE.FIT_TO_WIDTH) {
                        scope.selectedOption = scope.resizeOptions[resizeOptionKeys.FIT_WIDTH];
                        scope.selectedOption.isSelected = true;
                        scope.selectedSize = scope.selectedOption.name;
                        return;
                    }
                    if (id === viewerConst.PAGE_FIT_TYPE.BEST_FIT) {
                        scope.selectedOption = scope.resizeOptions[resizeOptionKeys.ZOOM_TO_PAGE_LEVEL];
                        scope.selectedOption.isSelected = true;
                        scope.selectedSize = scope.selectedOption.name;
                        return;
                    }
                };

                var updatePageZoom = function updatePageZoom() {
                    element.find('.btn').blur();
                    if (scope.selectedOption.id === viewerConst.COMMON_FUNCTION.RESIZE_KEYS.ZOOM_TO_PAGE_LEVEL || scope.selectedOption.id === viewerConst.COMMON_FUNCTION.RESIZE_KEYS.FIT_WIDTH) {
                        ViewerSettingService.setPageFitType(scope.selectedOption.id);
                    } else {
                        ViewerSettingService.setScale(scope.selectedOption.scale);
                        ViewerSettingService.setPageFitType(viewerConst.PAGE_FIT_TYPE.DEFAULT);
                    }
                    ViewerEvents.notify(ViewerEvents.SCALE_CHANGED);
                };

                scope.updateZoomInputDisplay = function updateZoomInputDisplay(scale) {
                    disableAllOptions();
                    if (scale !== viewerConst.PAGE_FIT_TYPE.FIT_TO_WIDTH && scale !== viewerConst.PAGE_FIT_TYPE.BEST_FIT) {
                        scope.selectedSize = Math.round(scale * 100) + "% ";
                        _.each(scope.resizeOptions, function(option) {
                            scope.selectedOption = option;
                            if (parseInt(scope.selectedSize) === parseInt(option.name)) {
                                scope.selectedOption.isSelected = true;
                            }
                        });
                    }  else {
                        fitToWidthAndBestFit(scale);
                    }
                };

                scope.showOptions = function showOptions() {
                    scope.isOptionsVisible = !scope.isOptionsVisible;
                };

                scope.predefinedZoomChange = function(selectedOption) {
                    disableAllOptions();
                    scope.selectedOption = selectedOption;
                    scope.selectedSize = selectedOption.name;
                    scope.selectedOption.isSelected = true;
                    scope.scale= scope.selectedOption.scale;
                    scope.isOptionsVisible = false;
                    updatePageZoom();
                };

                var init = function init() {
                    scope.isOptionsVisible = false;
                    resizeOptionKeys = viewerConst.COMMON_FUNCTION.RESIZE_KEYS;
                    scope.resizeOptions = viewerConst.COMMON_FUNCTION.RESIZE_OPTIONS;
                    _.each(scope.resizeOptions, function(option) {
                        option.isSelected = false;
                    });
                    scope.selectedOption = scope.resizeOptions[resizeOptionKeys.FIT_WIDTH];
                    scope.selectedSize = scope.resizeOptions[resizeOptionKeys.FIT_WIDTH].name;
                    scope.selectedOption.isSelected = true;
                    commonFuncCtrl.addPredefinedElement(element);
                };

                init();
            }
        };


}]);
