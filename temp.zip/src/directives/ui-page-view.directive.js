uiv.directive('uiPageView', [
    '$templateCache',
    '$timeout',
    'ViewerModel',
    'ViewerEvents',
    'ViewerNotification',
    'viewerConst',
    'ViewerSettingService',
    'ViewState',
    function($templateCache, $timeout, ViewerModel, ViewerEvents, ViewerNotification, viewerConst, ViewerSettingService, ViewState) {
        return {
            restrict: 'E',
            replace: true,
            require: '^uiViewer',
            scope: {

            },
            template: function() {
                return $templateCache.get('../src/views/ui-page-view.html');
            },
            controller: function($scope) {

                this.updateViewport = function updateViewport() {
                    $scope.updateViewPortDimension();
                };

                this.updatePageContainerDimension = function updatePageContainerDimension(width, height) {
                    $scope.updatePageContainerDimension(width, height);
                    //loop thru all directive available page childern and call method pageScope.updateContainerDimension()
                };

                this.scrollToFocusedAnnotation = function scrollToFocusedAnnotation(annotationId) {
                    $scope.scrollToFocusedAnnotation(annotationId);
                };

            },
            link: function(scope, element, attrs, uiViewerCtrl) {

                var scrollTimer,
                    viewerDS,
                    pageViewContainer,
                    pageViewContTop,
                    pageViewContBottom,
                    pageChanged,
                    showError,
                    isScrollIgnoredReqd,
                    initialLimit,
                    pageLimit,
                    pageRangeValue,
                    allPages = [],
                    viewablePages = [],
                    pages,
                    startPageScope,
                    endPageScope,
                    viewerEventsScope,
                    showPages,
                    showNotification,
                    viewerResized,
                    focusedPageObj,
                    rotationChanged,
                    scaleChanged,
                    focusedPageId,
                    onNewDocumentAdded,
                    documentChanged,
                    isDocSelectedFromOutside = false,
                    VS,
                    isScrollToFocusedPageReqd,
                    isThumbSorted = false;

                var onRightPanelScroll = function(event) {

                    if (scrollTimer) {
                        $timeout.cancel(scrollTimer);
                    }
                    scrollTimer = $timeout(function() {
                        if (isScrollIgnoredReqd) {
                            isScrollIgnoredReqd = false;
                        } else {
                            showPagesInRange(true);
                        }
                    }, 500);
                };

                var isInPrefetchRange = function(dom, top, bottom) {
                    var top = top - dom.height() * 5;
                    var bottom = bottom + dom.height() * 5;
                    return isInRange(dom, top, bottom);
                };

                //TODO: validate the logic
                var isInRange = function(dom, top, bottom) {
                    var posT = dom.position().top,
                        posB = dom.position().top + dom.height();
                    return (posT <= top && posB >= top) // page on upper boundary
                        || (posT >= top && posB <= bottom) // page within boundary
                        || (posT <= top && posB >= bottom) // page exceed boundary
                        || (posT <= bottom && posB >= bottom); // page on bottom boundary
                };

                //TODO: validate the logic
                var isInMiddle = function(dom, top, bottom) {
                    var posT = dom.position().top;
                    var posB = dom.position().top + dom.height();
                    var mid = (bottom - top) / 2;
                    return (mid >= posT && mid <= posB);
                };

                var showPagesInRange = function(isForcefully, isRerendered) {
                    //update container dimension
                    updateViewPortDimension();
                    var inRangePageArr = [];
                    // for full screen thumb view, restricting images to be loaded
                    if (pageViewContainer.outerWidth() < 5) {
                        return;
                    }
                    pages = $('ui-page');
                    //for (var i = 0, len = pages.length; i < len; i++)
                    for (var i = 0, len = pages.length; i < len; i++) {
                        var pageDir = viewerDS.getPageDirElementById($(pages[i]).attr('pageId'));
                        if (!pageDir) { return; }
                        var page = pageDir.find('.page-contr');
                        var pageScope = pageDir.isolateScope();
                        if (pageScope) {
                            if (isInRange(page, pageViewContTop, pageViewContBottom)) {
                                if (!startPageScope) {
                                    startPageScope = pageScope;
                                }
                                endPageScope = pageScope;
                            }
                            if (isInPrefetchRange(page, pageViewContTop, pageViewContBottom)) {
                                //TODO unbind previous Focused & bind focused anotation pointer event
                                pageScope.bindAnnotationEvents();
                                var isPriority = pageScope.page.isFocused ? true : false;
                                var pageCanvasContr = $(".page[page-id='" + pageScope.page.id + "']").find('canvas');
                                if ((isRerendered || !pageCanvasContr.length) && pageScope.page.isValidPage) {
                                    pageScope.showImage(isForcefully, isPriority);
                                    pageScope.page.isPageInRange = true;
                                    inRangePageArr.push(pageScope.page.id + ":PAGE");
                                } else {
                                    //already rendered
                                }

                                //select middle page as focused
                                if (isInMiddle(page, pageViewContTop, pageViewContBottom)) {
                                    if (focusedPageId !== pageScope.page.id) {
                                        focusedPageId = pageScope.page.id;
                                        if (!isDocSelectedFromOutside && !isScrollToFocusedPageReqd) {
                                            viewerDS.focusScrolledPage(pageScope.page);
                                        }
                                    }
                                }
                            } else {
                                //unload canvas
                                if (pageScope.page.isValidPage) {
                                    pageScope.page.isPageInRange = false;
                                    pageScope.unloadImage();
                                    pageScope.unbindAnnotationEvents();
                                }
                            }
                        }
                    };
                    viewerDS.cancelOldPageRequest(inRangePageArr);
                    if (startPageScope && endPageScope) {
                        loadAdvancePages(startPageScope.page, endPageScope.page);
                        startPageScope = "";
                    }
                    isDocSelectedFromOutside = false;
                    isScrollToFocusedPageReqd = false;
                };

                /**
                 * onDeletePagesCallback
                 * @return {[type]} [description]
                 */
                var onDeletePagesCallback = function onDeletePagesCallback(e, docs) {
                    var pageIds;
                    _.each(docs, function(obj) {
                        pageIds = _.pluck(obj.pages, 'id');
                    });

                    if (pageIds && pageIds.length) {
                        for (var i = 0, len = pageIds.length; i < len; i++) {
                            viewerDS.deletePageDirElement(pageIds[i]);
                        }
                    }
                    $timeout(function() {
                        var deletePages = _.flatten(_.pluck(docs, 'pages'));
                        _.each(deletePages, function(page) {
                            allPages.splice(_.indexOf(allPages, page), 1);
                        });
                        updatePages();
                    });
                };

                /**
                 * onBeforeDrawAnnotationCallback
                 * @return {[type]} [description]
                 */
                var onBeforeDrawAnnotationCallback = function onBeforeDrawAnnotationCallback(e, pageId) {
                    var pageDir;
                    var index;
                    var pageChildrenArray = viewerDS.getAllPageDirElements();
                    var pageIndex = pageChildrenArray.map(function(obj) {
                        return obj.attr('pageid');
                    }).indexOf(pageId);

                    if (pageIndex < 10) {
                        index = 0;
                    } else {
                        index = pageIndex - 10;
                    }

                    //Clearing the annotations of before 10 and after 10 pages of current page
                    for (var i = index, len = pageChildrenArray.length; i < len; i++) {
                        if (i === pageIndex) {
                            continue;
                        }
                        pageDir = pageChildrenArray[i];
                        if (pageDir && pageDir.isolateScope() && typeof pageDir.isolateScope().onCancelAnnotation === 'function') {
                            pageDir.isolateScope().onCancelAnnotation();
                        };
                        if (i === pageIndex + 10) {
                            break;
                        }
                    }
                };

                var onNewDocumentAddedCallback = function onNewDocumentAddedCallback() {
                    //TODO: need optimization: new document need to be pushed, not change complete array
                    scope.allDocuments = [];
                    scope.viewableDocuments = [];
                    scope.viewablePages = [];
                    viewerDS.resetAllPageDirElements();
                    $timeout(function() {
                        scope.allDocuments = viewerDS.getDocuments();
                        if (scope.allDocuments.length) {
                            allPages = _.flatten(_.pluck(scope.allDocuments, 'pages'));
                            // updatePages();
                        }
                    });
                };

                /**
                 * displays notification success/error
                 * @return {[type]} [description]
                 */
                var showNotificationCb = function showNotificationCb() {
                    scope.notificationObj = ViewerNotification.getCurrentNotification();
                    $timeout(function() {
                        scope.notificationObj = {};
                    }, 3000);
                };

                var onDocChangedCallback = function onDocChangedCallback(event, docId, isFromApplication) {
                    isDocSelectedFromOutside = isFromApplication;
                    if (isFromApplication) {
                        var docObj = viewerDS.getDocumentById(docId);
                        onPageChangedCallback(null, docObj.pages[0].id);
                    }
                    updateViewState();
                };

                var updateViewState = function updateViewState() {
                    var currentState = ViewerSettingService.getViewerState();
                    scope.controls = {
                        invalidDocument: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.INVALID_DOCUMENT][currentState]
                    };
                };

                var pageScrollTimer;
                var onPageChangedCallback = function onPageChangedCallback(event, pageId) {
                    //to restrict page render when user navigates pages frequently
                    isScrollToFocusedPageReqd = true;
                    if (pageScrollTimer) {
                        $timeout.cancel(pageScrollTimer);
                    }
                    pageScrollTimer = $timeout(function() {
                        focusedPageObj = viewerDS.getPageById(pageId);
                        if (focusedPageObj && (!_.where(scope.viewablePages, {'id' : pageId})[0] || isThumbSorted)) {
                            isThumbSorted = false;
                            var selectedPageIndex = _.indexOf(allPages, _.where(allPages, {'id' : focusedPageObj.id})[0]);
                            initialLimit = (selectedPageIndex > 1) ? (selectedPageIndex - 2) : 0
                            pageLimit = initialLimit + ViewerSettingService.getPageViewLimit();
                            updatePages();
                        } else {
                            scrollToFocusedPage();
                        }
                    }, 500);
                };

                var scrollToFocusedPage = function scrollToFocusedPage() {
                    if (!focusedPageObj) {
                        return;
                    }
                    pageId = focusedPageObj.id;
                    var selectedPage = $(pageViewContainer.find('.page[page-id="' + pageId + '"]'));
                    if (selectedPage.length) {
                        pageViewContainer.scrollTop(pageViewContainer.scrollTop() + selectedPage.position().top);
                        var selectedPageScope = selectedPage.children().isolateScope();
                        var pageCanvasContr = selectedPage.find('canvas');
                         if (!pageCanvasContr.length && selectedPageScope.page.isValidPage) {
                            selectedPageScope.showImage(true, true);
                         }
                    }
                };

                scope.scrollToFocusedAnnotation = function scrollToFocusedAnnotation(annotationId) {
                    var selectedAnnotation = $(pageViewContainer.find('*[annotation-id="' + annotationId + '"]'));
                    if (selectedAnnotation && selectedAnnotation.length) {
                        if (selectedAnnotation.position().top < 0) {
                            var relativeY = selectedAnnotation.offset().top - pageViewContainer.offset().top;
                            pageViewContainer.scrollTop(pageViewContainer.scrollTop() + relativeY - 20);
                        } else if (selectedAnnotation.position().top > pageViewContainer.height() - selectedAnnotation.height()) {
                            pageViewContainer.scrollTop(selectedAnnotation.position().top + pageViewContainer.scrollTop() - pageViewContainer.height() + selectedAnnotation.height());
                        }
                        isScrollIgnoredReqd = true;
                    }
                };

                scope.updatePageContainerDimension = function updatePageContainerDimension(width, height) {
                    _.each(viewerDS.getPageDirObjects(), function(pageDir) {
                        if (pageDir.isolateScope()) {
                            var pageObj = pageDir.isolateScope().page;
                            pageObj.setDimension({
                                width: pageObj.resolution.low.width,
                                height: pageObj.resolution.low.height
                            });
                            pageDir.isolateScope().updateSettings();
                        } else {
                            //no scope available
                        }
                    });
                };

                var onViewerResizedCallback = function onViewerResizedCallback() {
                    $timeout(function () {
                        updateScalePrequisites();
                        scope.updatePageContainerDimension();
                        focusedPageObj = viewerDS.getPageById(viewerDS.getFocusedPageId());
                        if (focusedPageObj) {
                            scrollToFocusedPage(focusedPageObj.id);
                            showPagesInRange(true, true);
                        }
                    });
                };

                var onRotaionChangedCallback = function onRotaionChangedCallback(event) {
                    isScrollToFocusedPageReqd = true;
                    updateScalePrequisites();
                    scope.updatePageContainerDimension();
                    focusedPageObj = viewerDS.getPageById(viewerDS.getFocusedPageId());
                    scrollToFocusedPage(focusedPageObj.id);
                    showPagesInRange(true, true);
                };

                var updateViewPortDimension = function updateViewPortDimension() {
                    pageViewContTop = pageViewContainer.position().top;
                    pageViewContBottom = pageViewContTop + pageViewContainer.outerHeight();

                    //update in settings
                    ViewerSettingService.setViewPortDimension(pageViewContainer.outerWidth(), pageViewContainer.outerHeight());
                };

                var onScaleChangedCallback = function onScaleChangedCallback() {
                    focusedPageObj = viewerDS.getFocusedDocument().getFocusedPage();
                    isScrollToFocusedPageReqd = true;
                    updateScalePrequisites();
                    scope.updatePageContainerDimension();
                    scrollToFocusedPage(focusedPageObj.id);
                    showPagesInRange(true, true);
                };

                var onLoadPagesCallback = function onLoadPagesCallback() {
                    pages = $('ui-page');
                    focusedPageObj = viewerDS.getFocusedDocument().getFocusedPage();
                    if (!focusedPageObj) {
                        return;
                    }
                    updateScalePrequisites();
                    scope.updatePageContainerDimension();
                    // showPagesInRange(true);
                };

                var updateScalePrequisites = function updateScalePrequisites() {
                    var pageSettingsObject = {};
                    if (!focusedPageObj || !focusedPageObj.resolution) { return; }
                    var pageResolution = focusedPageObj.resolution.low;
                    pageSettingsObject.imageWidth = pageResolution.width;
                    pageSettingsObject.imageHeight = pageResolution.height;
                    pageSettingsObject.viewPortWidth = pageViewContainer.outerWidth();
                    pageSettingsObject.viewPortHeight = pageViewContainer.outerHeight();
                    //update orientation
                    pageSettingsObject.isPortrait = focusedPageObj.rotation % 180 == 0;
                    //calculate scale (viewport dimension, original image size, orientation, pagefit)
                    pageSettingsObject.scale = calculateScale(pageSettingsObject);
                    //update scale in viewer settings
                    ViewerSettingService.setScale(pageSettingsObject.scale);
                    ViewerSettingService.setPageSettings(pageSettingsObject);
                    //update settings with original image size
                }

                /**
                 * [calculateScale description]
                 * @return {[type]} [description]
                 */
                var calculateScale = function calculateScale(pageSettings) {
                    var scale = 0;
                    switch (ViewerSettingService.getPageFitType()) {
                        case viewerConst.PAGE_FIT_TYPE.DEFAULT:
                            scale = ViewerSettingService.getScale();
                            break;
                        case viewerConst.PAGE_FIT_TYPE.FIT_TO_WIDTH:
                            if (pageSettings.isPortrait) {
                                scale = (pageSettings.viewPortWidth > 35) ? ((pageSettings.viewPortWidth - 35) / pageSettings.imageWidth) : 0;
                            } else {
                                scale = (pageSettings.viewPortWidth > 35) ? ((pageSettings.viewPortWidth - 35) / pageSettings.imageHeight) : 0;
                            }
                            break;
                        case viewerConst.PAGE_FIT_TYPE.BEST_FIT:
                            if (pageSettings.isPortrait) {
                                scale = pageSettings.viewPortWidth / pageSettings.imageWidth;
                                if ((pageSettings.imageHeight * scale) > pageSettings.viewPortHeight) {
                                    scale = pageSettings.viewPortHeight / pageSettings.imageHeight;
                                }
                            } else {
                                scale = pageSettings.viewPortHeight / pageSettings.imageHeight;
                                if ((pageSettings.imageWidth * scale) > pageSettings.viewPortWidth) {
                                    scale = pageSettings.viewPortWidth / pageSettings.imageWidth;
                                }
                            }
                            break;
                    }
                    return scale;
                };

                var updatePages = function updatePages(isScrollReachedLastPos) {
                     var pageViewLimit = ViewerSettingService.getPageViewLimit();

                    //reassigns the start and end limit, if pageLimit index crosses the no of pages available
                    if (initialLimit > 0 && (allPages.length - initialLimit) < pageViewLimit) {
                        initialLimit = (allPages.length) - pageViewLimit;
                        pageLimit = (allPages.length);
                    }

                    viewablePages = allPages.slice(initialLimit, pageLimit);
                    scope.viewablePages = viewablePages;
                    $timeout(function() {
                        //avoids page overlapping as new page containers will be created on virtual scroll
                        //apply the current scaling for all newly created pages
                        focusedPageObj = viewerDS.getFocusedDocument().getFocusedPage();
                        isScrollToFocusedPageReqd = true;
                        updateScalePrequisites();
                        scope.updatePageContainerDimension();
                        //avoid focus to the selected page to maintain the virtual scrolling smoothness
                        if (!isScrollReachedLastPos) {
                            scrollToFocusedPage(focusedPageObj.id);
                        }
                        showPagesInRange(true, true);
                    });
                };

                var loadInitialPages = function loadInitialPages() {
                    scope.viewableDocuments = [];
                    var docIds = _.uniq(_.pluck(viewablePages, 'docId'));
                    _.each(docIds, function(id) {
                        var docObj = viewerDS.getDocumentById(id);
                        docObj.pages = _.where(viewablePages, { 'docId': id });
                        scope.viewableDocuments.push(docObj);
                    });
                    $timeout(function() {
                        scope.updatePageContainerDimension();
                    });
                }

                var loadAdvancePages = function loadAdvancePages(startPage, endPage) {
                    var startPageIndexOfAllPages = _.indexOf(allPages, startPage),
                        endPageIndexOfAllPages = _.indexOf(allPages, endPage);

                    if (endPageIndexOfAllPages === (allPages.length - 1) || startPageIndexOfAllPages === 0) {
                        return;
                    }
                    if (pageViewContainer.scrollTop() === 0) {
                        initialLimit = (initialLimit < pageRangeValue) ? 0 : initialLimit - pageRangeValue;
                        pageLimit = (initialLimit < pageRangeValue) ? initialLimit + ViewerSettingService.getPageViewLimit() : pageLimit - pageRangeValue;
                        updatePages();
                        var selectedPage = $(pageViewContainer.find('.page[page-id="' + startPage.id + '"]'));
                        if (selectedPage.length) {
                            //TODO: scroll position is not changing immediately, need to revisit this area
                            $timeout(function() {
                                pageViewContainer.scrollTop(pageViewContainer.scrollTop() + selectedPage.position().top);
                            });
                        }
                        return;
                    }
                    if ((pageViewContainer.scrollTop() + pageViewContainer.innerHeight() + 10) >= pageViewContainer[0].scrollHeight) {
                        var pageId = allPages[initialLimit + pageRangeValue].id;
                        var rTH1 = $(pageViewContainer.find('.page[page-id="' + pageId + '"]'));
                        var rTH2 = $(pageViewContainer.find('.page[page-id="' + allPages[initialLimit].id + '"]'));
                        var height = (pageId) ? rTH1.position().top - rTH2.position().top : 0;
                        initialLimit = initialLimit + pageRangeValue;
                        pageLimit = pageLimit + pageRangeValue;
                        updatePages(true);
                        pageViewContainer.scrollTop(pageViewContainer.scrollTop() - height);
                        return;
                    }
                }

                var onThhumbSortablityChange = function onThhumbSortablityChange(event, data) {
                    scope.allDocuments = [];
                    isThumbSorted = true;
                    scope.allDocuments = viewerDS.getDocuments();
                    allPages = _.flatten(_.pluck(scope.allDocuments, 'pages'));
                };

                var init = function init() {
                    viewerDS = uiViewerCtrl.getDataSource();
                    pageViewContainer = $(element);
                    isScrollIgnoredReqd = false;
                    //define the viewport dimension on viewer loaded
                    // updateViewPortDimension();

                    showError = null;
                    scope.notificationType = viewerConst.NOTIFICATION_TYPE;
                    scope.allDocuments = viewerDS.getDocuments();
                    scope.updateViewPortDimension = updateViewPortDimension;
                    initialLimit = ViewerSettingService.getInititalLimit();
                    pageLimit = ViewerSettingService.getPageViewLimit();
                    pageRangeValue = ViewerSettingService.getPageViewRange();
                    VS  = uiViewerCtrl.getViewerSettings();
                    //on page scroll
                    //TODO: need to change
                    pageViewContainer.on('scroll', onRightPanelScroll);

                    //shortcuts
                    key.unbind(VS.shortcuts.pageScrollUp);
                    key.unbind(VS.shortcuts.pageScrollDown);

                    key.setScope(viewerConst.SHORTCUT_SCOPE.VIEWER);

                    key(VS.shortcuts.pageScrollUp, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $(pageViewContainer).scrollTop($(pageViewContainer).scrollTop() - 10);
                        console.log($(pageViewContainer).scrollTop());
                        return false;
                    });

                    key(VS.shortcuts.pageScrollDown, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $(pageViewContainer).scrollTop($(pageViewContainer).scrollTop() + 10);
                        console.log($(pageViewContainer).scrollTop());
                        return false;
                    });

                    //Listeners
                    viewerEventsScope = ViewerEvents.getViewerScope();
                    showPages = scope.$on('onLoadPages', onLoadPagesCallback);
                    showNotification = viewerEventsScope.$on(ViewerEvents.SHOW_NOTIFICATION, showNotificationCb);
                    pageChanged = viewerEventsScope.$on(ViewerEvents.PAGE_CHANGED, onPageChangedCallback);
                    documentChanged = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocChangedCallback);
                    viewerResized = viewerEventsScope.$on(ViewerEvents.VIEWER_RESIZED, onViewerResizedCallback);
                    rotationChanged = viewerEventsScope.$on(ViewerEvents.ROTATION_CHANGED, onRotaionChangedCallback);
                    scaleChanged = viewerEventsScope.$on(ViewerEvents.SCALE_CHANGED, onScaleChangedCallback);
                    onNewDocumentAdded = viewerEventsScope.$on(ViewerEvents.NEW_DOCUMENT_ADDED, onNewDocumentAddedCallback);
                    onBeforeDrawAnnotation = viewerEventsScope.$on(ViewerEvents.REMOVE_RAPHAEL_ELEMENT, onBeforeDrawAnnotationCallback);
                    onDeletePages = viewerEventsScope.$on(ViewerEvents.DELETE_PAGES_DONE, onDeletePagesCallback);
                    onThhumbSortablityChange = viewerEventsScope.$on(ViewerEvents.THUMB_SORTABILITY_CHNAGED, onThhumbSortablityChange);

                    scope.$on('$destroy', function() {
                        showPages();
                        showNotification();
                        documentChanged();
                        pageChanged();
                        viewerResized();
                        rotationChanged();
                        scaleChanged();
                        onNewDocumentAdded();
                        onBeforeDrawAnnotation();
                        onDeletePages();
                        onThhumbSortablityChange();
                    });
                };

                init();
            }
        };
    }
]);
