uiv.directive('uiPage', ['$templateCache',
    'uiViewerDatasource',
    '$timeout',
    '$compile',
    'ViewerEvents',
    'ViewerSettingService',
    'viewerConst',
    'ViewerModel',
    'ViewerUtilitis',
    'AnnotationHelperService',
    'PageRenderService',
    'ViewerNotification',
    function($templateCache, uiViewerDatasource, $timeout, $compile, ViewerEvents, ViewerSettingService, viewerConst, ViewerModel, ViewerUtilitis, AnnotationHelperService, PageRenderService, ViewerNotification) {
        return {
            restrict: 'E',
            require: ['^uiViewer', '^uiPageView'],
            scope: {
                page: '=',
                doc: '=',
                docIndex: '=',
                pageIndex: '='
            },
            template: function() {
                return $templateCache.get('../src/views/ui-page.html');
            },
            link: function(scope, element, attr, ctrl) {

                var uiViewerCtrl,
                    uiPageViewCtrl,
                    pageContainer,
                    container,
                    svgContainer,
                    $selection,
                    viewerDS,
                    box,
                    raphaelPaper,
                    raphaelPaperSet,
                    drawnElement,
                    drawnElementFreeTransform,
                    annotationArr,
                    boxTemplate,
                    boxTemplateHtml,
                    mouseDownX,
                    mouseDownY,
                    viewerEventsScope,
                    highlightAnnotation,
                    deleteAnnotation,
                    cancelAnnotation,
                    isAnnotationDrawLocked,
                    imageLoadTimer,
                    VS;

                scope.annotationKeys = viewerConst.ANNOTATION_KEYS;
                scope.annotationText = {};
                scope.resolutionState="MEDIUM";


                /**
                 * [updateSettings description]
                 * @return {[type]} [description]
                 */
                scope.updateSettings = function updateSettings() {
                    uiPageViewCtrl.updateViewport();
                    scope.settings = {
                        viewPortWidth: ViewerSettingService.getViewPortDimension().width,
                        viewPortHeight: ViewerSettingService.getViewPortDimension().height,
                        rotation: scope.page.rotation,
                        imageWidth: scope.page.resolution.low.width,
                        imageHeight: scope.page.resolution.low.height,
                        scale: ViewerSettingService.getScale()
                    }
                    PageRenderService.updateContainerDimension(scope, pageContainer, container, svgContainer);
                };

                /**
                * [renderPageImage description]
                * @return {[type]} pageContent, pageSettings [description]
                */
                scope.renderPageImage = function(pageContent, pageSettings) {
                    var image = new Image();
                    image.onload = function() {
                        var pageSettingsObject = pageSettings;
                        var pageDim = scope.page.getDimension();
                        pageSettingsObject.imageWidth = pageDim.width;
                        pageSettingsObject.imageHeight = pageDim.height;
                        pageSettingsObject.scale = ViewerSettingService.getScale();
                        pageSettingsObject.isPortrait = pageSettings.rotation % 180 == 0;

                        //Add canvas to container
                        var cnv = PageRenderService.getPrintedCanvas(image, pageSettingsObject);

                        container.innerHTML = '';
                        container.appendChild(cnv);

                        //update page property
                        scope.page.setRendered(true);

                        container.setAttribute("data-rotation", pageSettingsObject.rotation);
                        svgContainer.setAttribute("data-rotation", pageSettingsObject.rotation);

                        if (scope.annotationComments) {
                            scope.annotationComments = '';
                        }
                        //unload older one
                        scope.unloadAnnotation();

                        //show annotation
                        scope.loadAnnotation(pageSettingsObject);

                        //appending comment popup to the container
                        boxTemplate = $compile(boxTemplateHtml)(scope);
                        $(svgContainer).append(boxTemplate);
                        $(boxTemplate).hide();
                    };
                    //scope.isLoadingVisible = false;
                    image.src = pageContent;
                };

                scope.onDownloadInvalidDocument = function onDownloadInvalidDocument() {
                    uiViewerCtrl.downloadSourceDocument();
                };




                /**
                * showPropertyBox
                * @description - showing popover for entering annotation comments
                */
                var showPropertyBox = function showPropertyBox(bbox) {
                    $(boxTemplate).css({ left: bbox.x, top: bbox.y2 + 6 }); //popup for rectangle
                    $(boxTemplate).show();

                    if (ViewerSettingService.annotationTypeId === scope.annotationKeys.TEXT) {
                        $('.annotation-text-textbox').focus();
                    } else {
                        $('.annotation-comment-text').focus();
                    }
                };

                /**
                * isIntersected
                * @description - returns true if element is fully placed inside the selected area
                */
                var isIntersected = function isIntersected(selection, element) {
                    var sb = selection.getBBox();
                    var eb = element.getBBox();
                    return (sb.x <= eb.x && sb.x2 >= eb.x2 && sb.y <= eb.y && sb.y2 >= eb.y2);
                };

                /**
                 * [unFocusAnnotations description]
                 * @param {[type]} [description]
                 */
                var unFocusAnnotations = function unFocusAnnotations() {
                    $('.selected-annotation').removeAttr('class')
                };

                /**
                 * [focusAnnotation description]
                 * @param {[type]} [description]
                 */
                var focusAnnotation = function focusAnnotation(node) {
                    unFocusAnnotations();
                    node.setAttribute('class', 'selected-annotation');
                    uiPageViewCtrl.scrollToFocusedAnnotation(node.getAttribute('annotation-id') || node.parentNode.getAttribute('annotation-id'));

                    //highlight selected annotation's comment
                    ViewerEvents.notify(ViewerEvents.HIGHLIGHT_ANNOTATION_COMMENT, node.getAttribute('annotation-id') || node.parentNode.getAttribute('annotation-id'));
                };

                /**
                * [postDrawnElement description]
                * @param  {[type]} bbox [description]
                */
                var postDrawnElement = function postDrawnElement(bbox) {
                    //add the new drawnElement into raphael set
                    raphaelPaperSet.push(drawnElement);
                    var transformString = AnnotationHelperService.getTransformationString(scope.settings);

                    //apply freeTransform to the new drawnElement
                    drawnElementFreeTransform = AnnotationHelperService.applyFreeTransform(raphaelPaper, scope.settings, drawnElement, bbox.scaledBbox, transformString);

                    //apply tranformation
                    drawnElement.transform(transformString);

                    //show property box
                    showPropertyBox(drawnElement.getBBox());
                };

                /**
                 * [drawShape description]
                 * @param  {[type]} boxObj [description]
                 */
                var drawShape = function drawShape(boxObj) {

                    if (isAnnotationDrawLocked) {
                        ViewerNotification.showError(new ViewerModel.Error({
                            code: VS.errorCodes.ANNOTATION_IN_PROGRESS,
                            message: VS.errorMessages[VS.errorCodes.ANNOTATION_IN_PROGRESS]
                        }));
                        return;
                    }

                    ViewerEvents.notify(ViewerEvents.REMOVE_RAPHAEL_ELEMENT, scope.page.id);
                    if ($('.box-template').is(':visible')) {
                        scope.onCancelAnnotation();
                    }

                    if (!boxObj) {
                        return;
                    }

                    var ele, eleFt;

                    annotationArr = viewerDS.getAnnotations();

                    //Before selecting/drawing the elements, hide the freetransform
                    _.each(annotationArr, function(obj) {
                        eleFt = obj.drawnElementFreeTransform;
                        if (eleFt) {
                            eleFt.hideHandles();
                        }
                    });

                    switch (ViewerSettingService.annotationTypeId) {
                        case 1:
                            if (boxObj.w < 40) {
                                return;
                            }
                            break;

                        case 2:
                            //Comment
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);
                            var iconSize = 20 / scope.settings.scale;

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawCommentAnnotation(raphaelPaper, bbox, iconSize);
                            postDrawnElement(bbox);
                            break;

                        case 3:
                            //Underline
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawUnderlineAnnotation(raphaelPaper, bbox, scope.settings);
                            drawnElement.attr({ stroke: '#00f' });
                            postDrawnElement(bbox);
                            break;

                        case 4:
                            //Text
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawTextAnnotation(raphaelPaper, bbox, scope.settings);

                            //Raphael workaround: If the text is empty, it makes all the getBBox property as zero
                            $timeout (function(){
                                drawnElement.attr('text', '');
                            });

                            drawnElement.attr({ 'fill': '#EB4545', 'stroke-width': 0, 'font-size': 1, 'font-family': 'Arial' });
                            postDrawnElement(bbox);
                            break;

                        case 5:
                            //Strikeout
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawStrikeoutAnnotation(raphaelPaper, bbox, scope.settings);
                            drawnElement.attr({ stroke: '#f00' });
                            postDrawnElement(bbox);
                            break;

                        case 6:
                            //Erase
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawEraseAnnotation(raphaelPaper, bbox);
                            postDrawnElement(bbox);
                            break;
                        case 7:
                            //Redaction
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawRedactionAnnotation(raphaelPaper, bbox);
                            postDrawnElement(bbox);
                            break;
                        case 8:
                            //Highlight
                            var bbox = AnnotationHelperService.getBboxInFullScale(raphaelPaper, boxObj, scope.settings);

                            //draw respective element
                            drawnElement = AnnotationHelperService.drawHighlightAnnotation(raphaelPaper, bbox);
                            postDrawnElement(bbox);
                            break;
                    }
                };

                /**
                * [pageMousedownEvent description]
                * @param  {[type]} event [description]
                */
                var pageMousedownEvent = function pageMousedownEvent(e) {
                    box = null;
                    if (!raphaelPaper || !raphaelPaperSet || e.target.tagName !== 'svg') {
                        return;
                    }

                    currentContainer = $(e.currentTarget);
                    var offset = currentContainer.offset();
                    mouseDownX = e.pageX - offset.left;
                    mouseDownY = e.pageY - offset.top;

                    $selection.css({
                        'top': mouseDownY,
                        'left': mouseDownX,
                        'width': 0,
                        'height': 0
                    });

                    $selection.appendTo(currentContainer);

                    element.on('mousemove', pageMousemoveEvent);
                    element.on('mouseleave', pageMouseleaveEvent);
                    e.stopPropagation();
                };

                /**
                * [pageMousemoveEvent description]
                * @param  {[type]} event [description]
                */
                var pageMousemoveEvent = function pageMousemoveEvent(e) {
                    if (!raphaelPaper || !raphaelPaperSet || e.target.tagName !== 'svg') {
                        return;
                    }

                    var offset = currentContainer.offset(),
                        moveX = e.pageX - offset.left,
                        moveY = e.pageY - offset.top,
                        width = Math.abs(moveX - mouseDownX),
                        height = Math.abs(moveY - mouseDownY),
                        newX = (moveX < mouseDownX) ? (mouseDownX - width) : mouseDownX,
                        newY = (moveY < mouseDownY) ? (mouseDownY - height) : mouseDownY;
                    box = {
                        w: width,
                        h: height,
                        x: newX,
                        y: newY
                    };

                    $selection.css({
                        'width': box.w,
                        'height': box.h,
                        'top': box.y,
                        'left': box.x
                    });
                    e.stopPropagation();
                };

                /**
                * [pageMouseupEvent description]
                * @param  {[type]} event [description]
                */
                var pageMouseupEvent = function pageMouseupEvent(e) {
                    // e.stopImmediatePropagation()
                    element.off('mousemove');
                    element.off('mouseleave');

                    if (!raphaelPaper || !raphaelPaperSet || e.target.getAttribute('id') === 'box-template' || $(e.target).parents('#box-template').length === 1) {
                        return;
                    }

                    if ($selection) {
                        drawShape(box);
                        $selection.remove();
                    }
                };

                /**
                * [pageMouseleaveEvent description]
                * @param  {[type]} event [description]
                */
                var pageMouseleaveEvent = function pageMouseleaveEvent(e) {
                    element.off('mousemove');
                    pageMouseupEvent(e);
                };

                /**
                * [bindAnnotationClick description]
                * @param  {[type]} Either raphaelSet or drawnElement [description]
                */
                var bindAnnotationClick = function bindAnnotationClick(elements) {
                    //Here elements denotes drawnElement
                    if (!$.isArray(elements)) {
                        elements.click(function() {
                            focusAnnotation(elements.node);
                        });
                        return;
                    }

                    //Here elements are raphaelSet items
                    var el;
                    for (var i = 0, len = elements.length; i < len; i++) {
                        el = elements[i];
                        el.click(function(event) {
                            focusAnnotation(event.target);
                        });
                    }

                };

                /**
                * [bindAnnotationEvents description]
                * @param  {[type]} [description]
                */
                scope.bindAnnotationEvents = function bindAnnotationEvents() {
                    //unbind events
                    element.off('mousedown', pageMousedownEvent);
                    element.off('mouseup', pageMouseupEvent);
                    //bind events
                    element.on('mousedown', '.page-contr', pageMousedownEvent);
                    element.on('mouseup', '.page-contr', pageMouseupEvent);
                };

                /**
                * [unbindAnnotationEvents description]
                * @param  {[type]} [description]
                */
                scope.unbindAnnotationEvents = function unbindAnnotationEvents() {
                    element.off('mousedown', pageMousedownEvent);
                    element.off('mousemove', pageMousemoveEvent);
                    element.off('mouseup', pageMouseupEvent);
                    element.off('mouseleave', pageMouseleaveEvent);
                };

                /**
                 * [showImage description]
                 * @return {[type]} [description]
                 */
                scope.showImage = function showImage(isForcefully, isPriority) {

                    scope.loadPage(isForcefully, isPriority);

                };

                /**
                 * initiate loading image
                 * @return {[type]} [description]
                 */
                scope.loadPage = function loadPage(isForcefully, isPriority) {
                    //unload older canvas
                    scope.unloadImage();
                    //update settings
                    scope.updateSettings();
                    //gets document object
                    var docObj = viewerDS.getDocumentById(scope.page.docId);
                    //get image data
                    var imageData=viewerDS.getPageImageFromStorage(scope.page.id, "MEDIUM");

                    if(imageData){
                      scope.renderPageImage(imageData.data.data, scope.settings);
                    }
                    else {
                      imageData=viewerDS.getPageImageFromStorage(scope.page.id, "LOW");
                      if(imageData){
                        scope.renderPageImage(imageData.data.data, scope.settings);
                      }
                      else{
                        scope.loadPageFromAPI(docObj,isForcefully, isPriority,"LOW");
                      }

                      imageLoadTimer = $timeout(function(){
                        scope.loadPageFromAPI(docObj,isForcefully, isPriority,"MEDIUM");
                      },1000);

                }


                scope.loadPageFromAPI=function loadPageFromAPI(docObj,isForcefully, isPriority,resolution) {

                  viewerDS.getPageImage(scope.page.id,"PAGE", docObj.status, isForcefully, isPriority,resolution).then(function(imageData){
                    scope.renderPageImage(imageData.data.data, scope.settings);
                  },function(error) {

                  });
                }

                scope.cancelTimer=function cancelTimer() {

                $timeout.cancel(imageLoadTimer);

                };

                /**
                * [unloadAnnotation description]
                * @param  {[type]} [description]
                */
                scope.unloadAnnotation = function unloadAnnotation() {
                    $(svgContainer).empty();
                };

                /**
                 * initiate loading Annotation
                 * @return {[type]} [description]
                 */
                scope.loadAnnotation = function loadAnnotation(pageSettingsObject) {
                    if (VS.actions.business.annotation.read) {

                        //init svg
                        var svg = {};
                        svg.width = ((pageSettingsObject.isPortrait) ? pageSettingsObject.imageWidth : pageSettingsObject.imageHeight) * pageSettingsObject.scale;
                        svg.height = ((pageSettingsObject.isPortrait) ? pageSettingsObject.imageHeight : pageSettingsObject.imageWidth) * pageSettingsObject.scale;
                        //initialzing Raphael
                        raphaelPaper = Raphael(svgContainer, svg.width, svg.height);

                        //load all annotations
                        uiViewerCtrl.getAllAnnotations(scope.page.id).then(function(annotationObjArr) {
                            var dom = '';
                            var content = '';

                            //clear the paper and create new set
                            raphaelPaper.clear();
                            raphaelPaperSet = raphaelPaper.set();

                            //append raphael elements
                            for (var i = 0, len = annotationObjArr.length; i < len; i++) {
                                content = annotationObjArr[i].content;
                                content = content.replace('&gt;', ' annotation-id=&quot;' + annotationObjArr[i].id + '&quot;&gt;');
                                dom += ViewerUtilitis.htmlUnescape(content);

                                //update raphael object to annotation object
                                annotationObjArr[i].drawnElement = drawnElement;
                                annotationObjArr[i].drawnElementFreeTransform = drawnElementFreeTransform;

                                //add elements to paper set
                                raphaelPaperSet.push(drawnElement);

                                //add annotation object to store
                                viewerDS.addAnnotation(annotationObjArr[i], false);
                            }
                            //notify update comment view
                            ViewerEvents.notify(ViewerEvents.UPDATE_COMMENT_REPLY);
                            dom = '<svg>' + dom + '</svg>';

                            raphaelPaper.importSVG(dom, raphaelPaperSet);

                            bindAnnotationClick(raphaelPaperSet.items);

                            raphaelPaperSet.forEach(function(ele, index){
                                if (ele && ele.type === 'path') {
                                    ele.attr({ 'stroke-width': '2'});
                                }
                            });


                            //apply transformation
                            raphaelPaperSet.transform(AnnotationHelperService.getTransformationString(scope.settings));
                        }, function(error) {
                            isAnnotationDrawLocked = false;
                            //clear the paper and create new set. User should be able to draw eventhough annotation API fails
                            raphaelPaper.clear();
                            raphaelPaperSet = raphaelPaper.set();
                        });
                    }

                };

                /**
                 * [unloadImage description]
                 * @return {[type]} [description]
                 */
                scope.unloadImage = function unloadImage() {
                    $(container).empty();
                    $(svgContainer).empty();
                    scope.isLoadingVisible = false;
                    scope.page.setRendered(false);
                };

                /**
                * [onHighlightAnnotation - callback ]
                * @return {[type]} event, annotationId [description]
                */
                var onHighlightAnnotation = function onHighlightAnnotation(event, annotationId) {
                    if (raphaelPaperSet && raphaelPaperSet.length) {

                        var toFocusAnnotation = _.find(raphaelPaperSet, function(obj) {
                            if (obj && obj.node) {
                                return obj.node.getAttribute('annotation-id') === annotationId;
                            }
                        });

                        if (toFocusAnnotation) {
                            focusAnnotation(toFocusAnnotation.node);
                        }
                    }
                };

                /**
                 * [onDeleteAnnotation - callback ]
                 * @return {[type]} event, annotationId [description]
                 */
                var onDeleteAnnotation = function onDeleteAnnotation(e, annotationId) {
                    _.each(raphaelPaperSet, function(obj) {
                        if (obj && obj.node && obj.node.getAttribute('annotation-id') === annotationId) {
                            obj.remove();
                            //TODO remove drwanElement Freetransform
                            //eleFt.unplug();
                        };
                        ViewerEvents.notify(ViewerEvents.UPDATE_COMMENT_REPLY);
                    })
                };

                /**
                 * [isAnnotationText description]
                 * @return {[type]}
                 */
                scope.isAnnotationText = function isAnnotationText() {
                    return ViewerSettingService.annotationTypeId === scope.annotationKeys.TEXT;
                };

                /**
                * [onSaveAnnotation description]
                * @return {[type]}
                */
                scope.onSaveAnnotation = function onSaveAnnotation() {
                    //API call to save the annotation, clear the ng-model and hide the popup
                    var commentModel = new ViewerModel.Comment({
                        comment: scope.annotationComments
                    });

                    //For annotation text, replace the default text by the user defined value
                    if (ViewerSettingService.annotationTypeId === scope.annotationKeys.TEXT) {
                        drawnElement.attr('text', scope.annotationText.val);
                        drawnElement.attr({'font-size': '20px'});//should not remove the font-size, workaround for raphael text
                    }

                    var annotationModel = AnnotationHelperService.constructAnnotationModel(scope.page, commentModel, svgContainer, drawnElement, drawnElementFreeTransform);

                    isAnnotationDrawLocked = true;
                    scope.canSaveAnnotation = false;
                    uiViewerCtrl.createAnnotation(annotationModel).then(function(annotationResponse) {
                        viewerDS.addAnnotation(annotationResponse, true);

                        //update comment reply section
                        ViewerEvents.notify(ViewerEvents.UPDATE_COMMENT_REPLY);

                        //bind click event on the drawnElement
                        bindAnnotationClick(drawnElement);

                        //update raphael object to annotation object
                        annotationResponse.drawnElement = drawnElement;
                        annotationResponse.drawnElementFreeTransform = drawnElementFreeTransform;

                        raphaelPaperSet.push(drawnElement);

                        scope.annotationText.val = '';
                        scope.annotationComments = '';
                        $(boxTemplate).hide();
                        isAnnotationDrawLocked = false;
                        scope.canSaveAnnotation = true;
                        //set annotation id into the drawnElement node inorder to get the drawnElement reference during loadAnnotation
                        drawnElement.node.setAttribute('annotation-id', annotationResponse.id);
                        drawnElement = null;
                    }, function(error) {
                        scope.annotationText.val = '';
                        scope.annotationComments = '';
                        $(boxTemplate).hide();
                        isAnnotationDrawLocked = false;
                        scope.canSaveAnnotation = true;
                        drawnElement = null;
                    });

                    if (drawnElementFreeTransform) {
                        drawnElementFreeTransform.hideHandles();
                    }

                };

                /**
                * [onCancelAnnotation description]
                * @return {[type]}
                */
                scope.onCancelAnnotation = function onCancelAnnotation() {

                    if (isAnnotationDrawLocked) return;

                    scope.annotationText.val = '';
                    scope.annotationComments = '';
                    isAnnotationDrawLocked = false;

                    if (drawnElement) {
                        drawnElement.remove();
                    }
                    if (drawnElementFreeTransform) {
                        drawnElementFreeTransform.unplug();
                    }
                    $(boxTemplate).hide();
                };

                /**
                * [init description]
                * @return {[type]}
                */
                var init = function init() {
                    uiViewerCtrl = ctrl[0];
                    uiPageViewCtrl = ctrl[1];
                    pageContainer = element[0].querySelector('.page-contr');
                    container = element[0].querySelector('.pageCanvasContainer');
                    svgContainer = element[0].querySelector('.pageSvgContainer');
                    viewerDS = uiViewerCtrl.getDataSource();
                    VS = uiViewerCtrl.getViewerSettings();
                    annotationArr = [];
                    boxTemplateHtml = AnnotationHelperService.buildBoxTemplate();
                    $selection = $('<div>').addClass('selection-box');
                    box = {};
                    isAnnotationDrawLocked = false;
                    scope.canSaveAnnotation = true;

                    viewerDS.addElement(scope.page.id, element);

                    $(svgContainer).hover(function(event) {
                        if ((ViewerSettingService.annotationTypeId === scope.annotationKeys.COMMENT
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.UNDERLINE
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.TEXT
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.STRIKEOUT
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.ERASE
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.REDACTION
                            || ViewerSettingService.annotationTypeId === scope.annotationKeys.HIGHLIGHT)
                            && (!isAnnotationDrawLocked)) {
                            $(this).css('cursor', 'crosshair');
                        } else {
                            $(this).css('cursor', 'default');
                        }
                    });

                    //Inorder to work in IE, we have manually adding outerHTML to the element
                    Object.defineProperty(SVGElement.prototype, 'outerHTML', {
                        get: function () {
                            var $node, $temp;
                            $temp = document.createElement('div');
                            $node = this.cloneNode(true);
                            $temp.appendChild($node);
                            return $temp.innerHTML;
                        },
                        enumerable: false,
                        configurable: true
                    });

                    //LISTENERS
                    viewerEventsScope = ViewerEvents.getViewerScope();

                    highlightAnnotation = viewerEventsScope.$on(ViewerEvents.HIGHLIGHT_ANNOTATION, onHighlightAnnotation);
                    deleteAnnotation = viewerEventsScope.$on(ViewerEvents.DELETE_ANNOTATION, onDeleteAnnotation);
                    cancelAnnotation = viewerEventsScope.$on(ViewerEvents.CANCEL_ANNOTATION, scope.onCancelAnnotation);
                    scope.$on('$destroy', function() {
                        highlightAnnotation();
                        deleteAnnotation();
                        cancelAnnotation();
                    });
                };

                init();
            }
        };
    }
]);
