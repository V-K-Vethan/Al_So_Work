uiv.directive('uiThumbnail', [
    '$document',
    '$compile',
    '$parse',
    '$timeout',
    'ViewerEvents',
    'uiViewerDatasource',
    'ViewerSettingService',
    'viewerConst',
    'ViewerNotification',
    'ViewerModel',
    function($document, $compile, $parse, $timeout, ViewerEvents, uiViewerDatasource, ViewerSettingService, viewerConst, ViewerNotification, ViewerModel) {

        return {
            restrict: 'E',
            require: ['^uiViewer', '^uiThumbnailView'],
            scope: {
                thumb: '=',
                doc: '=',
                docIndex: '=',
                thumbIndex: '=',
                thumbId: '='
            },
            templateUrl: '../src/views/ui-thumbnail.html',
            link: function(scope, element, attrs, ctrl) {
                var uiViewerCtrl,
                    uiThumbnailViewCtrl,
                    viewerDS,
                    viewerSettings,
                    container,
                    thumbnailScope,
                    VS;

                scope.showThumbImage = function(isForcefully, isPriority){
                    scope.isThumbLoadingVisible = true;
                    viewerDS.getImage(scope.thumb.id, "THUMBNAIL", scope.doc.status, isForcefully, isPriority).then(function(result){
                        renderThumbImage(result.data.data);
                    }, function(error){
                        //TODO: need to handle the error scenarios
                        // show error message
                    });
                };

                scope.unloadThumbImage = function(){
                    container.innerHTML = '';
                    scope.isThumbLoadingVisible = false;
                    scope.thumb.setIsThumbRendered(false);
                };

                /**
                 * draws the image on the canvas
                 * @return {[canvas]} [description]
                 */
                var getPrintedCanvas = function getPrintedCanvas(image) {
                    var canvas = document.createElement('canvas');
                    var ctx = canvas.getContext("2d");
                    canvas.width = image.width;
                    canvas.height = image.height;
                    ctx.drawImage(image, 0, 0, image.width, image.height, 0, 0, canvas.width, canvas.height);
                    return canvas;
                };

                /**
                 * loads the images into the thumbnail canvas
                 */
                var renderThumbImage = function renderThumbImage(pageContent) {
                    var image = new Image();
                    image.onload = function() {
                        scope.unloadThumbImage();
                        container.appendChild(getPrintedCanvas(image));
                        scope.thumb.setIsThumbRendered(true);
                    };
                    scope.isThumbLoadingVisible = false;
                    image.src = pageContent;
                };

                var currentFocusedPage, shortCutFocusedPage;
                var setCurrentSelectedThumbByDownArrow = function (isMultiThumbSelectedUsingShift) {
                    $timeout(function() {
                        //using shift key
                        var focusedDoc = viewerDS.getFocusedDocument();
                        currentFocusedPage = focusedDoc.getFocusedPage();

                        var shortCutFocusedPage = ViewerSettingService.getShortCutFocusedPage();
                        var currPageIndex = focusedDoc.pages.indexOf(currentFocusedPage);
                        var shortCutFocusedPageIndex = focusedDoc.pages.indexOf(shortCutFocusedPage);

                        if (ViewerSettingService.getShortCutState() === 'ctrl') {
                            viewerDS.clearSelectedThumbs();
                            viewerDS.focusPage(focusedDoc.pages[currPageIndex], null, currentFocusedPage, true);
                            ViewerSettingService.setPageSelectDirection('');
                        } else if (shortCutFocusedPage && shortCutFocusedPage.pageNumber < currentFocusedPage.pageNumber) {
                            ViewerSettingService.setPageSelectDirection('downwards');
                        }
                        ViewerSettingService.setShortCutState('shift');
                        viewerDS.toggleNextPage(focusedDoc, currPageIndex, shortCutFocusedPageIndex);
                    });
                };

                var setCurrentSelectedThumbByUpArrow = function (isMultiThumbSelectedUsingShift) {
                    $timeout(function() {
                        //using shift key
                        var focusedDoc = viewerDS.getFocusedDocument();
                        currentFocusedPage = focusedDoc.getFocusedPage();

                        var shortCutFocusedPage = ViewerSettingService.getShortCutFocusedPage();
                        var currPageIndex = focusedDoc.pages.indexOf(currentFocusedPage);
                        var shortCutFocusedPageIndex = focusedDoc.pages.indexOf(shortCutFocusedPage);

                        if (ViewerSettingService.getShortCutState() === 'ctrl') {
                            viewerDS.clearSelectedThumbs();
                            viewerDS.focusPage(focusedDoc.pages[currPageIndex], null, currentFocusedPage, true);
                            ViewerSettingService.setPageSelectDirection('');
                        } else if (shortCutFocusedPage && shortCutFocusedPage.pageNumber > currentFocusedPage.pageNumber) {
                            ViewerSettingService.setPageSelectDirection('upwards');
                        }
                        ViewerSettingService.setShortCutState('shift');
                        viewerDS.togglePrevPage(focusedDoc, currPageIndex, shortCutFocusedPageIndex);
                    });
                };

                var setCurrentSelectedThumb = function setCurrentSelectedThumb(isMultiThumbSelected, isMultiThumbSelectedUsingShift) {
                    $timeout(function() {
                        var focusedDoc = viewerDS.getFocusedDocument();

                        //using shift click
                        if (isMultiThumbSelectedUsingShift) {
                            currentFocusedPage = ViewerSettingService.getShortCutFocusedPage();
                            ViewerSettingService.setShortCutState('shift');
                            viewerDS.clearSelectedThumbs();
                            currentFocusedPage.focus();
                            var previousFocusedDoc = ViewerSettingService.getPreviousFocusedDoc();
                            var currPageIndex = focusedDoc.pages.indexOf(currentFocusedPage);
                            var selectedPageIndex = focusedDoc.pages.indexOf(scope.thumb);
                            var toSelectDoc;
                            if (selectedPageIndex === -1) {
                                toSelectDoc = previousFocusedDoc;
                                if (viewerDS.getDocIndexById(scope.doc.id) < viewerDS.getDocIndexById(previousFocusedDoc.id)) {
                                    selectedPageIndex = 0;
                                } else {
                                    selectedPageIndex = viewerDS.getDocumentById(previousFocusedDoc.id).pages.length - 1;
                                }
                                ViewerNotification.showError(new ViewerModel.Error({
                                    code: VS.errorCodes.MULTISELECT_THUMB_RESTRICT,
                                    message: VS.errorMessages[VS.errorCodes.MULTISELECT_THUMB_RESTRICT]
                                }));
                            } else {
                                toSelectDoc = scope.doc;
                            }
                            currentFocusedPage.deSelect();
                            if (selectedPageIndex > currPageIndex) {
                                PageFromIndex = currPageIndex;
                                PageToIndex = selectedPageIndex;
                                ViewerSettingService.setPageSelectDirection('downwards');
                                for(var i = PageFromIndex, len = PageToIndex; i <= len; i++) {
                                    viewerDS.setSelectedThumb(toSelectDoc, toSelectDoc.pages[i].id, isMultiThumbSelectedUsingShift);
                                }
                            } else {
                                PageFromIndex = selectedPageIndex;
                                PageToIndex = currPageIndex;
                                ViewerSettingService.setPageSelectDirection('upwards');
                                for(var i = PageToIndex, len = PageFromIndex; i >= len; i--) {
                                    viewerDS.setSelectedThumb(toSelectDoc, toSelectDoc.pages[i].id, isMultiThumbSelectedUsingShift);
                                }
                            }
                            return;
                        }

                        /*using ctrl click and single click*/

                        //avoid multiple page selection across document using ctrl click
                        if (isMultiThumbSelected && (focusedDoc.getFocusedPage().docId !== scope.thumb.docId)) {
                            ViewerNotification.showError(new ViewerModel.Error({
                                code: VS.errorCodes.MULTISELECT_THUMB_RESTRICT,
                                message: VS.errorMessages[VS.errorCodes.MULTISELECT_THUMB_RESTRICT]
                            }));
                            return;
                        }
                        //allow multiple page selection
                        viewerDS.setSelectedThumb(scope.doc, scope.thumb.id, isMultiThumbSelected);//not selecting the thumbs properly if timeout is removed
                        ViewerSettingService.setPreviousFocusedDoc(scope.doc);
                        ViewerSettingService.setShortCutFocusedPage(scope.thumb);
                        ViewerSettingService.setShortCutState('ctrl');
                    });
                };

                var init = function init() {
                    ViewerEvents.setThumbnailScope(scope);
                    uiViewerCtrl        = ctrl[0];
                    uiThumbnailViewCtrl = ctrl[1];
                    viewerDS            = uiViewerCtrl.getDataSource();
                    viewerSettings      = viewerDS.getPageSettings();
                    container           = element[0].querySelector('.thumbCanvasContainer');
                    thumbnailScope      = ViewerEvents.getThumbnailScope();
                    VS                  = uiViewerCtrl.getViewerSettings();
                    //TODO values comes from the settings
                    $(container).width(70);
                    $(container).height(100);
                    //register this to parent
                    uiThumbnailViewCtrl.addThumbnail(element);
                    element.bind('mouseup', function(event) {
                        if (!event.shiftKey && !event.ctrlKey) {
                            setCurrentSelectedThumb(false);
                            return;
                        }
                        if (event.shiftKey) {
                            setCurrentSelectedThumb(false, true);
                            return;
                        }
                        if (event.ctrlKey) {
                            setCurrentSelectedThumb(true);
                            return;
                        }
                    });

                    key.unbind(VS.shortcuts.selectPagesUp);
                    key.unbind(VS.shortcuts.selectPagesDown);
                    key.unbind(VS.shortcuts.prevDoc);
                    key.unbind(VS.shortcuts.nextDoc);

                    key.setScope(viewerConst.SHORTCUT_SCOPE.VIEWER);

                    key(VS.shortcuts.selectPagesUp, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        // $timeout(function() {
                        setCurrentSelectedThumbByUpArrow(true);
                        // });
                        return false;
                    });

                    key(VS.shortcuts.selectPagesDown, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        // $timeout(function() {
                        setCurrentSelectedThumbByDownArrow(true);
                        // });
                        return false;
                    });

                    key(VS.shortcuts.prevDoc, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $timeout(function() {
                            viewerDS.setPrevDocumentFocus(viewerDS.getFocusedDocument().id);
                        });
                        return false;
                    });

                    key(VS.shortcuts.nextDoc, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $timeout(function() {
                            viewerDS.setNextDocumentFocus(viewerDS.getFocusedDocument().id);
                        });
                        return false;
                    });
                };

                init();
            }
        };
    }
]);
