uiv.directive('uiViewer', [
    '$document',
    '$compile',
    '$parse',
    '$timeout',
    '$templateCache',
    'ViewerEvents',
    'ViewerSettingService',
    'ViewerModel',
    'ViewerSetting',
    'ViewerNotification',
    'viewerConst',
    'ViewerClipboardService',
    function($document, $compile, $parse, $timeout, $templateCache, ViewerEvents, ViewerSettingService, ViewerModel, ViewerSetting, ViewerNotification, viewerConst, ViewerClipboardService) {

        return {
            restrict: 'A',
            scope: {
                docViewer: "=",
                rDataSource: "=",
                rSettings: "=",
                rDeletePages: "&",
                rSplitDocument: "&",
                rMergeDocuments: "&",
                rShowDoc: "&",
                rReorder: "&",
                rReorderBulkPages: "&",
                rOnDocumentChange: "&",
                rDownloadSelectivePages: "&",
                rDownloadSourceDocument: "&",
                rCreateAnnotation: "&",
                rGetAllAnnotations: "&",
                rDeleteAnnotation: "&",
                rReplyComment: "&",
                rDeleteComment: "&",
                rOnUpdateDocument: "&",
                rOnViewChange: "&"
            },
            controller: 'uiViewerController',
            controllerAs: '$uiViewer',
            template: function() {
                return $templateCache.get('../src/views/uiViewer.html');
            },
            transclude: true,
            link: function(scope, element, attr, ctrl, transcludeFn, transScope) {
                //variable declaration
                var viewerControls;
                var viewerEventsScope;
                var documentChanged;
                var viewerSetting;
                var populateDocumentView = function populateDocumentView(id, view) {
                    element.find('#' + id).append($compile(view.contents())(scope));
                };

                var onDocChangedCallback = function onDocChangedCallback() {
                    scope.allDocuments = scope.rDataSource.getDocuments();
                    scope.focusedDocument = scope.rDataSource.getFocusedDocument();
                    if (ViewerClipboardService.getCutDocuments()) { return; }
                    if (scope.focusedDocument) {
                        //sets all edit operation disabled for inprogress and failed document
                        if (!scope.focusedDocument.isValidDoc) {
                            ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.DISABLE_EDIT);
                        } else {
                            ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.BASIC);
                        }
                        ViewerSettingService.setCurrentDocTotalPages(scope.focusedDocument.pages.length);
                    }
                    // scope.rDataSource.notifySidePanelNavView();
                };  

                 var addMenus = function addMenus() {
                    var i = 0;
                    for (var item in  viewerSetting.VIEWER_NAV_MENU) {
                        i++;
                        //default menus
                        if ((item === viewerConst.NAV_VIEWS.THUMBNAIL) || 
                            (item === viewerConst.NAV_VIEWS.META_DATA) || 
                            (item === viewerConst.NAV_VIEWS.COMMENT)) {
                            continue;
                        }
                        //user defined menu object
                        var menuObj = viewerSetting.VIEWER_NAV_MENU[item];
                        //DOM for new menu
                        var menuDOM = '<li id="sidePane'+ menuObj.id +'" \
                                        ng-class="{\'side-pane-selected-icon\' : (sidePaneSelectedButton=='+i+'), \'ng-viewer-theme-text\' : (sidePaneSelectedButton=='+i+'), \'disable-button\': !allDocuments.length || ' + menuObj.disabled + '}">\
                                        <button class="ng-viewer-theme-btn side-panel-icons no-border"\
                                         ng-click="changeView(\'' + menuObj.label + '\', sidePaneSelectedButton='+i+');" \
                                         title="' + menuObj.tooltips + '"><i class="fa ' + menuObj.icon + '"></i></button>\
                                        </li>'
                        //compiles the menu and adding dynamically
                        $('#viewerMenuList').append($compile(menuDOM)(scope));
                        var menuContent = '<div id="' + menuObj.id + '" style="height: 100%" ng-show="leftSectionSelectedView == \''+ menuObj.label +'\'"></div>'
                        //append to viewer pane
                        $('#viewer-content .split-pane1').append($compile(menuContent)(scope));
                        //matches the external content based on the role property
                        var viewContent = transcludeFn().filter('[role="' + menuObj.id + '"]');
                        //appends external application content to the view
                        populateDocumentView(menuObj.id, viewContent);
                    }
                };

                var init = function init() {
                    scope.allDocuments = [];
                    var documentView = transcludeFn().filter('[role="documentView"]');
                    populateDocumentView('documentViewContent', documentView);
                    viewerSetting = scope.rSettings;
                    //Listeners
                    viewerEventsScope = ViewerEvents.getViewerScope();
                    documentChanged = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocChangedCallback);
                    scope.$on('$destroy', function() {
                        documentChanged();
                    });

                    //grabbing the rfng theme
                    $timeout(function() {
                        //disable right click
                        addMenus();
                        element.on("contextmenu", function(e) {
                            e.preventDefault();
                            var error = new ViewerModel.Error({
                                code: viewerSetting.errorCodes.RIGHT_CLICK_DISABLED,
                                message: viewerSetting.errorMessages[viewerSetting.errorCodes.RIGHT_CLICK_DISABLED]
                            });
                            $timeout(function() {
                                ViewerNotification.showError(error);
                            });
                        });

                        var ngvThemeColor = $('#theme').css('color');
                        $("<style type='text/css'>" +
                        ".ng-viewer-theme-border{ border-color: " + ngvThemeColor + " !important} " +
                        ".ng-viewer-theme-bg{ background-color: " + ngvThemeColor + " !important} " +
                        ".ng-viewer-theme-text{ color: " + ngvThemeColor + " !important} " +
                        ".ng-viewer-theme-btn:hover{ color: " + ngvThemeColor + " !important} " +
                        "</style>").appendTo("head");
                    }, 700);
                };

                init();
            }
        };
    }
]);
