uiv.directive('scroller', function(){
    return {
        restrict: 'A',
        scope: {
            scrollMethod: '&scroller'
        },
        link: function(scope,elem,attrs){
            $(elem).on('scroll', function(evt){
               scope.$apply(scope.scrollMethod());
            });
        }
    };
});
