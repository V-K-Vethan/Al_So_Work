"use strict";

uiv.directive('uiCommentView', ['$templateCache', '$timeout', 'viewerConst', 'ViewerEvents', function($templateCache, $timeout, viewerConst, ViewerEvents) {
    return {
        restrict: 'E',
        require: '^uiViewer',
        template: function () {
            return $templateCache.get('../src/views/ui-comment-view.html');
        },
        link: function (scope, element, attrs, uiViewerCtrl) {

            var focusedPageObj,
                viewerDS,
                commentViewContainer,
                updateComment,
                pageChanged,
                navToThumb,
                highlightAnnotationComment,
                viewerEventsScope,
                VS;

            var updateComments = function updateComments () {
                var focusedDoc = viewerDS.getFocusedDocument();
                if (focusedDoc) {
                    focusedPageObj = focusedDoc.getFocusedPage();
                    if (focusedPageObj) {
                        scope.annotations = viewerDS.getAnnotationByPageId(focusedPageObj.id);
                    }
                }
            };

            var updateCommentReply = function updateCommentReply () {
                updateComments();
            };

            var onPageChangedCallback = function onPageChangedCallback () {
                updateComments();
            };

            var onHighlightAnnotationComment = function onHighlightAnnotationComment (e, annotationId) {
                focusedPageObj = viewerDS.getFocusedDocument().getFocusedPage();
                scope.annotations = viewerDS.getAnnotationByPageId(focusedPageObj.id);

                $timeout(function () {
                    scope.focusedAnnotation = annotationId;
                    var ele = $(element.find('.comment-box #'+annotationId));

                    if (ele && ele.length) {
                        if (ele.position().top < 0) {
                            commentViewContainer.scrollTop(ele.position().top + commentViewContainer.scrollTop());
                        } else if (ele.position().top > commentViewContainer.height() - ele.height()) {
                            commentViewContainer.scrollTop(ele.position().top + commentViewContainer.scrollTop() - commentViewContainer.height() + ele.height() + 30);
                        }
                    }
                });
            };

            scope.validComment = function (item) {
                return item.comments[0].comment !== null;
            };

            scope.highlightAnnotation = function (annotationObj) {
                ViewerEvents.notify(ViewerEvents.HIGHLIGHT_ANNOTATION, annotationObj.id);
            };

            scope.deleteAnnotation = function (annotationId) {
                uiViewerCtrl.deleteAnnotation(annotationId).then(function (response) {
                    viewerDS.deleteAnnotation(annotationId);
                    ViewerEvents.notify(ViewerEvents.DELETE_ANNOTATION, annotationId);
                });
            };

            var init = function () {

                commentViewContainer = $(element[0].querySelector('.comment-box'));
                viewerDS = uiViewerCtrl.getDataSource();

                ViewerEvents.setCommentViewScope(scope);

                //Annotation delete control
                VS = uiViewerCtrl.getViewerSettings();
                scope.controls = {
                    annotation : VS.actions.business.annotation
                };

                scope.annotations = viewerDS.getAnnotations();

                scope.annotationNames = viewerConst.ANNOTATION_NAMES;
                scope.annotationKeys  = viewerConst.ANNOTATION_KEYS;


                //Listeners
                viewerEventsScope = ViewerEvents.getViewerScope();

                updateComment = viewerEventsScope.$on(ViewerEvents.UPDATE_COMMENT_REPLY, updateCommentReply);
                pageChanged = viewerEventsScope.$on(ViewerEvents.PAGE_CHANGED, onPageChangedCallback);
                navToThumb = viewerEventsScope.$on(ViewerEvents.NAV_TO_THUMB, onPageChangedCallback);
                highlightAnnotationComment = viewerEventsScope.$on(ViewerEvents.HIGHLIGHT_ANNOTATION_COMMENT, onHighlightAnnotationComment);
                scope.$on('$destroy', function() {
                    updateComment();
                    pageChanged();
                    navToThumb();
                    highlightAnnotationComment();
                });
            };


            init();
        }
    };
}]);
