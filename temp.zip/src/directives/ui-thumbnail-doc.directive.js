uiv.directive('uiThumbnailDoc', [
    '$document',
    '$compile',
    '$parse',
    '$timeout',
    'ViewerEvents',
    'ViewerSettingService',
    'ViewerNotification',
    'ViewerModel',
    function($document, $compile, $parse, $timeout, ViewerEvents, ViewerSettingService, ViewerNotification, ViewerModel) {

        return {
            restrict: 'A',
            require: ['^uiViewer','^uiThumbnailView'],
            scope: {
                doc: '=',
                docIndex: '='
            },
            templateUrl: "../src/views/ui-thumbnail-doc.html",
            link: function(scope, element, attrs, ctrl) {
                var viewerDS,
                    reorderedPages,
                    hasPageReOrdered,
                    focusedDoc, docId,
                    viewerSettings,
                    viewerEventsScope,
                    freezeOrUnfreezeReorder,
                    settings,
                    thumbId,
                    selectedThums,
                    ele,
                    VS;

                var getClonedImage = function getClonedImage(element) {
                    var canvas = element.find('.thumbCanvasContainer').find('canvas');
                    var clonedImage = element.clone();
                    if (canvas[0]) {
                        var newImageTag = new Image();
                        newImageTag.src = canvas[0].toDataURL();
                        clonedImage.find('canvas').remove();
                        clonedImage.find('.thumbCanvasContainer').append(newImageTag);
                    }
                    return clonedImage;
                };

                var applyThumbSortability = function applyThumbSortability() {
                    ele.multisortable({
                        connectWith: ".thumbContainer",
                        scroll: true,
                        placeholder: 'sortable-placeholder',
                        tolerance: 'pointer',
                        scrollSensitivity: 30,
                        containment: '.sortable-container',
                        sort: function(e, ui) {
                           $(ui.placeholder).html("<p class='placeholder-content'>Drop Here</p>");
                        },
                        helper: function(e, item) {
                           var clonedImage;
                           ViewerSettingService.setIsThumbsPageChanged(false);
                           docId = $(item.children()[0]).isolateScope().doc.id
                           focusedDoc = viewerDS.getDocumentById(docId);
                           thumbId = item.attr('thumb-id');
                           selectedThums = item.parent().find(".selected");
                           ViewerSettingService.setSelectedThumbs(selectedThums);
                           if (!(item.hasClass('selected'))) {
                               $('.thumb').removeClass('selected');
                               selectedThums = item;
                               $timeout(function() {
                                  viewerDS.setSelectedThumb(focusedDoc, thumbId, false);
                                });
                           }
                           if (selectedThums.length > 1) {
                               var helper = $("<div class='sortable-helper'></div>");
                               clonedImage = helper.append("<span style=''>" + _.where(focusedDoc.pages, 'isSelected').length + " pages selected</span>");
                           } else {
                               clonedImage = getClonedImage(item);
                               clonedImage.find('.pageNumber').remove();
                           }
                           return clonedImage;
                        },
                        stop: function(event, ui) {
                           $('.thumb-wrapper').find('.selected').show();
                           if (!ui.item.parents('.thumb-wrapper').length || ViewerSettingService.getIsThumbsPageChanged()) {
                               var error = new ViewerModel.Error({ code: VS.errorCodes.SORT_OUT_OF_BOUNDARY, message: VS.errorMessages[VS.errorCodes.SORT_OUT_OF_BOUNDARY], isError: true });
                               ViewerNotification.showError(error);
                               ViewerEvents.notify(ViewerEvents.THUMB_SORTABILITY_CHNAGED, false);
                               ViewerSettingService.setIsThumbsPageChanged(false);
                               return;
                           }
                           var docs = viewerDS.getDocuments();
                           var oldDocIndex = docs.indexOf(viewerDS.getFocusedDocument());
                           var newDocIndex = viewerDS.getDocIndexById(ui.item.parents('.thumb-wrapper').attr('id'));
                           var newThumbIndex = $(ui.item.parent().find('.thumb.selected')[0]).index();
                            var oldThumbIndex = parseInt($(ui.item.parent().find('.thumb.selected')[0]).attr('data-pagenumber')) -  1;
                        //    var oldThumbIndex = ui.item.find("ui-thumbnail").isolateScope().thumbIndex;
                           var selectedThums = ui.item.parent().find(".selected");
                           var selectedPages = function() {
                               var pages = [];
                               for(var i=0; i<selectedThums.length; i++){
                                   pages.push($(selectedThums[i].children[0]).isolateScope().thumbIndex);
                               }
                               return pages;
                           };
                           var data = {
                               fromDoc: oldDocIndex,
                               toDoc: newDocIndex,
                               toThumb: newThumbIndex,
                               fromThumb: oldThumbIndex,
                               selectedPages: selectedPages()
                           }
                           //to check if the thumb location is changed to avoid increasing the version
                           if ((oldDocIndex === newDocIndex) && (newThumbIndex === oldThumbIndex)) {
                               return;
                           }
                           ViewerEvents.notify(ViewerEvents.PROCESS_REORDER, data);
                       },
                       start: function(event, ui) {
                           var selectedThums =  ViewerSettingService.getSelectedThumbs();
                           if (selectedThums.length > 1) {
                               $('.thumb-wrapper').find('.selected').hide();
                           }
                          var newFocusedDoc = ui.item.parents('.thumb-wrapper').isolateScope().doc;
                          var selectedThumbId = ui.item.attr('thumb-id');
                       }
                    }).disableSelection();
                };

                var init = function init() {
                    viewerDS = ctrl[0].getDataSource();
                    reorderedPages = [];
                    hasPageReOrdered = false;
                    scope.isFreezed = true;
                    VS = ctrl[0].getViewerSettings();
                    settings = ViewerSettingService;
                    viewerSettings = viewerDS.getPageSettings();
                    if (scope.doc.isValidDoc) {
                      element.find('.thumbContr').addClass('thumbContainer');
                    }
                    ele = element.find('.thumbContainer');
                    if(ele.length) {
                      applyThumbSortability();
                      if(!settings.getIsThumbsSortable()){
                        ele.sortable("disable");
                      }
                    }
                    viewerEventsScope = ViewerEvents.getViewerScope();
                };
                init();
            }
        };
    }
]);
