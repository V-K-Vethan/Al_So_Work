uiv.directive('uiCommonFunction', ['$templateCache', '$timeout', 'viewerConst', 'ViewerModel', 'ViewerSetting', 'ViewerNotification', 'ViewerEvents', 'ViewerSettingService', 'ViewState',
    function($templateCache, $timeout, viewerConst, ViewerModel, ViewerSetting, ViewerNotification, ViewerEvents, ViewerSettingService, ViewState) {
        return {
            restrict: 'E',
            require: '^uiViewer',
            replace: true,
            template: function() {
                return $templateCache.get('../src/views/ui-common-function.html');
            },
            controller: function($scope) {
                this.addPredefinedElement = function(ele) {
                    $scope.predefinedElement = ele;
                };
            },
            link: function(scope, element, attrs, uiViewerCtrl) {

                var viewerDS,
                    viewerSettings,
                    resizeOptionKeys,
                    toolKeys,
                    viewerEventsScope,
                    onFocusedDocument,
                    pageChanged,
                    viewerControls,
                    currentState,
                    VS,
                    onNavToThumb,
                    viewerStateChanged;

                var onDocumentChanged = function() {
                    var allDocs = viewerDS.getDocuments();
                    scope.focusedDocument = viewerDS.getFocusedDocument();
                    scope.currentPageText = (allDocs.length) ? ViewerSettingService.getCurrentPageText() : '';
                    scope.currentDocTotalPages = (allDocs.length) ? ViewerSettingService.getCurrentDocTotalPages() : '';
                };

                var getFocusedDocument = function() {
                    return viewerDS.getFocusedDocument();
                };

                var focusedDocPageCount = function() {
                    var focusedDoc = getFocusedDocument();
                    return focusedDoc.pages.length;
                };

                var getFocusedDocIndex = function() {
                    return viewerDS.getFocusedDocIndex();
                };

                var onErrorCallback = function(errorObj) {
                    ViewerNotification.showError(errorObj);
                };

                scope.navToPage = function() {
                    viewerDS.clearSelectedThumbs();
                    ViewerSettingService.setIsMultiThumbSelected(false);
                    viewerDS.jumpToPage(scope.currentPageText);
                    element.find('input').blur();
                };

                /*scope.onNavToPageBlur = function() {
                    element.find('input').blur();
                };*/

                scope.prevPage = function() {
                    viewerDS.focusPrevPage();
                };

                scope.nextPage = function() {
                    viewerDS.focusNextPage();
                };

                var getNextZoom = function getNextZoom(isZoomIn, currentScale, zoomAmount) {
                    var s = Math.round(currentScale * 100),
                        a = Math.round(zoomAmount * 100),
                        s1;
                    if (s % a === 0) {
                        s1 = isZoomIn ? (s + a) : (s - a);
                    } else {
                        if (isZoomIn) {
                            s1 = s  + (a - s % a);
                        } else {
                            s1 = s - s % a;
                        }
                    }
                    return parseFloat(s1/100).toPrecision(2);
                };

                //zoom in & zoom out start
                scope.zoomIn = function() {
                    var scale = ViewerSettingService.getScale();
                    scale = getNextZoom(true, scale, 0.1);
                    if (scale <= viewerConst.MaxZoom) {
                        ViewerSettingService.setScale(scale);
                        ViewerSettingService.setPageFitType(viewerConst.PAGE_FIT_TYPE.DEFAULT);
                        scope.predefinedElement.isolateScope().updateZoomInputDisplay(scale);
                        ViewerEvents.notify(ViewerEvents.SCALE_CHANGED);
                    } else {
                        // ViewerSettingService.setScale(viewerConst.MaxZoom);
                        var error = ViewerModel.Error({ code: VS.errorCodes.MAX_ZOOM, message: VS.errorMessages[VS.errorCodes.MAX_ZOOM], isError: true });
                        ViewerNotification.showError(error);
                    }
                };

                scope.zoomOut = function() {
                    var scale = ViewerSettingService.getScale();
                    scale = getNextZoom(false, scale, 0.1);
                    if (scale >= viewerConst.MinZoom) {
                        ViewerSettingService.setScale(scale);
                        ViewerSettingService.setPageFitType(viewerConst.PAGE_FIT_TYPE.DEFAULT);
                        scope.predefinedElement.isolateScope().updateZoomInputDisplay(scale);
                        ViewerEvents.notify(ViewerEvents.SCALE_CHANGED);
                    } else {
                        // ViewerSettingService.setScale(viewerConst.MinZoom);
                        var error = new ViewerModel.Error({ code: VS.errorCodes.MIN_ZOOM, message: VS.errorMessages[VS.errorCodes.MIN_ZOOM], isError: true });
                        ViewerNotification.showError(error);
                    }
                };

                scope.bestFit = function() {
                    scope.selectedSize = scope.resizeOptions[resizeOptionKeys.ZOOM_TO_PAGE_LEVEL];
                    ViewerSettingService.setPageFitType(viewerConst.PAGE_FIT_TYPE.BEST_FIT);
                    scope.predefinedElement.isolateScope().updateZoomInputDisplay(scope.selectedSize.id);
                    ViewerEvents.notify(ViewerEvents.SCALE_CHANGED);
                };

                scope.fitToWidth = function() {
                    scope.selectedSize = scope.resizeOptions[resizeOptionKeys.FIT_WIDTH];
                    ViewerSettingService.setPageFitType(viewerConst.PAGE_FIT_TYPE.FIT_TO_WIDTH);
                    scope.predefinedElement.isolateScope().updateZoomInputDisplay(scope.selectedSize.id);
                    ViewerEvents.notify(ViewerEvents.SCALE_CHANGED);
                };

                scope.downloadSelectivePages = function() {
                    uiViewerCtrl.downloadSelectivePages(viewerDS.getSelectedPages());
                };

                scope.onChangeTool = function(value) {
                    scope.selectedTool = value;
                };

                var onPageChangedCb = function onPageChangedCb() {
                    scope.currentPageText = ViewerSettingService.getCurrentPageText();
                    scope.currentDocTotalPages = ViewerSettingService.getCurrentDocTotalPages();
                };

                var onNavToThumbCallback = function onNavToThumbCallback() {
                    onPageChangedCb();
                };

                var onCheckSelectedThumbsCallback = function() { 
                    var focusedDoc = viewerDS.getFocusedDocument();
                    //disables the download if page is corrupted
                    scope.canDownload = viewerDS.getSelectedThumbsCount() > 0;
                };

                var updateViewState = function updateViewState() {
                    onCheckSelectedThumbsCallback();
                    currentState = ViewerSettingService.getViewerState();
                    scope.controls = {
                        nextPage: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.NEXT_PAGE][currentState] && VS.actions.viewer.nextPage,
                        prevPage: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.PREV_PAGE][currentState] && VS.actions.viewer.prevPage,
                        pageNo: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.PAGE_NO][currentState] && VS.actions.viewer.pageNo,
                        zoomOut: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.ZOOM_OUT][currentState] && VS.actions.viewer.zoomOut,
                        zoomIn: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.ZOOM_IN][currentState] && VS.actions.viewer.zoomIn,
                        predefinedZoom: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.PREDEFINED_ZOOM][currentState] && VS.actions.viewer.predefinedZoom,
                        fitToWidth: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.FIT_TO_WIDTH][currentState] &&  VS.actions.viewer.fitToWidth,
                        bestFit: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.BEST_FIT][currentState] && VS.actions.viewer.bestFit,
                        download: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.DOWNLOAD][currentState] &&  VS.actions.business.download && scope.canDownload
                    };
                };

                var init = function init() {
                    viewerDS = uiViewerCtrl.getDataSource();
                    VS = uiViewerCtrl.getViewerSettings();
                    resizeOptionKeys = viewerConst.COMMON_FUNCTION.RESIZE_KEYS;
                    scope.currentPageText = ViewerSettingService.getCurrentPageText();
                    scope.currentDocTotalPages = ViewerSettingService.getCurrentDocTotalPages();
                    scope.resizeOptions = viewerConst.COMMON_FUNCTION.RESIZE_OPTIONS;
                    scope.selectedSize = scope.resizeOptions[resizeOptionKeys.FIT_WIDTH];
                    scope.tools = viewerConst.COMMON_FUNCTION.TOOLS;

                    //set default choice
                    //scope.selectedTool = scope.tools[viewerConst.COMMON_FUNCTION.TOOL_KEYS.HIDE_TOOLS];
                    scope.selectedTool = scope.tools[viewerConst.COMMON_FUNCTION.TOOL_KEYS.TOOLS];
                    //viewer button controls
                    updateViewState();
                    //Listener
                    viewerEventsScope = ViewerEvents.getViewerScope();
                    onFocusedDocument = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChanged);
                    pageChanged = viewerEventsScope.$on(ViewerEvents.PAGE_CHANGED, onPageChangedCb);
                    checkSelectedThumbs = viewerEventsScope.$on(ViewerEvents.CHECK_SELECTED_THUMBS, onCheckSelectedThumbsCallback);
                    onNavToThumb = viewerEventsScope.$on(ViewerEvents.NAV_TO_THUMB, onNavToThumbCallback);
                    viewerStateChanged = viewerEventsScope.$on(ViewerEvents.VIEWER_STATE_CHANGED, updateViewState);

                    key.unbind(VS.shortcuts.prevPage);
                    key.unbind(VS.shortcuts.nextPage);

                    key.setScope(viewerConst.SHORTCUT_SCOPE.VIEWER);

                    key(VS.shortcuts.prevPage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $timeout(function() {
                            scope.prevPage();
                        });
                        return false;
                    });

                    key(VS.shortcuts.nextPage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $timeout(function() {
                            scope.nextPage();
                        });
                        return false;
                    });

                    key(VS.shortcuts.jumpToPage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                        $('.toolbar .pageNumberBox').focus();
                        $('.toolbar .pageNumberBox').select();
                        return false;
                    });

                    scope.$on('destroy', function() {
                        onFocusedDocument();
                        pageChanged();
                        onNavToThumb();
                        checkSelectedThumbs();
                        viewerStateChanged()
                    });
                };

                init();
            }
        };
    }
]);

uiv.directive('clickAnywhereButHere', function($document){
    return {
        restrict: 'A',
        link: function(scope, elem, attr, ctrl) {
          elem.bind('click', function(e) {
            // this part keeps it from firing the click on the document.
            e.stopPropagation();
          });
          $document.bind('click', function() {
            // magic here.
            scope.$apply(attr.clickAnywhereButHere);
        });
        }
    };
});
