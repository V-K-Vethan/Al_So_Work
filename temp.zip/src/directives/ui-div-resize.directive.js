uiv.directive( 'uiDivResize', function() {
    return {
        scope: {
            uiDivResize: "&"
        },
        link: function( scope, elem, attrs ) {
            scope.$watch( function() {
                 setTimeout(function () {
                    scope.uiDivResize({size: elem.width()});
                },1000);
            });
        }
    }
});