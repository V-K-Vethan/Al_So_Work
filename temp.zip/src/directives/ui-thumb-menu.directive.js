uiv.directive('uiThumbMenu', ['$templateCache', 'ViewerEvents', 'ViewerSettingService', 'viewerConst', 'ViewState', 'ViewerSetting', '$timeout', 'ViewerModel', 'ViewerNotification', 'ViewerUtilitis', 'ViewerClipboardService',
    function($templateCache, ViewerEvents, ViewerSettingService, viewerConst, ViewState, ViewerSetting, $timeout, ViewerModel, ViewerNotification, ViewerUtilitis, ViewerClipboardService) {
    return {
        restrict: 'E',
        require: '^uiViewer',
        replace: true,
        template: function() {
            return $templateCache.get('../src/views/ui-thumb-menu.html');
        },
        link: function(scope, element, attrs, uiViewerCtrl) {
            var viewerDS,
                settings,
                viewerEventsScope,
                checkSelectedThumbs,
                currentState,
                VS,
                onThumbSortablity,
                onProcessReorder,
                selectedPages,
                selectedPageIndexes = [],
                pagesForReorder;

            scope.onDeleteSelectedThumbs = function() {
                if (scope.controls.delete) {
                    uiViewerCtrl.deletePages(viewerDS.getSelectedPages());
                }
            };

            scope.onSplitDocument = function() {
                if (scope.controls.split) {
                    var splittedDocument =  getSplittedDocument();
                    uiViewerCtrl.splitDocument(splittedDocument);
                }
            };

            scope.cutThumbsList = [];
            scope.onEditThumb = function(action) {
                var currentFocusedDoc = viewerDS.getFocusedDocument();
                if (action === 'cut' && scope.controls.cut) {
                    selectedPageIndexes = [];
                    scope.canPaste = false;
                    viewerDS.setThumbEditAction(action);
                    selectedPages = viewerDS.getSelectedPages()[0].pages;
                    _.each(selectedPages, function(page) {
                        selectedPageIndexes.push(page.pageNumber - 1);
                    });
                    pagesForReorder = angular.copy(viewerDS.getPagesForReorder());
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.DISABLE_EDIT);
                } else if (action === 'paste') {
                    if ((!pagesForReorder && !pagesForReorder.length) || !scope.controls.paste) {
                        return;
                    }
                    var data = {
                        fromDoc: viewerDS.getDocIndexById(selectedPages[0].docId),
                        toDoc: viewerDS.getFocusedDocIndex(),
                        toThumb: currentFocusedDoc.getFocusedPage().pageNumber,
                        fromThumb: selectedPageIndexes[0],
                        selectedPages: selectedPageIndexes
                    };
                    onProcessReorderCb(null, data, true);
                    pagesForReorder = '';
                    viewerDS.setThumbEditAction('paste');
                    ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.BASIC);
                }
                ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
            };

            scope.onRotateLeft = function() {
                //update metadata
                viewerDS.getFocusedDocument().getFocusedPage().rotateACW();
                //broadcast
                ViewerEvents.notify(ViewerEvents.ROTATION_CHANGED);
            };

            scope.onRotateRight = function() {
                //update metadata
                viewerDS.getFocusedDocument().getFocusedPage().rotateCW();
                //broadcast
                ViewerEvents.notify(ViewerEvents.ROTATION_CHANGED);
            };

            scope.freezeOrUnfreezeReorder = function() {
                if (ViewerSettingService.getReorderStatus() === viewerConst.RESPONSE_STATUS.PROGRESS) {
                    var progressStatusObj = new ViewerModel.Error({ code: VS.progressCodes.REORDER_PAGES, message: VS.progressMessages[VS.progressCodes.REORDER_PAGES], isError: true });
                    ViewerNotification.showProgress(progressStatusObj);
                    return;
                }
                if (scope.controls.reorder) {
                    scope.isThumbSortable = !scope.isThumbSortable
                }
                updateReorderState();
            };

            /*
            * returns splitted document with pages retains the order while selection
            */
            var getSplittedDocument = function getSplittedDocument() {
                var docObj = viewerDS.getSelectedPages()[0];
                if (VS.actions.business.split && VS.actions.business.split.userSelectedOrder) {
                    var orderedSelectedPages = viewerDS.getPagesForReorder();
                    var pages = [];
                    _.each(orderedSelectedPages, function(id) {
                        pages.push(docObj.getPageById(id));
                    });
                    docObj.pages = pages;
                }
                return [docObj];
            };

            var undoCutThumbs = function undoCutThumbs() {
                if (!ViewerClipboardService.getCutDocuments()) { return; }
                viewerDS.undoCutThumbs();
                scope.canPaste = false;
                pagesForReorder = '';
                ViewerSettingService.setViewerState(viewerConst.VIEW_STATE.BASIC);
                ViewerEvents.notify(ViewerEvents.VIEWER_STATE_CHANGED);
            };

            var onThumbSortabilityChanged = function onThumbSortabilityChanged() {
                scope.isThumbSortable = false;
            };

            var updateReorderState = function updateReorderState() {
                if (scope.isThumbSortable) {
                    $('.thumbContainer').sortable("enable");
                } else {
                    $('.thumbContainer').sortable("disable");
                }

                $timeout(function() {
                    if (scope.isThumbSortable){
                        $('.thumb').css({
                            'cursor': '-webkit-grab'
                        });
                    } else {
                        $('.thumb').css({
                            'cursor': ''
                        });
                    }
                }, 300);
                scope.reorderTitle = (scope.isThumbSortable) ? 'Freeze Reorder' : 'Unfreeze Reorder';
                settings.setIsThumbsSortable(scope.isThumbSortable);
                scope.cutThumbsList = viewerDS.getCutThumbsList();
                updateViewState();
            };

            var onProcessReorderCb = function onProcessReorderCb(event, data, isPaste) {
                configureCrossDocOprSettings(data);
                viewerDS.reorderPages(data, pagesForReorder);
                var docs = viewerDS.getDocuments();
                var reorderedDocs = (data.fromDoc !== data.toDoc) ? [docs[data.fromDoc], docs[data.toDoc]] : [docs[data.fromDoc]]; //currently only two documents are allowed for reorder
                var crossDocType = isPaste ? viewerConst.CROSS_DOC_OPR_TYPE.CUT_PASTE : viewerConst.CROSS_DOC_OPR_TYPE.REORDER;
                uiViewerCtrl.reorderBulkPages(reorderedDocs, crossDocType);
                var fromDocObj = docs[data.fromDoc];
                if (!fromDocObj.pages.length) {
                    viewerDS.removeDocument(docs[data.fromDoc].id, data.fromDoc);
                }
                var newFocusedDoc =  viewerDS.getFocusedDocument();
                var focusedPage = newFocusedDoc.getFocusedPage();
                viewerDS.removeCutDocumentsFromList();
                ViewerSettingService.setCurrentPageText(focusedPage.pageNumber);
                ViewerSettingService.setCurrentDocTotalPages(newFocusedDoc.pages.length);
                //sets the thumb page changed value to false to avoid the reorder out of boundary error
                ViewerSettingService.setIsThumbsPageChanged(false);
                ViewerEvents.notify(ViewerEvents.THUMB_SORTABILITY_CHNAGED, true);
            };

            var configureCrossDocOprSettings = function(data) {
                var isPreviousDataToClean = false;
                var focusedDoc = viewerDS.getFocusedDocument();
                var pagesForReorder = viewerDS.getPagesForReorder();
                var pageNumberList = [];
                _.each(pagesForReorder, function(id) {
                    pageNumberList.push(focusedDoc.getPageById(id).pageNumber)
                });
                //to prevent cleaning of entire data set to avoid container flickering
                scope.cutThumbsList = viewerDS.getCutThumbsList();
                isPreviousDataToClean = (!scope.cutThumbsList.length && ((data.fromDoc !== data.toDoc) || ((data.fromDoc === data.toDoc) && (ViewerSettingService.getPageSelectDirection() === 'upwards' || !ViewerUtilitis.isSorted(pageNumberList))))) ? true : false;
                ViewerSettingService.setIsPreviousDataToClean(isPreviousDataToClean);
            };

            var setShortcutFocusPage = function setShortcutFocusPage() {
                var focusedDoc =  viewerDS.getFocusedDocument();
                var selectedPages = viewerDS.getSelectedPagesByDocId(focusedDoc.id);
                //sets the first selected pages of a document to maintain the shift+up/down sequence
                ViewerSettingService.setShortCutFocusedPage(selectedPages[0]);
                ViewerSettingService.setShortCutState('shift');
            };

            var onReorderCompleteCb = function onReorderCompleteCb(event, respData) {
                updateReorderState();
                switch (ViewerSettingService.getReorderStatus()) {
                    case viewerConst.RESPONSE_STATUS.FAILURE:
                        viewerDS.undoReorderChanges();
                        ViewerSettingService.setIsThumbsPageChanged(false);
                        ViewerEvents.notify(ViewerEvents.THUMB_SORTABILITY_CHNAGED, false);
                        setShortcutFocusPage();
                        break;
                    case viewerConst.RESPONSE_STATUS.SUCCESS:
                        var docs = viewerDS.getDocuments();
                        _.each(respData.data, function(data) {
                            viewerDS.updateDocuments({id : data.id, updatedDtm : data.modifiedDtm});
                            var doc = _.where(docs, {'id' : data.id})[0];
                            data.pageCount = (doc) ? doc.pages.length : 0;
                        });
                        uiViewerCtrl.onDocumentUpdate(respData.data);
                        setShortcutFocusPage();
                        break;
                    case viewerConst.RESPONSE_STATUS.PROGRESS:
                        break;
                }
            };

            var onCheckSelectedThumbsCallback = function onCheckSelectedThumbsCallback(event, docs) {
                var focusedPage,
                    focusedDoc = viewerDS.getFocusedDocument();
                if (focusedDoc) {
                    focusedPage = focusedDoc.getFocusedPage();
                }

                scope.canEdit = viewerDS.validateEditOperationOnThumbSelection();
                var selectedDocs = _.where(viewerDS.getDocuments(), 'isSelected');
                scope.canSplit = (selectedDocs.length > 1) ? false : true;
                scope.canReorder = (focusedDoc && focusedDoc.pages.length) ? true : false;
                scope.canCut = (selectedDocs.length && selectedDocs.length <= 1) ? true : false;
                scope.canPaste =  (selectedDocs.length && viewerDS.getCutThumbsList().length && focusedPage && focusedPage.action !== 'cut' && focusedPage.isValidPage) ? true: false;
            };

            var onPageChangeCallback = function onPageChangeCallback() { };

            var onDocumentChangeCallback = function onDocumentChangeCallback() { };

            var updateViewState = function updateViewState() {
                onCheckSelectedThumbsCallback();
                currentState = ViewerSettingService.getViewerState();
                scope.controls = {
                    rotateLeft : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.ROTATE_LEFT][currentState] && VS.actions.viewer.rotateLeft,
                    rotateRight : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.ROTATE_RIGHT][currentState] && VS.actions.viewer.rotateRight,
                    split : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.SPLIT][currentState] && VS.actions.business.split && scope.canSplit && scope.canEdit,
                    delete : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.DELETE][currentState] && VS.actions.business.delete && scope.canEdit,
                    reorder : ViewState.stateMatrix[viewerConst.UI_ELEMENTS.FREEZE_REORDER][currentState] && VS.actions.business.reorder,
                    cut: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.CUT][currentState] && VS.actions.business.cut && scope.canCut,
                    paste: ViewState.stateMatrix[viewerConst.UI_ELEMENTS.PASTE][currentState] && VS.actions.business.paste && scope.canPaste
                };
            };

            var init = function init() {
                viewerDS = uiViewerCtrl.getDataSource();
                VS = uiViewerCtrl.getViewerSettings();
                settings = ViewerSettingService;
                scope.isThumbSortable = settings.getIsThumbsSortable();
                scope.canEdit = false;
                scope.isFreezed = true;
                scope.reorderTitle = 'Unfreeze Reorder';
                onCheckSelectedThumbsCallback();
                viewerEventsScope = ViewerEvents.getViewerScope();
                checkSelectedThumbs = viewerEventsScope.$on(ViewerEvents.CHECK_SELECTED_THUMBS, onCheckSelectedThumbsCallback);
                onDocumentChange = viewerEventsScope.$on(ViewerEvents.DOCUMENT_CHANGED, onDocumentChangeCallback);
                onPageChange = viewerEventsScope.$on(ViewerEvents.PAGE_CHANGED, onPageChangeCallback);
                stateChanged = viewerEventsScope.$on(ViewerEvents.STATE_CHANGED, updateViewState);
                onReorderComplete = viewerEventsScope.$on(ViewerEvents.REORDER_OPERATION_DONE, onReorderCompleteCb);
                onThumbSortablity = viewerEventsScope.$on(ViewerEvents.THUMB_SORTABILITY_CHNAGED, onThumbSortabilityChanged);
                onProcessReorder = viewerEventsScope.$on(ViewerEvents.PROCESS_REORDER, onProcessReorderCb);
                viewerStateChanged = viewerEventsScope.$on(ViewerEvents.VIEWER_STATE_CHANGED, updateViewState);
                
                //Tooltip bindings as object
                scope.tooltip = VS.tooltips;

                //shortcuts
                key.unbind(VS.shortcuts.cutPage);
                key.unbind(VS.shortcuts.pastePage);
                key.unbind(VS.shortcuts.undoCutPaste);

                key.setScope(viewerConst.SHORTCUT_SCOPE.VIEWER);

                key(VS.shortcuts.cutPage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                    $timeout(function() {
                        scope.onEditThumb('cut');
                    });
                    return false;
                });

                key(VS.shortcuts.pastePage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                    $timeout(function() {
                        scope.onEditThumb('paste');
                    });
                    return false;
                });

                key(VS.shortcuts.undoCutPaste, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                    $timeout(function() {
                        undoCutThumbs();
                    });
                    return false;
                });

                key(VS.shortcuts.splitPage, viewerConst.SHORTCUT_SCOPE.VIEWER, function() {
                    $timeout(function() {
                        scope.onSplitDocument();
                    });
                    return false;
                });

                scope.$on('$destroy', function() {
                    checkSelectedThumbs();
                    onDocumentChange();
                    onPageChange();
                    stateChanged();
                    onReorderComplete();
                    onThumbSortablity();
                    onProcessReorder();
                    viewerStateChanged();
                });
            };

            init();
        }
    };
}]);
