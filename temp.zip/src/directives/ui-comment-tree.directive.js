uiv.directive("commentTreeModel", function($compile, $timeout, uiViewerDatasource, ViewerEvents) {
    return {
        restrict: "A",
        require: "^uiViewer",
        link: function(b, h, c, uiViewerCtrl) {

            var viewerDS = uiViewerCtrl.getDataSource();

            b.getDateTimeString = function (timeStamp) {
                return moment(timeStamp).format("MM/DD/YYYY HH:mm");
            };

            var a = c.treeId,
                g = c.commentTreeModel,
                e = c.nodeLabel || "label",
                d = c.nodeChildren || "children",
                e = '<ul style="list-style-type: none; padding-left: 16px;">\
                      <li data-ng-repeat= "node in ' + g + '">\
                        <div class="anotation-item">\
                        <span>{{getDateTimeString(node.createdDtm)}} {{node.createdBy}}</span>\
                        </div>\
                        <div class="comment-tree-node" data-ng-class="node.selected" data-ng-click="' + a + '.selectNodeLabel(node)">{{node.' + e + '}}</div>\
                        <div ui-comment-reply comment="node"></div>\
                        <div data-ng-hide="node.collapsed" data-tree-id="' + a + '" data-comment-tree-model="node.' + d + '" data-node-id=' + (c.nodeId || "id") + " data-node-label=" + e + " data-node-children=" + d + "></div>\
                      </li>\
                    </ul>";
            a && g && (c.angularTreeview && (b[a] = b[a] || {}, b[a].selectNodeHead = b[a].selectNodeHead || function(a) {
                a.collapsed = !a.collapsed
            }, b[a].selectNodeLabel = b[a].selectNodeLabel || function(c) {
                b[a].currentNode && b[a].currentNode.selected &&
                    (b[a].currentNode.selected = void 0);
                c.selected = "selected";
                b[a].currentNode = c
            }), h.html('').append($compile(e)(b)));
        }
    }
});

uiv.directive("uiCommentReply", function($compile, $timeout, ViewerEvents, ViewerModel) {
    return {
        restrict: "A",
        require: "^uiViewer",
        template:   '<div data-ng-hide="isEdit">\
                        <button class="ng-viewer-theme-btn comment-reply-btn" title="Reply" data-ng-click="showReplyBox($event)">Reply</button>\
                        <button class="ng-viewer-theme-btn comment-delete-btn" title="Delete" ng-show="isLeaf" data-ng-click="deleteComment()">Delete</button>\
                    </div>\
        <div ng-show="isEdit"><textarea class="comment-reply-text" ng-model="reply" type="text" ng-change="onCommentChange()" maxlength="500"></textarea><button class="hyperlink-button" data-ng-click="replyOk()">Ok</button><button class="hyperlink-button" data-ng-click="replyCancel()">Cancel</button><div class="has-error" ng-if="isCommentEmpty && isEdit"><p class="validation-help-block"><i class="fa fa-exclamation-triangle"></i>&nbsp; Add comments</p></div></div>',
        scope: {
            rCommentReply: "&",
            comment: "="
        },
        link: function(scope, element, attr, ctrl) {

            scope.isEdit = false;
            scope.isLeaf = scope.comment.parentId ? true : false;
            if(scope.isLeaf) scope.isLeaf = (!scope.comment.comments || (scope.comment.comments && scope.comment.comments.length == 0)) ? true : false;
            var viewerDS = ctrl.getDataSource();

            scope.showReplyBox = function (e) {
                scope.isEdit = true;
                scope.isCommentEmpty = false;
                $timeout(function() {
                    $('.comment-reply-text').focus();
                });
            };

            scope.replyOk = function () {
                var commentModel = new ViewerModel.Comment({
                    id : "",
                    annotationId: scope.comment.annotationId,
                    comment: scope.reply,
                    parentId: scope.comment.id
                    // createdDtm : "03/18/2016 05:00 PM",
                    // createdBy : "Arul Jeeva",
                    // updatedDtm: "03/18/2016 05:00 PM",
                    // updatedBy: "Arul Jeeva"
                });
                if (scope.reply) {
                    scope.isCommentEmpty = false;
                    ctrl.replyComment(commentModel).then(function(responeData){
                        //add comment to annotation storage
                        viewerDS.addReplyToComment(responeData);
                        //fire event to refresh the annotations
                        ViewerEvents.notify(ViewerEvents.UPDATE_COMMENT_REPLY);
                    }, function(error) {

                    });
                    scope.reply = "";
                    scope.isEdit = false;
                } else {
                    scope.isCommentEmpty = true;
                }
            };

            scope.onCommentChange = function onCommentChange() {
                scope.isCommentEmpty = scope.reply ? false : true;
            };

            scope.replyCancel = function () {
                scope.reply = "";
                scope.isEdit = false;
            };

            scope.deleteComment = function() {
                ctrl.deleteComment(scope.comment).then(function(responeData){
                    //add comment to annotation storage
                    viewerDS.deleteComment(responeData);
                    //fire event to refresh the annotations
                    ViewerEvents.notify(ViewerEvents.UPDATE_COMMENT_REPLY);
                });
            };
        }
    }
});
