uiv.controller('uiViewerController',['$scope', '$window', '$state', '$http', '$timeout', 'ViewerModel','ViewerEvents', 'ViewerNotification', 'ViewerSettingService', 'ViewerSetting', '$q', 'viewerConst',
function($scope, $window, $state, $http, $timeout, ViewerModel, ViewerEvents, ViewerNotification, ViewerSettingService, ViewerSetting, $q, viewerConst) {

    var init = function() {
        ViewerEvents.setViewerScope($scope);
    };

    this.getDataSource = function () {
        return $scope.rDataSource;
    };

    this.getViewerSettings = function() {
        return $scope.rSettings;
    };

    this.deletePages = function(deletedDocs) {
        $scope.rDeletePages({docs: deletedDocs}).then(function(resp) {
            ViewerEvents.notify(ViewerEvents.DELETE_PAGES_DONE, deletedDocs);
            $scope.rDataSource.deleteDocumentPages(deletedDocs, resp);
            that.onDocumentUpdate(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showError(error);
        });
    };

    this.splitDocument = function(docs) {
        $scope.rSplitDocument({docs: docs}).then(function(resp) {
            var docIdList = _.pluck(resp.data, 'childDocumentIds');
            if (resp.data.length > 1) {
                var docIds = _.flatten(docIdList);
                mergeDocuments(docIds);
            } else {
                $scope.rShowDoc({docId : docIdList[0]});
            }
            ViewerEvents.notify(ViewerEvents.DELETE_PAGES_DONE, docs);
            resp.data[0].id = resp.data[0].parentDocumentId;
            $scope.rDataSource.deleteDocumentPages(docs, resp);
            that.onDocumentUpdate(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showError(error);
        });
    };

    this.reorderPages = function(pages, docId) {
        $scope.rReorder({pages: pages, docId: docId}).then(function(resp) {
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showSuccess(error);
        });
    };

    this.downloadSelectivePages = function(docs) {
        $scope.rDownloadSelectivePages({docs: docs})
    };

    this.downloadSourceDocument = function() {
        $scope.rDownloadSourceDocument();
    };

    var mergeDocuments = function(docIds) {
        $scope.rMergeDocuments({docIds: docIds});
    };

    //TODO: refactor this
    this.clearSelectedDocument = function () {
        $scope.selectedDocument = null;
    };

    //TODO; meed to refactor: move to caller directive(ui-thumb-menu) after settings refactor
    this.rotatePageToLeft = function() {
        var focusedThumbObj = $scope.rDataSource.getFocusedThumbObjById($scope.rDataSource.getFocusedThumbId());
        $scope.settings.rotation = focusedThumbObj.rotation - 90;
        if ($scope.settings.rotation < 0) {
            $scope.settings.rotation = 360 + $scope.settings.rotation;
        }
        $scope.rDataSource.setPropertyToFocusedThumbObj(focusedThumbObj.id, {rotation: $scope.settings.rotation});
        $scope.rDataSource.setPageSettings($scope.settings);
    };

    //TODO; meed to refactor: move to caller directive(ui-thumb-menu) after settings refactor
    this.rotatePageToRight = function() {
        var focusedThumbObj = $scope.rDataSource.getFocusedThumbObjById($scope.rDataSource.getFocusedThumbId());
        $scope.settings.rotation = focusedThumbObj.rotation + 90;
        //regularize
        if ($scope.settings.rotation === 360) {
            $scope.settings.rotation = 0;
        }
        $scope.rDataSource.setPropertyToFocusedThumbObj(focusedThumbObj.id, {rotation: $scope.settings.rotation});
        $scope.rDataSource.setPageSettings($scope.settings);
    };
    /**
     * evnt for 3rd party
     * @param  {[type]} currentDocId [description]
     * @param  {[type]} oldDocId     [description]
     * @return {[type]}              [description]
     */
    this.onDocumentChange = function(currentDocId, oldDocId) {
        $scope.rOnDocumentChange({currentDocumentId : currentDocId, oldDocumentId : oldDocId});
    };

    this.onViewChange = function(currentView, oldView) {
        $scope.rOnViewChange({currentView : currentView, oldView : oldView});  
    };

    this.onDocumentUpdate = function(data) {
        $scope.rOnUpdateDocument({data: data});
    };
    /**
     * command for viewer from 3rd party
     * @type {[type]}
     */
    this.resizeViewer = function resizeViewer(){
        //TODO: grob page view directive and call updateViewPortDimension()
    };

    /**
    * create annotation API call
    * @type {[type]}
    */
    this.createAnnotation = function(annotationObj) {
        var deferred = $q.defer();
        $scope.rCreateAnnotation({annotation: annotationObj}).then(function(resp) {
            deferred.resolve(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showError(error);
            deferred.reject(error);
        });
        return deferred.promise;
    };

    /**
    * reply comment API call
    * @type {[type]}
    */
    this.replyComment = function(reply) {
        var deferred = $q.defer();
        $scope.rReplyComment({reply: reply}).then(function(resp) {
            deferred.resolve(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showError(error);
        });
        return deferred.promise;
    };

    /**
    * delete comment API call
    * @type {[type]}
    */
    this.deleteComment = function(comment) {
        var deferred = $q.defer();
        $scope.rDeleteComment({comment: comment}).then(function(resp) {
            deferred.resolve(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function (error) {
            ViewerNotification.showError(error);
        });
        return deferred.promise;
    };

    /**
    * get all anotations of a page, API call
    * @type {[type]}
    */
    this.getAllAnnotations = function(pageId) {
        var deferred = $q.defer();
        $scope.rGetAllAnnotations({documentObjectId: pageId}).then(function(resp) {
            deferred.resolve(resp);
        }, function(error) {
            ViewerNotification.showError(error);
            deferred.reject(error);
        });
        return deferred.promise;
    };

    /**
    * delete annotation of a page, API call
    * @type {[type]}
    */
    this.deleteAnnotation = function(id) {
        var deferred = $q.defer();
        $scope.rDeleteAnnotation({annotationId: id}).then(function(resp) {
            deferred.resolve(resp.data);
            ViewerNotification.showSuccess(resp);
        }, function(error) {
            ViewerNotification.showError(error);
        });
        return deferred.promise;
    };

    //reorder bulk pages
    this.reorderBulkPages = function(docs, crossDocType) {
        ViewerSettingService.setReorderStatus(viewerConst.RESPONSE_STATUS.PROGRESS);
        $scope.rReorderBulkPages({docs: docs, crossDocType : crossDocType }).then(function(resp) {
            ViewerNotification.showSuccess(resp);
            ViewerSettingService.setReorderStatus(viewerConst.RESPONSE_STATUS.SUCCESS);
            ViewerEvents.notify(ViewerEvents.REORDER_OPERATION_DONE, resp);
        }, function(error) {
            ViewerNotification.showError(error);
            ViewerSettingService.setReorderStatus(viewerConst.RESPONSE_STATUS.FAILURE);
            ViewerEvents.notify(ViewerEvents.REORDER_OPERATION_DONE, error);
        });
    };
    var that = this;
    init();
}]);
