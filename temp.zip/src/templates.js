angular.module('ui').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('../src/views/page-template.html',
    "<div class=\"page\"></div>"
  );


  $templateCache.put('../src/views/ui-comment-view.html',
    "<div id=\"ui-comment-view-container\" class=\"comment-view-container\"><div class=\"heading\"><div class=\"header-title\">Comments</div></div><div class=\"comment-box\"><div ng-repeat=\"anno in annotations\" ng-if=\"anno.comments.length>0\" id=\"{{anno.id}}\" class=\"annotation-comment\" ng-click=\"highlightAnnotation(anno)\" ng-class=\"{'selected-annotation-comment': anno.id == focusedAnnotation}\"><div class=\"annotation-delete\"><button title=\"Delete Annotation\" ng-if=\"controls.annotation.delete\" ng-click=\"deleteAnnotation(anno.id)\"><i class=\"fa fa-trash-o\"></i></button></div><div ng-if=\"anno.annotationType == annotationKeys.COMMENT\" class=\"fa fa-comment-o pull-left comment-legend\"></div><div ng-if=\"anno.annotationType == annotationKeys.HIGHLIGHT\" class=\"fa fa-icon-edit-sign pull-left comment-legend\"></div><div ng-if=\"anno.annotationType == annotationKeys.TEXT\" class=\"fa fa-font pull-left comment-legend\"></div><div ng-if=\"anno.annotationType == annotationKeys.STRIKEOUT\" class=\"fa fa-strikethrough pull-left comment-legend\"></div><div ng-if=\"anno.annotationType == annotationKeys.UNDERLINE\" class=\"fa fa-underline pull-left comment-legend\"></div><div ng-if=\"anno.annotationType == annotationKeys.REDACTION\" class=\"fa fa-eraser pull-left comment-legend\"></div><div data-angular-treeview=\"true\" data-tree-id=\"mytree\" data-node-label=\"comment\" data-node-children=\"comments\" data-comment-tree-model=\"anno.comments\"></div></div></div></div>"
  );


  $templateCache.put('../src/views/ui-common-function.html',
    "<ul class=\"toolbar menu\"><li style=\"width: 159px\"><button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.nextPage }\" ng-click=\"prevPage()\" ng-disabled=\"!controls.nextPage\" title=\"Previous Page\"><i class=\"fa fa-arrow-up\"></i></button> <button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.prevPage }\" ng-click=\"nextPage()\" ng-disabled=\"!controls.prevPage\" title=\"Next Page\"><i class=\"fa fa-arrow-down\"></i></button> <input type=\"text\" class=\"pageNumberBox\" numerics ng-model=\"currentPageText\" ng-enter=\"navToPage()\" ng-disabled=\"!controls.pageNo\"> <span><label class=\"pageNumberDivider\">/</label></span> <span><label class=\"pageCount\">{{currentDocTotalPages}}</label></span></li><li><button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.zoomOut }\" ng-click=\"zoomOut()\" ng-disabled=\"!controls.zoomOut\" title=\"Zoom Out\"><i class=\"fa fa-search-minus\"></i></button> <button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.zoomIn }\" ng-click=\"zoomIn()\" ng-disabled=\"!controls.zoomIn\" title=\"Zoom In\"><i class=\"fa fa-search-plus\"></i></button> <span id=\"zoomLevel\" ui-predefined-zooms state=\"controls.predefinedZoom\" scale=\"{{scale}}\"></span></li><li><button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.fitToWidth }\" style=\"padding-top:4px\" ng-click=\"fitToWidth()\" ng-disabled=\"!controls.fitToWidth\" title=\"Fit to Width\"><i class=\"fa fa-arrows-h\"></i></button> <button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.bestFit }\" ng-click=\"bestFit()\" ng-disabled=\"!controls.bestFit\" title=\"Best Fit\"><i class=\"fa fa-arrows\"></i></button></li><li><button class=\"ng-viewer-theme-btn cursor-pointer disable-button\" style=\"padding-top:4px\" ng-disabled=\"true\" title=\"High Resolution\"><i class=\"fa fa-eye-slash\"></i></button> <button class=\"ng-viewer-theme-btn cursor-pointer\" style=\"padding-top:4px\" ng-class=\"{'disable-button' : !controls.download || !canDownload }\" ng-disabled=\"!controls.download\" ng-click=\"downloadSelectivePages()\" title=\"Save As PDF\"><i class=\"fa fa-floppy-o\"></i></button></li><li><div class=\"dropdown commonMenuDropdown\"><button style=\"width: 95px\" type=\"button\" data-toggle=\"dropdown\">{{selectedTool.name}} <span class=\"caret\"></span></button><ul class=\"dropdown-menu tool-list\"><li class=\"cursor-pointer tool-items\" ng-repeat=\"item in tools\" ng-click=\"onChangeTool(item)\"><a>{{item.name}}</a></li></ul></div></li></ul>"
  );


  $templateCache.put('../src/views/ui-document-tab.html',
    "<div id=\"document-tab-dir-container\"><div id=\"document-tabs-dir\" class=\"tabbable-panel\" ng-if=\"!isMultipleDocumentAdded\"><button id=\"leftSlide\" class=\"arrow ng-viewer-theme-btn\" style=\"border: none;background: transparent\"><i class=\"fa fa-chevron-circle-left\" ng-click=\"onLeft()\"></i></button><div id=\"tabContainer\"><ul class=\"tabbable-line\"><li ng-repeat=\"item in allDocuments\" class=\"ng-viewer-theme-btn ng-viewer-theme-border\" ng-class=\"{'active': item.isFocused, 'side-pane-selected-icon, ng-viewer-theme-text' : item.isFocused }\"><span data-toggle=\"tab\" class=\"cursor-pointer\" ng-click=\"setFocusedDocument(item)\"><div class=\"textEllipsis\" ng-class=\"{'focused-item' : item.isFocused, 'ng-viewer-theme-text' : item.isFocused}\">{{item.name || 'untitled'}} <span ng-class=\"{'focused-item': item.isFocused, 'ng-viewer-theme-text' : item.isFocused}\"><i class=\"fa fa-times-circle\" ng-click=\"removeDocument(item)\"></i></span></div></span></li></ul></div><button id=\"rightSlide\" class=\"arrow ng-viewer-theme-btn\" style=\"border: none;background: transparent\"><i class=\"fa fa-chevron-circle-right\" ng-click=\"onRight()\"></i></button></div><div class=\"singleDocTab ng-viewer-theme-text\" ng-if=\"isMultipleDocumentAdded\"><div class=\"textEllipsis\" ng-class=\"{'focused-item' : item.isFocused, 'ng-viewer-theme-text' : item.isFocused}\">{{focusedDoc.name}}</div></div></div>"
  );


  $templateCache.put('../src/views/ui-page-doc.html',
    "<div align=\"center\" class=\"page\" id=\"page{{$index+1}}\" ng-repeat=\"page in doc.pages\" page-id=\"{{page.id}}\"><ui-page doc=\"doc\" doc-index=\"docIndex\" page=\"page\" pageid=\"{{page.id}}\" page-index=\"$index\"></ui-page></div>"
  );


  $templateCache.put('../src/views/ui-page-view.html',
    "<div id=\"pageViewDir\" class=\"page-container\"><div class=\"align-center\" ng-class=\"{'IVError' : notificationObj.type }\"><p ng-if=\"notificationObj.type === notificationType.ERROR\"><i class=\"fa fa-exclamation-triangle\"></i> {{notificationObj.message}}</p><p ng-if=\"notificationObj.type === notificationType.SUCCESS\"><i class=\"fa fa-check\"></i> {{notificationObj.message}}</p><p ng-if=\"notificationObj.type === notificationType.PROGRESS\"><i class=\"fa fa-exclamation-triangle\"></i> {{notificationObj.message}}</p></div><div class=\"pageDocContainer\" ng-repeat=\"page in viewablePages\" repeater ng-repeat-finished=\"onLoadPages\"><div align=\"center\" class=\"page\" id=\"page{{$index+1}}\" page-id=\"{{page.id}}\"><ui-page page=\"page\" pageid=\"{{page.id}}\" page-index=\"$index\"></ui-page></div></div></div>"
  );


  $templateCache.put('../src/views/ui-page.html',
    "<div class=\"page-contr\"><div ng-if=\"isLoadingVisible && !page.error.PAGE.isError && page.isValidPage\" class=\"loader-image\"></div><div ng-if=\"page.error.PAGE.isError && page.isValidPage\" class=\"page-error-msg\"><p style=\"color: red\"><i class=\"fa fa-exclamation-triangle\"></i></p><p>{{page.error.PAGE.errorMsg}}</p></div><div class=\"pageCanvasContainer page-image\" style=\"background-color: white\"><div class=\"dummyPageContr\" ng-if=\"!page.isValidPage\"><span style=\"font-size: 20px; font-weight: bold\">Preview is not available for this document</span><p style=\"margin-top: 70px\"><a href=\"\" ng-click=\"onDownloadInvalidDocument()\">Download Original Document</a></p></div></div><div class=\"pageSvgContainer\"></div></div>"
  );


  $templateCache.put('../src/views/ui-predefined-zooms.html',
    "<div class=\"dropdown commonMenuDropdown\"><button style=\"width: 105px\" type=\"button\" data-toggle=\"dropdown\">{{selectedSize}} <span class=\"caret\"></span></button><ul class=\"dropdown-menu tool-list\" style=\"width: 109px\"><li class=\"cursor-pointer tool-items\" ng-repeat=\"item in resizeOptions\" ng-click=\"predefinedZoomChange(item)\"><a><div class=\"predefinedZoomListContent\"><span ng-if=\"item.isSelected\"><i class=\"fa fa-check\"></i></span></div><div class=\"predefinedZoomListContent\"><span>{{item.name}}</span></div></a></li></ul></div>"
  );


  $templateCache.put('../src/views/ui-side-panel-navigation.html',
    "<ul id=\"viewerMenuList\" ng-init=\"sidePaneSelectedButton=1\"><li id=\"sidePaneThumbnailView\" ng-class=\"{'side-pane-selected-icon' : (sidePaneSelectedButton==1), 'ng-viewer-theme-text' : (sidePaneSelectedButton==1)}\"><button class=\"ng-viewer-theme-btn side-panel-icons no-border\" ng-init=\"thumbnailSelected=true\" ng-click=\"changeView(leftSectionAvailableViews.THUMBNAIL, sidePaneSelectedButton=1);\" title=\"Thumbnails\"><i class=\"fa fa-film\"></i></button></li><li id=\"sidePaneDocumentView\" ng-class=\"{'side-pane-selected-icon' : (sidePaneSelectedButton==2), 'ng-viewer-theme-text': (sidePaneSelectedButton==2), 'disable-button': !isMetaDataView}\"><button class=\"ng-viewer-theme-btn side-panel-icons no-border\" ng-init=\"documentViewSelected=false\" ng-click=\"changeView(leftSectionAvailableViews.META_DATA, sidePaneSelectedButton=2);\" title=\"Document Properties\"><i class=\"fa fa-file-o\" style=\"font-size: 1.2em\"></i><i class=\"fa fa-info\" style=\"position: absolute; margin-left: -11px; margin-top:3px; font-size:12px\"></i></button></li><!--<li id=\"sidePaneExtractView\" class=\"disable-button\" ng-class=\"{'side-pane-selected-icon':(sidePaneSelectedButton==3), 'ng-viewer-theme-text': (sidePaneSelectedButton==3),}\">\r" +
    "\n" +
    "        <button class=\"ng-viewer-theme-btn side-panel-icons no-border\" ng-init=\"extractViewSelected=false\" ng-click=\"changeView(leftSectionAvailableViews.EXTRACT_VIEW, sidePaneSelectedButton=3);\" title=\"Page Properties\"><i class=\"fa fa-list\"></i></button>\r" +
    "\n" +
    "    </li> --><li id=\"sidePaneCommentView\" ng-class=\"{'side-pane-selected-icon':(sidePaneSelectedButton==3), 'ng-viewer-theme-text': (sidePaneSelectedButton==3), 'disable-button': !isCommentView}\"><button class=\"ng-viewer-theme-btn side-panel-icons no-border\" ng-disabled=\"!isCommentView\" ng-init=\"commentViewSelected=false\" ng-click=\"changeView(leftSectionAvailableViews.COMMENT, sidePaneSelectedButton=3);\" title=\"Comments\"><i class=\"fa fa-comments-o\"></i></button></li></ul>"
  );


  $templateCache.put('../src/views/ui-stampbar.html',
    "<div class=\"dv-btn-group stampbar-container\"><button class=\"dv-btn dv-btn-default disable-button\"><i class=\"fa fa-gavel\"></i></button> <button class=\"dv-btn dv-btn-default disable-button\"><i class=\"fa fa-star-o\"></i></button> <button class=\"dv-btn dv-btn-default disable-button\"><i class=\"fa fa-square-o\"></i></button> <button class=\"dv-btn dv-btn-default disable-button\"><i class=\"fa fa-lightbulb-o\"></i></button></div>"
  );


  $templateCache.put('../src/views/ui-thumb-menu.html',
    "<div id=\"thumb-menu-dir\"><ul class=\"menu pull-right\"><li><button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.zoomIn }\" ng-click=\"zoomIn()\" ng-disabled=\"true\" title=\"Zoom In\"><i class=\"fa fa-search-plus\"></i></button></li><li><button class=\"ng-viewer-theme-btn cursor-pointer\" ng-class=\"{'disable-button' : !controls.zoomOut }\" ng-click=\"zoomOut()\" ng-disabled=\"true\" title=\"Zoom Out\"><i class=\"fa fa-search-minus\"></i></button></li><li><button class=\"cursor-pointer\" ng-class=\"(!controls.rotateLeft) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onRotateLeft()\" title=\"Rotate Left\"><i class=\"fa fa-rotate-left\"></i></button></li><li><button class=\"cursor-pointer\" class=\"cursor-pointer\" ng-class=\"(!controls.rotateRight) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onRotateRight()\" title=\"Rotate Right\"><i class=\"fa fa-rotate-right\"></i></button></li><li><button class=\"cursor-pointer\" ng-class=\"(!controls.cut) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onEditThumb('cut')\" title=\"{{tooltip.cutPage}}\"><i class=\"fa fa-cut\"></i></button></li><!-- <li>\r" +
    "\n" +
    "            <button class=\"cursor-pointer disable-button\" ng-click=\"onEditThumb('copy')\"><i class=\"fa fa-files-o\"></i></button>\r" +
    "\n" +
    "        </li> --><li><button class=\"cursor-pointer\" ng-class=\"(!controls.paste) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onEditThumb('paste')\" title=\"{{tooltip.pastePage}}\"><i class=\"fa fa-paste\"></i></button></li><li><button class=\"cursor-pointer\" ng-class=\"(!controls.split) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onSplitDocument()\" title=\"{{tooltip.splitPage}}\"><i class=\"fa fa-chain-broken\"></i></button></li><li><button class=\"cursor-pointer\" ng-class=\"(!controls.delete) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"onDeleteSelectedThumbs()\" title=\"Page Delete\"><i class=\"fa fa-trash-o\"></i></button></li><li><button class=\"cursor-pointer\" ng-class=\"(!controls.reorder) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-click=\"freezeOrUnfreezeReorder()\" title=\"{{reorderTitle}}\"><i class=\"fa fa-unlock\" ng-if=\"isThumbSortable\"></i><i class=\"fa fa-lock\" ng-if=\"!isThumbSortable\"></i></button></li></ul></div>"
  );


  $templateCache.put('../src/views/ui-thumbnail-doc.html',
    "<div class=\"thumb-doc-header ng-viewer-theme-text\">{{doc.name}}</div><div class=\"thumbContr\"><div class=\"thumb\" id=\"thumb{{$index+1}}\" ng-repeat=\"thumb in doc.viewablePages\" ng-class=\"{ 'selected' : thumb.isSelected }\" thumb-id=\"{{thumb.id}}\" data-pagenumber=\"{{$index+1}}\"><ui-thumbnail doc=\"doc\" doc-index=\"docIndex\" thumb=\"thumb\" thumbid=\"{{thumb.id}}\" thumb-index=\"$index\"></ui-thumbnail></div></div>"
  );


  $templateCache.put('../src/views/ui-thumbnail-view.html',
    "<div class=\"thumViewContainer\"><div class=\"heading\"><div class=\"pull-left heading-1\">Thumbnails</div><div class=\"pull-right heading-1\"><div class=\"pull-right cursor-pointer thumb-expand-icon ng-viewer-theme-btn\" ng-click=\"manageThumbBox($event)\" ng-class=\"thumbHeaderIcon == 'right' ? 'fa fa-caret-right' : 'fa fa-caret-left'\" title=\"Full Thumbnail View\"></div><hr></div></div><div class=\"thumbview\"><!-- <div class=\"dummyThumbnail\" ng-if=\"controls.invalidDocument\">\r" +
    "\n" +
    "            No Preview\r" +
    "\n" +
    "        </div> --><div class=\"sortable-container\"><ul class=\"thumb-wrapper\" ng-repeat=\"doc in viewableDocuments\" ng-if=\"doc.pages.length\" id=\"{{doc.id}}\" ui-thumbnail-doc doc=\"doc\" doc-index=\"$index\" repeater ng-repeat-finished=\"onLoadThumbs\"></ul></div></div><ui-thumb-menu></ui-thumb-menu></div>"
  );


  $templateCache.put('../src/views/ui-thumbnail.html',
    "<div align=\"center\" class=\"thumb-contr\" style=\"position: relative\" ng-class=\"{'thumbCut' : thumb.action==='cut'}\"><div ng-if=\"isThumbLoadingVisible && !thumb.error.THUMBNAIL.isError\" class=\"thumb-loader-image\"></div><div ng-if=\"thumb.error.THUMBNAIL.isError\" class=\"thumb-error-msg\"><p style=\"color: red\"><i class=\"fa fa-exclamation-triangle\"></i></p><p>{{thumb.error.THUMBNAIL.errorMsg}}</p></div><div><div class=\"thumb-border\" ng-class=\"{ 'thumb-image-selected' : thumb.isSelected , 'ng-viewer-theme-bg': thumb.isSelected, 'thumb-image-focused' : thumb.isFocused, 'thumb-cut':  (thumb.action === 'cut')}\"><div class=\"thumbCanvasContainer thumb-image\"><div class=\"dummyThumbnail\" ng-if=\"!thumb.isValidPage\">No Preview</div></div></div></div><div class=\"pageNumber ng-viewer-theme-text\">{{thumb.pageNumber}}</div></div>"
  );


  $templateCache.put('../src/views/ui-toolbar.html',
    "<ul class=\"toolbar menu tools\"><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.POINTER}\"><button ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" title=\"Selection\" ng-click=\"annotationPointer()\"><i class=\"fa fa-mouse-pointer\"></i></button></li><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.COMMENT}\"><button title=\"Comment\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationComment()\"><i class=\"fa fa-comment-o\"></i></button></li><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.HIGHLIGHT}\"><button title=\"Highlight\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationHighlight()\"><i class=\"fa fa-icon-edit-sign\"></i></button></li><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.TEXT}\"><button title=\"Text\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationText()\"><i class=\"fa fa-font\"></i></button></li><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.STRIKEOUT}\"><button title=\"StrikeOut\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationStrikeOut()\"><i class=\"fa fa-strikethrough\"></i></button></li><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.UNDERLINE}\"><button title=\"Underline\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationUnderLine()\"><i class=\"fa fa-underline\"></i></button></li><!-- <li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.ERASE}\">\r" +
    "\n" +
    "        <button title=\"Erase\" class=\"\" ng-click=\"annotationErase()\"><i class=\"fa fa-eraser\"></i></button>\r" +
    "\n" +
    "    </li>\r" +
    "\n" +
    "    <li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.REDACTION}\">\r" +
    "\n" +
    "        <button title=\"Redaction\" class=\"\" ng-click=\"annotationRedaction()\"><i class=\"fa fa-tint\"></i></button>\r" +
    "\n" +
    "    </li> --><li ng-class=\"{'ng-viewer-theme-text': annotationTypeId == annotationKeys.REDACTION}\"><button title=\"Redaction\" ng-class=\"(!controls.annotation) ? 'disable-button' : 'ng-viewer-theme-btn'\" ng-disabled=\"!controls.annotation\" ng-click=\"annotationRedaction()\"><i class=\"fa fa-eraser\"></i></button></li><li class=\"li-separator\"></li><li><button title=\"Snapshot\" class=\"disable-button\" ng-disabled=\"!controls.annotation\"><i class=\"fa fa-camera\"></i></button></li></ul>"
  );


  $templateCache.put('../src/views/uiViewer.html',
    "<div id=\"ui-viewer-container\"><div id=\"theme\" class=\"color-rfng-heading-text-color\"></div><div id=\"common-tools\" class=\"tab-pane active in\"><ui-common-function></ui-common-function></div><div id=\"Stamps\" class=\"dv-tab-pane tab-content-tools\" ng-if=\"selectedTool.name == 'Stamps'\"><ui-stampbar></ui-stampbar></div><div id=\"annotation-tools\" class=\"dv-tab-pane tab-content-tools\" ng-if=\"selectedTool.name == 'Tools'\"><ui-toolbar></ui-toolbar></div><div id=\"document-tabs\" ng-if=\"allDocuments.length\"><ui-document-tab></ui-document-tab></div><div id=\"ui-viewer-body\"><div id=\"ui-side-panel-nav\"><ui-side-panel-navigation></ui-side-panel-navigation></div><div id=\"ui-viewer-content\"><div id=\"viewer-content\" class=\"\"><bg-splitter orientation=\"horizontal\"><bg-pane min-size=\"minSize\" max-size=\"maxSize\"><div ng-show=\"leftSectionSelectedView == 'thumbnail'\" id=\"thumb-container\"><ui-thumbnail-view thumb-header-icon=\"thumbHeaderIcon\"></ui-thumbnail-view></div><div id=\"documentViewContent\" ng-show=\"leftSectionSelectedView == 'metaData'\"></div><div ng-show=\"leftSectionSelectedView == 'extraction'\">Extract view template goes here</div><div ng-show=\"leftSectionSelectedView == 'comment'\" id=\"annotation-comment-contr\"><ui-comment-view></ui-comment-view></div></bg-pane><bg-pane><ui-page-view></ui-page-view></bg-pane></bg-splitter></div></div></div></div>"
  );

}]);
