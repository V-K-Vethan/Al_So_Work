uiv.constant('viewerConst', {
    COMMON_FUNCTION: {
        RESIZE_OPTIONS: [
         {
            id: 0,
            name: '25%',
            scale: 0.25
        }, {
            id: 1,
            name: '50%',
            scale: 0.5
        }, {
            id: 2,
            name: '75%',
            scale: 0.75
        }, {
            id: 3,
            name: '100%',
            scale: 1
        }, {
            id: 4,
            name: '125%',
            scale: 1.25
        }, {
            id: 5,
            name: '150%',
            scale: 1.5
        }, {
            id: 6,
            name: '200%',
            scale: 2
        }, {
            id: 7,
            name: '400%',
            scale: 4
        }, {
            id: 8,
            name: 'Actual Size',
            scale: 1
        }, {
            id: 9,
            name: 'Best Fit',
            scale: null
        }, {
            id: 10,
            name: 'Fit to Width',
            scale: null
        }],
        RESIZE_KEYS: {
            TWO_FIVE: 0,
            FIVE_ZERO: 1,
            SEVEN_FIVE: 2,
            ONE_ZERO_ZERO: 3,
            ONE_TWO_FIVE: 4,
            ONE_FIVE_ZERO: 5,
            TWO_ZERO_ZERO: 6,
            FOUR_ZERO_ZERO: 7,
            ACTUAL_SIZE: 8,
            ZOOM_TO_PAGE_LEVEL: 9,
            FIT_WIDTH: 10
        },
        TOOLS: [{
            id: 1,
            name: 'Hide Tools'
        }, {
            id: 2,
            name: 'Tools'
        }],
        TOOL_KEYS: {
            TOOLS: 0,
            HIDE_TOOLS: 1,
            STAMPS: 2
        }
    },
    // sidePanelNavView : ['thumbnailView', 'documentView', 'extractView', 'commentView'],
    VIEWS : {
        THUMBNAIL : 'thumbnail',
        META_DATA: 'metaData',
        COMMENT: 'comment',
        EXTRACT_VIEW: 'extraction',
        HISTORY: 'history'
    },
    ResponseMessages: {
        error: {
            UIV000: 'Looks like there is a technical issue. Please try again after sometime.', // default technical message
            UIV200: 'There are no matching documents', //Search resulted zero document
            UIV401: 'Looks like there is a technical issue. Please try again after sometime.', //unauthorised
            UIV400: 'Looks like there is a technical issue. Please try again after sometime.', // bad-request
            UIV404: 'Looks like there is a technical issue. Please try again after sometime.', //not-found
            UIV503: 'Looks like there is a technical issue. Please try again after sometime.', //service-unavailable
            UIV403: 'Looks like there is a technical issue. Please try again after sometime.', //forbidden- no access
            UIV500: 'Looks like there is a technical issue. Please try again after sometime.' // Internal server error
        },
        success: {
            SPLIT_DOCUMENT: 'New document has been created successfully with selected pages',
            PAGE_DELETE: 'Selected pages has been deleted successfully',
            REORDER_PAGES: 'Pages has been reordered successfully',
            DEFAULT : 'Operation has been completed successfully'
        }
    },
    MinZoom: 0.2,
    MaxZoom: 4,
    PAGE_FIT_TYPE: {
        DEFAULT: 0,
        FIT_TO_WIDTH: 10,
        BEST_FIT:9
    },
    PAGE_ORIENTATION:{
        PORTRAIT: 0,
        LANDSCAPE:1
    },

    VIEW_STATE: {
        DISABLED: 0,
        BASIC: 1,
        MIDDLE_PAGE: 2,
        INVALID_DOCUMENT: 3,
        DISABLE_EDIT: 4,
        CORRUPT_PAGE: 5
    },

    CROSS_DOC_OPR_TYPE : {
        CUT_PASTE: 'cutPaste',
        REORDER: 'reorder'
    },

    UI_ELEMENTS:{
        NEXT_PAGE: 0,
        PREV_PAGE: 1,
        PAGE_NO: 2,
        ZOOM_IN: 3,
        ZOOM_OUT: 4,
        PREDEFINED_ZOOM: 5,
        BEST_FIT: 6,
        FIT_TO_WIDTH: 7,
        ANTIALIAS: 8,
        THUMBNAIL: 9,
        ROTATE_LEFT: 10,
        ROTATE_RIGHT: 11,
        CUT: 12,
        COPY: 13,
        PASTE: 14,
        SPLIT: 15,
        DELETE: 16,
        FREEZE_REORDER: 17,
        DOWNLOAD : 18,
        ANNOTATION: 19,
        INVALID_DOCUMENT: 20,
        DEFAULT_PAGE: 21,
        COMMENT: 22,
        META_DATA: 23
    },

    NOTIFICATION_TYPE: {
        DEFAULT: 0,
        SUCCESS: 1,
        ERROR: 2,
        PROGRESS: 3
    },
    ANNOTATION_TYPES: {
        1 : {
            label: 'Pointer',
            element: '',
            cursor: 'crosshair'
        },
        2 : {
            label: 'COMMENTS',
            element: 'rect',
            cursor: 'crosshair'
        },
        3 : {
            label: 'UNDERLINE',
            element: '',
            cursor: 'crosshair'
        },
        4 : {
            label: 'TEXT',
            element: '',
            cursor: 'crosshair'
        },
        5 : {
            label: 'STRIKETHROUGH',
            element: '',
            cursor: 'crosshair'
        },
        6 : {
            label: 'ERASE',
            element: '',
            cursor: 'crosshair'
        },
        7 : {
            label: 'REDACTION',
            element: '',
            cursor: 'crosshair'
        },
        8 : {
            label: 'HIGHLIGHT',
            element: '',
            cursor: 'crosshair'
        }
    },
    ANNOTATION_KEYS: {
        NOSELECTION: 0,
        POINTER: 1,
        COMMENT: 2,
        UNDERLINE: 3,
        TEXT: 4,
        STRIKEOUT: 5,
        ERASE: 6,
        REDACTION: 7,
        HIGHLIGHT: 8
    },
    ANNOTATION_NAMES: {
        Pointer: 1,
        Comment: 2,
        Underline: 3,
        Text: 4,
        Strikethrough: 5,
        Erase: 6,
        Redaction: 7,
        Highlight: 8
    },
    VIEWER_MAX_DOC_ALLOCATION : 50,
    ADD_DOCUMENT_CONFIRMATION : 'Only 50 documents can be viewed in the viewer. Adding a new one will delete the previous document. Are you sure you want to proceed?',

    RESPONSE_STATUS: {
        SUCCESS : 'success',
        FAILURE : 'failure',
        PROGRESS: 'inProgress'
    },
    displayType : {
        PAGE : "PAGE",
        THUMBNAIL: "THUMBNAIL"
    },
    SHORTCUT_SCOPE: {
        VIEWER: 'ng-viewer'
    },
    NAV_VIEWS : {
        THUMBNAIL : 'thumbnail',
        META_DATA: 'metaData',
        COMMENT: 'comment'
    },
    viewerMenuMode: {
                    DEFAULT_SIZE: 1,
                    LAST_VISITED_WIDTH: 2,
                    FULL_SCREEN: 3,
                    WIDTH_FROM_OTHER: 4
                }
});
