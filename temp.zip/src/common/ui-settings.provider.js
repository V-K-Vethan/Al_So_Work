uiv.factory('ViewerSetting', function(viewerConst, ViewerSettingService, ViewerEvents, ViewerUtilitis){

    return function viewerSetting(param) {
        var defaultSettings = {
            thumbnail : true,
            css : {},
            actions : {
                viewer:{
                    nextPage: true,
                    prevPage: true,
                    zoomOut:true,
                    zoomIn:true,
                    rotateRight:true,
                    pageNo : true,
                    rotateLeft: true,
                    predefinedZoom:true,
                    fitToWidth:true,
                    bestFit:true,
                    comment: true,
                    continousNavigation: true,
                },
                business:{
                    delete: true,
                    split: { userSelectedOrder : false },
                    cut: true,
                    paste: true,
                    reorder: true,
                    download:true,
                    antialias:true,
                    snapShot:true,
                    annotation: {
                        create: true,
                        read: true,
                        update: true,
                        delete: true
                    }
                }
            },
            shortcuts: {
                prevPage: 'up',
                nextPage: 'down',
                jumpToPage: 'shift+j',
                selectPagesUp: 'shift+up',
                selectPagesDown: 'shift+down',
                cutPage: 'ctrl+x',
                pastePage: 'ctrl+v',
                undoCutPaste: 'esc',
                splitPage: 'ctrl+\\',
                pageScrollUp: 'ctrl+up',
                pageScrollDown: 'ctrl+down',
                prevDoc: 'pageup',
                nextDoc: 'pagedown'

            },
            tooltips: {
                cutPage: 'Cut (Ctrl+X)',
                pastePage: 'Paste (Ctrl+V)',
                splitPage: 'Split (Ctrl+\\)',
            },
            viewerStates : {
                DISABLED: 0,
                BASIC: 1,
                MIDDLE_PAGE: 2,
                INVALID_DOCUMENT: 3,
                DISABLE_EDIT: 4
            },
            displayType : {
                PAGE : "PAGE",
                THUMBNAIL: "THUMBNAIL"
            },
            errorCodes : {
                PAGE_NOT_FOUND : "pageNotFound",
                PAGE_INCORRECT : "pageIncorrect",
                THUMB_NOT_FOUND : "thumbNotFound",
                THUMB_INCORRECT : "thumbIncorrect",
                SPLIT_DOCUMENT : 'splitDocument',
                PAGE_DELETE : 'pageDelete',
                REORDER_PAGES : 'reorderPages',
                UNDO_REORDER_PAGES: 'undoReorderPages',
                FIRST_PAGE: 'firstPage',
                LAST_PAGE: 'lastPage',
                INVALID_PAGE: 'invalidPage',
                MAX_ZOOM: 'maxZoom',
                MIN_ZOOM: 'minZoom',
                DOCUMENT_ALREADY_AVAILABLE : "documentAlreadyAvailable",
                RIGHT_CLICK_DISABLED : 'rightClickDisabled',
                SAVE_ANNOTATION : 'saveAnnotation',
                DELETE_ANNOTATION : 'deleteAnnotation',
                REPLY_COMMENT : 'replyComment',
                DELETE_COMMENT : 'deleteComment',
                GET_ALL_ANNOTATIONS: 'getAllAnnotations',
                ANNOTATION_IN_PROGRESS: 'annotationInProgress',
                MULTISELECT_THUMB_RESTRICT: 'multiselectThumbRestict',
                SORT_OUT_OF_BOUNDARY: 'sortOutOfBoundary'
            },
            successCodes : {
                SPLIT_DOCUMENT : 'splitDocument',
                PAGE_DELETE: 'pageDelete',
                REORDER_PAGES: 'reorderPages',
                CUT_PASTE: 'cutPaste',
                SAVE_ANNOTATION : 'saveAnnotation',
                DELETE_ANNOTATION : 'deleteAnnotation',
                REPLY_COMMENT : 'replyComment',
                DELETE_COMMENT : 'deleteComment'
            },
            progressCodes: {
                REORDER_PAGES: 'reorderPages'
            },
            successMessages : {
                splitDocument : 'New document has been created successfully with selected pages',
                pageDelete: 'Selected pages has been deleted successfully',
                reorderPages: 'Pages has been reordered successfully',
                cutPaste: 'Pages has been pasted successfully',
                saveAnnotation: 'Annotation has been saved successfully',
                deleteAnnotation: 'Annotation has been deleted successfully',
                replyComment: 'Reply comment has been added successfully',
                deleteComment: 'Comment has been deleted successfully'
            },
            errorMessages : {
                splitDocument : 'Looks like there is a technical issue. Please try again after sometime.',
                pageDelete: 'Looks like there is a technical issue. Please try again after sometime.',
                reorderPages: 'Looks like there is a technical issue. Please try again after sometime.',
                undoReorderPages: 'Your changes has been rolled back',
                pageIncorrect : 'Page not in correct format.',
                pageNotFound : 'Page is not found',
                thumbNotFound: 'Thumbnail not found',
                thumbIncorrect : 'Thumbnail not in correct format.',
                firstPage: 'First page reached.',
                lastPage: 'Last page reached.',
                invalidPage: 'Invalid page number.',
                maxZoom: 'Maximum zoom level reached.',
                minZoom: 'Minimum zoom level reached.',
                documentAlreadyAvailable : "Document is already available in the viewer",
                rightClickDisabled : 'Right click is disabled',
                saveAnnotation: 'Looks like there is a technical issue. Please try again after sometime.',
                deleteAnnotation: 'Looks like there is a technical issue. Please try again after sometime.',
                replyComment: 'Looks like there is a technical issue. Please try again after sometime.',
                deleteComment: 'Looks like there is a technical issue. Please try again after sometime.',
                getAllAnnotations: 'Looks like there is a technical issue. Please try again after sometime.',
                annotationInProgress: 'Please wait while annotation is being saved',
                multiselectThumbRestict: 'Multiple pages can only be selected within a document',
                sortOutOfBoundary : 'Cannot sort the pages out of boundary. Instead please use Cut and paste option'
            },
            progressMessages : {
                reorderPages: 'Reorder is in Progress...'
            },
            ANNOTATION_KEYS: {
                POINTER: 1,
                COMMENTS: 2,
                UNDERLINE: 3,
                TEXT: 4,
                STRIKETHROUGH: 5,
                ERASE: 6,
                REDACTION: 7,
                HIGHLIGHT: 8
            },
            viewerMenuMode: {
                    DEFAULT_SIZE: 1,
                    LAST_VISITED_WIDTH: 2,
                    FULL_SCREEN: 3,
                    WIDTH_FROM_OTHER: 4
            },
            VIEWER_NAV_MENU: {
                                "thumbnail": {
                                    mode : 2,
                                    size : 150,
                                    minSize: 150,
                                    maxSize: 610
                                },
                                "metaData": {
                                    mode : 2,
                                    size : 320,
                                    minSize: 150,
                                    maxSize: 610,
                                },
                                "comment": {
                                    mode : 2,
                                    size : 350,
                                    minSize: 150,
                                    maxSize: 610
                                }
            }
        };

        this.settings = {};
        if (param) {
            this.settings = ViewerUtilitis.mergeRecursive(defaultSettings, param);
        } else {
            this.settings = defaultSettings;
        }
        ViewerSettingService.setViewerSettings(this.settings);
        //TODO: else part missing for default settings
        return this.settings;
    };
});
