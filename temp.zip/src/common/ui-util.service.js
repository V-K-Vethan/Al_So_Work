uiv.service('ViewerUtilitis', ['viewerConst',
    function(viewerConst) {
        var utilsService = {
            getErrorMessage: function getErrorMessage(errorCode) {
                switch (errorCode) {
                    case 400:
                        return viewerConst.ResponseMessages.error.UIV400;
                    case 401:
                        return viewerConst.ResponseMessages.error.UIV401;
                    case 404:
                        return viewerConst.ResponseMessages.error.UIV404;
                    case 500:
                        return viewerConst.ResponseMessages.error.UIV500;
                    case 503:
                        return viewerConst.ResponseMessages.error.UIV503;
                    case 0:
                        return;
                    default:
                        return viewerConst.ResponseMessages.error.UIV000;
                }
            },
            getSuccessMessage: function getSuccessMessage(successCode) {
                switch (successCode) {
                    case 'SPLIT_DOCUMENT':
                        return viewerConst.ResponseMessages.success.SPLIT_DOCUMENT;
                    case 'PAGE_DELETE':
                        return viewerConst.ResponseMessages.success.PAGE_DELETE;
                    case 'REORDER_PAGES':
                        return viewerConst.ResponseMessages.success.REORDER_PAGES;
                    default:
                        return viewerConst.ResponseMessages.success.DEFAULT;
                }
            },
            mergeRecursive: function mergeRecursive(obj1, obj2) {
                for (var p in obj2) {
                    try {
                        // Property in destination object set; update its value.
                        if (obj2[p].constructor == Object) {
                            obj1[p] = mergeRecursive(obj1[p], obj2[p]);

                        } else {
                            obj1[p] = obj2[p];

                        }
                    } catch (e) {
                        // Property in destination object not set; create it and set its value.
                        obj1[p] = obj2[p];
                    }
                }
                return obj1;
            },
            getHTML : function getHTML(who, deep){
                if(!who || !who.tagName) return '';
                var txt, ax, el= document.createElement("div");
                el.appendChild(who.cloneNode(false));
                txt= el.innerHTML;
                if(deep){
                    ax= txt.indexOf('>')+1;
                    txt= txt.substring(0, ax)+who.innerHTML+ txt.substring(ax);
                }
                el= null;
                return txt;
            },
            tranformStringToMatrix: function tranformStringToMatrix(transform) {
                var parts = transform.split('r');
                var s = parts[0].substring(1).split(',');
                parts = parts[1].split('t');
                var r = parts[0].substring(0).split(',');
                var t = parts[1].substring(0).split(',');

                return {
                    scale: {
                        x: s[0],
                        y: s[1]
                    },
                    center: {
                        x: s[2],
                        y: s[3]
                    },
                    translate: {
                        x: t[0],
                        y: t[1]
                    },
                    rotation: {
                        angle: r[0],
                        cx: r[1],
                        cy: r[2]
                    }
                };
            },
            /**
            * Converting dom to string
            * @return {[type]} [description]
            */
            htmlEscape : function htmlEscape(html) {
                return String(html)
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            },
            /**
            * Converting string to dom
            * @return {[type]} [description]
            */
            htmlUnescape : function htmlUnescape(value) {
                return String(value)
                .replace(/&quot;/g, '"')
                .replace(/&#39;/g, "'")
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&');
            },
            isSorted : function(list) {
                var isSorted = true;
                for(var i = 0, len = list.length; i < len; i++) {
                    for (j = i + 1; j < len; ++j) {
                        if (list[i] > list[j]) {
                            isSorted = false;
                        }
                    }
                }
                return isSorted;
            }
        }
        return utilsService;
    }
]);
