uiv.factory('ViewerEvents', [
    function() {
        var Event = {
            PAGE_CHANGED: 'pageChanged',
            DOCUMENT_CHANGED: 'documentChanged',
            NEW_DOCUMENT_ADDED: 'newDocumentAdded',
            SCALE_CHANGED: 'scaleChanged',
            PAGE_FIT_CHANGED: 'pageFitChanged',
            ROTATION_CHANGED: 'rotationChanged',
            CUT_PAGES_DONE: 'cutPagesDone',
            COPY_PAGES_DONE: 'copyPagesDone',
            PASTE_PAGES_DONE: 'pastePagesDone',
            DELETE_PAGES_DONE: 'deletePagesDone',
            REORDER_PAGES_DONE: 'repoderPagesDone',
            DOCUMNETS_UNLOCKED: 'documentUnlocked',
            DOCUMNETS_LOCKED: 'documentLocked',
            ANNOTATION_TOOL_BOX_OPENED: "annotationToolboxOpened",
            STAMP_TOOL_BOX_OPENED: "stampToolboxOpened",
            TOOL_BOX_HIDDEN: "toolboxHidden",
            THUMBNAIL_PANEL_OPENED: "thumbnailPanelOpened",
            THUMBNAIL_PANEL_CLOSED: "thumbnailPanelClosed",
            DOCUMENT_METADATA_PANEL_OPENED: "documentMetadataPanelOpened",
            PAGE_METADATA_PANEL_OPENED: "pageMetadataPanelOpened",
            COMMENT_PANEL_OPENED: "commentMetadataPanelOpened",
            REPEAT_FINISHED: 'repeatFinished',
            THUMBNAIL_SELECTION_CHANGED: 'thumbnailSelectionChanged',
            ANNOTATION_SELECTION_CHANGED: 'annotaionSelectionChanged',
            SHOW_NOTIFICATION: 'showNotification',
            THUMB_SELECTION_CHANGED: 'thumbSelectionChanged',
            THUMB_SORTABILITY_CHNAGED: 'thumbSortabilityChanged',
            JUMP_TO_PAGE: 'jumpToPage',
            NAV_TO_THUMB: 'navToThumb',
            PROCESS_REORDER: 'processReorder',
            // TODO: need to deprecate
            //SET_REORDER_STATE: 'setReorderState',
            //TODO: need to use DOCUMENT_CHANGED in place of ON_DOC_CHANGE
            //ON_DOC_CHANGE: 'onDocumentChange',
            //SIDE_PANEL_NAV_VIEW: 'sidePanelNavView',
            SHOW_PAGE_IN_RANGE: 'showPagesInRange',
            //FOCUSED_DOCUMENT: 'focusedDocument',
            VIEWER_RESIZED: "viewerResized",
            REORDER_OPERATION_DONE: "reorderOperationDone",
            UPDATE_COMMENT_REPLY: "update_comment_reply",
            HIGHLIGHT_ANNOTATION: "hightlightAnnotation",
            HIGHLIGHT_ANNOTATION_COMMENT: "hightlightAnnotationComment",
            DELETE_ANNOTATION: "deleteAnnotation",
            REMOVE_RAPHAEL_ELEMENT: "removeRaphaelElement",
            CANCEL_ANNOTATION: "cancelAnnotation",
            VIEWER_STATE_CHANGED: "viewerStateChanged",
            UPDATE_NAV_VIEW_SIZE: "updateNavViewSize"
        };

        var viewerScope;
        var thumbnailScope;
        var commentViewScope;

        Event.setViewerScope = function(rViewerScope) {
            viewerScope = rViewerScope;
        };

        Event.getViewerScope = function() {
            return viewerScope;
        };

        Event.notify = function(event, data, metaData) {
            viewerScope.$broadcast(event, data, metaData);
        };


        //TODO: All methods need to be removed..

        Event.setThumbnailScope = function(rthumbnailScope) {
            thumbnailScope = rthumbnailScope;
        };

        Event.getThumbnailScope = function() {
            return thumbnailScope;
        };

        Event.setCommentViewScope = function(rCommentViewScope) {
            commentViewScope = rCommentViewScope;
        };

        Event.getCommentViewScope = function() {
            return commentViewScope;
        };


        Event.notifyPageChanged = function(data) {
            viewerScope.$broadcast(Event.PAGE_CHANGED, data);
        };

        Event.notifyRepeatFinished = function() {
            viewerScope.$emit(Event.REPEAT_FINISHED);
        };

        Event.notifyUpdateCommentReply = function() {
            commentViewScope.$broadcast(Event.UPDATE_COMMENT_REPLY);
        };
        return Event;
    }
]);
