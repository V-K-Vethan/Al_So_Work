var uiv = angular.module('DemoApp', ['ui.router', 'restangular', 'ui']);

//var rootState = "demo";
uiv.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('example1', {
            name: 'example1',
            url: '/example1',
            templateUrl: "example1.html"
        })
        .state('example2', {
            name: 'example2',
            url: '/example2',
            templateUrl: "example2.html"
        }).state('example3', {
            name: 'example3',
            url: '/example3',
            templateUrl: "example3.html"
        });
    $urlRouterProvider.otherwise('/example1');
});

uiv.factory('RdvngRestSpiderService',
    function(Restangular) {
        return Restangular.withConfig(function(RestangularConfigurer) {
            // Set base url to local, it can be overridden by rdngRestConfigService
            RestangularConfigurer.setBaseUrl('');
            // Set full response on to get status code
            RestangularConfigurer.setFullResponse(true);
            // Cachebuster for IE 9 cache issue
            RestangularConfigurer.setFullRequestInterceptor(function(element, operation, what, url, headers, params) {

                if (operation === 'remove') {
                    return {
                        headers: headers,
                        params: _.extend(params, {
                            cache: new Date().getTime()
                        }),
                        element: null
                    };
                }

                if (operation === 'getList' || operation === 'get') {
                    return {
                        headers: headers,
                        params: _.extend(params, {
                            cache: new Date().getTime()
                        }),
                        element: element
                    };
                }
            });
        });
    }
);

uiv.service('RdvngDocumentModelService', [
    'RdvngRestSpiderService', "$q",
    function(RdvngRestSpiderService, $q) {
        var config = {};

        //rdcoruqa2 qa
        // config = {
        //     url : "http://rdcoruqa2-spider1.altidev.net:9991",
        //     token : 'token eyJVU0VSTkFNRSI6Ik1haGVzaC5rdW1hcnNAYWx0aXNvdXJjZS5jb20iLCJTUkNfQVBQX0lEIjoiNTZkNWQ4YzYzMGM5YTEwNWNjOWYyYjRiIn0=.efcd6dd5b7f2ff0226736fac9ebe3610abbc9f25'
        // };

        // rdcoreuqa1 qa
        // config = {
        //     url : "http://rdcoruqa1-lbmain1.altidev.net:9991",
        //     token : 'token eyJVU0VSTkFNRSI6Ik1haGVzaC5LdW1hclNAYWx0aXNvdXJjZS5jb20iLCJTUkNfQVBQX0lEIjoiNTc3MjI1Njk3N2E1NjQwZGM4Y2M5Yjc5In0=.7006d314558d514e518ffe79e0b6b779f38f8290'
        // };

        // rdcoreuqa1 ui dev
        // config = {
        //     url : "http://rdcoruqa1-lbmain1.altidev.net:9991",
        //     token : 'token eyJVU0VSTkFNRSI6InJhamF0Lmdob3JhaUBhbHRpc291cmNlLmNvbSIsIlNSQ19BUFBfSUQiOiI1NzdlM2I5Mjc3YTU2NDRiMzkzMmJhMjcifQ==.7ffa0c091793102765855cf9dcfae512d4232446'
        // };

        //rdcoruqa2 dev
        // config = {
        //     url : "http://rdcoruqa2-spider1.altidev.net:9991",
        //     token: "token eyJVU0VSTkFNRSI6IlJhamF0Lkdob3JhaUBhbHRpc291cmNlLmNvbSIsIlNSQ19BUFBfSUQiOiI1N2JhZDU4YjMwYzlhMTE1MjAyMjE5YzYifQ==.6f878a491277a612648aa0c63f8a541a8881ad73"
        // };

        // config = {
        //     url : "http://rdcoruqa2-spider1.altidev.net:9991",
        //     token: "token eyJVU0VSTkFNRSI6Ik1haGVzaC5LdW1hclNAYWx0aXNvdXJjZS5jb20iLCJTUkNfQVBQX0lEIjoiNTdiZWM5YzAzMGM5YTE0MDM2ZDljYzdjIn0=.ced1ca778ce02720cdd76dee618ee01d9062f86b"
        // };

        // rdcoreuqa1 qa
        config = {
            url : "http://rdcoruqa1-spider1.altidev.net:9991",
            token : 'token eyJVU0VSTkFNRSI6IlJhamF0Lkdob3JhaUBhbHRpc291cmNlLmNvbSIsIlNSQ19BUFBfSUQiOiI1N2Y0ZTIzYjc3YTU2NDU4ZGQ3ZDIxOGQifQ==.aaf7d86b75adfe49e37d91f5ee3957762949472c'
        };
        //config rest service
        RdvngRestSpiderService.setBaseUrl(config.url);

        // Set uid on local development
        RdvngRestSpiderService.setDefaultHeaders({
            'Authorization': config.token
        });

        this.getPageById = function(id) {
            //return RdvngRestSpiderService.all("documents/objects/" + id + "/latest?format=png&base64Encode=true").doGET();
            return RdvngRestSpiderService.all("documents/objects/" + id + "/latest?format=png&pngResolution=medium").withHttpConfig({
                responseType: 'blob'
            }).doGET();
        };

        this.getThumbById = function(id) {
            //return RdvngRestSpiderService.all("documents/objects/" + id + "/latest?format=thumbnail&base64Encode=true").doGET();
            return RdvngRestSpiderService.all("documents/objects/" + id + "/latest?format=thumbnail").withHttpConfig({
                responseType: 'blob'
            }).doGET();
        };

        this.getDocumentById = function(id) {
            var data = { "createdDtm": 1458034795000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a562d205a2", "businessKey": "abc", "extendedMetadata": { "category": "No title", "orderId": "Unfiled", "conditionId": 80064 }, "internalMetadata": {}, "version": "2.0", "docTypes": [{ "code": "UNCLASSIFIED", "label": "UNCLASSIFIED" }], "sourceFile": { "RAW": [{ "createdDtm": 1458034795000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a3", "pageNumber": 0, "documentVersion": "2.0", "checksum": "48b96da673b2bc006035fae86a224afc", "extendedMetadata": { "filename": "multiple.tif", "sizeInBytes": 1063098, "checksum": "48b96da673b2bc006035fae86a224afc", "contentType": "image/tiff" }, "internalMetadata": {} }] }, "pageSet": { "PNG": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }], "ALTERNATE": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }], "THUMBNAIL": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }] } };
            return RdvngRestSpiderService.all("documents/" + id + "/latest").doGET();
        };

        this.getDocuments = function(searchRequest) {
            var data = { "createdDtm": 1458034795000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a562d205a2", "businessKey": "abc", "extendedMetadata": { "category": "No title", "orderId": "Unfiled", "conditionId": 80064 }, "internalMetadata": {}, "version": "2.0", "docTypes": [{ "code": "UNCLASSIFIED", "label": "UNCLASSIFIED" }], "sourceFile": { "RAW": [{ "createdDtm": 1458034795000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a3", "pageNumber": 0, "documentVersion": "2.0", "checksum": "48b96da673b2bc006035fae86a224afc", "extendedMetadata": { "filename": "multiple.tif", "sizeInBytes": 1063098, "checksum": "48b96da673b2bc006035fae86a224afc", "contentType": "image/tiff" }, "internalMetadata": {} }] }, "pageSet": { "PNG": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }], "ALTERNATE": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }], "THUMBNAIL": [{ "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a4", "pageNumber": 1, "documentVersion": "2.0", "checksum": "aac91b827b807f8437dee9696f19bb1b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_1.png", "sizeInBytes": 39261, "checksum": "aac91b827b807f8437dee9696f19bb1b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a5", "pageNumber": 2, "documentVersion": "2.0", "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_2.png", "sizeInBytes": 24451, "checksum": "3926ed475e607f776f1c1d7e7adbb64a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a6", "pageNumber": 3, "documentVersion": "2.0", "checksum": "8b1bfc323255395b87743654b7734b40", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_3.png", "sizeInBytes": 81436, "checksum": "8b1bfc323255395b87743654b7734b40", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a7", "pageNumber": 4, "documentVersion": "2.0", "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_4.png", "sizeInBytes": 86925, "checksum": "5aaafc0a5800c7ebe5ef9b02f5f858f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305a9", "pageNumber": 5, "documentVersion": "2.0", "checksum": "5de6b7b981820e6627a506d6d67340dd", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_6.png", "sizeInBytes": 83105, "checksum": "5de6b7b981820e6627a506d6d67340dd", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305aa", "pageNumber": 6, "documentVersion": "2.0", "checksum": "34df04e51b2da2a79f92c5987241e7b6", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_7.png", "sizeInBytes": 77079, "checksum": "34df04e51b2da2a79f92c5987241e7b6", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ab", "pageNumber": 7, "documentVersion": "2.0", "checksum": "b123cc5d75c827b98887cc42b4f5551a", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_8.png", "sizeInBytes": 69665, "checksum": "b123cc5d75c827b98887cc42b4f5551a", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ac", "pageNumber": 8, "documentVersion": "2.0", "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_9.png", "sizeInBytes": 56025, "checksum": "f00f22d9e90d12b1f2f6fee8fb43ca35", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ad", "pageNumber": 9, "documentVersion": "2.0", "checksum": "510589b65330653718a6e9e88e442b04", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_10.png", "sizeInBytes": 68170, "checksum": "510589b65330653718a6e9e88e442b04", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305ae", "pageNumber": 10, "documentVersion": "2.0", "checksum": "b530c426b638b106e4e9d9d5f2145a10", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_11.png", "sizeInBytes": 58824, "checksum": "b530c426b638b106e4e9d9d5f2145a10", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305af", "pageNumber": 11, "documentVersion": "2.0", "checksum": "f875b7030889264db498eae698b2cb43", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_12.png", "sizeInBytes": 82587, "checksum": "f875b7030889264db498eae698b2cb43", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b0", "pageNumber": 12, "documentVersion": "2.0", "checksum": "6c9bab2a154f4223949efc77663962af", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_13.png", "sizeInBytes": 69494, "checksum": "6c9bab2a154f4223949efc77663962af", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b1", "pageNumber": 13, "documentVersion": "2.0", "checksum": "3fa89300afe33dd2757750d68fc057a5", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_14.png", "sizeInBytes": 77391, "checksum": "3fa89300afe33dd2757750d68fc057a5", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b2", "pageNumber": 14, "documentVersion": "2.0", "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_15.png", "sizeInBytes": 65042, "checksum": "d3e8bab0d1b72ff51efeffe195612d44", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b3", "pageNumber": 15, "documentVersion": "2.0", "checksum": "0f00302cb0bc797371797b0a264e5331", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_16.png", "sizeInBytes": 58321, "checksum": "0f00302cb0bc797371797b0a264e5331", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b4", "pageNumber": 16, "documentVersion": "2.0", "checksum": "f1efc6c977070e168bc1c29dc50167f8", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_17.png", "sizeInBytes": 45297, "checksum": "f1efc6c977070e168bc1c29dc50167f8", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b5", "pageNumber": 17, "documentVersion": "2.0", "checksum": "a43e69be7c859804202cb23eb26a5d42", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_18.png", "sizeInBytes": 48592, "checksum": "a43e69be7c859804202cb23eb26a5d42", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }, { "createdDtm": 1458034797000, "updatedDtm": 1458131628000, "createdBy": "mahesh.kumars@altisource.com", "updatedBy": "Mahesh.kumars@altisource.com", "status": "UPDATED", "id": "8a82815a537529e9015379a56c0305b6", "pageNumber": 18, "documentVersion": "2.0", "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "extendedMetadata": { "filename": "6072593c-7603-455f-bd80-1d422022b133_19.png", "sizeInBytes": 135171, "checksum": "d91ad75d5d2b9c2076bcb19b9f5c9f9b", "contentType": "image/png", "sourceId": null }, "internalMetadata": {} }] } };
            return RdvngRestSpiderService.all("search/documents").doPOST(searchRequest, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.deletePages = function(doc, pageIds) {
            return RdvngRestSpiderService.all("documents/" + doc.id + "/page/multiple/delete").doPOST(pageIds, null, {}, {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            });
        };

        this.splitDocument = function(docId, payload) {
            return RdvngRestSpiderService.one("documents/" + docId + "/split").doPOST(payload, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.mergeDocuments = function(docModel) {
            return RdvngRestSpiderService.one("documents/merge").doPOST(docModel, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.reorderPages = function(pages, docId) {
            var reorderPayload = { id: docId, pages: pages };
            return RdvngRestSpiderService.one("documents/" + docId + "/reorder").doPUT(reorderPayload, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.createAnnotation = function(model) {
            return RdvngRestSpiderService.one("annotations").doPOST(model, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.editAnnotation = function(annotationId, obj) {
            return RdvngRestSpiderService.one("annotations/" + annotationId).doPOST(obj, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.deleteAnnotation = function(annotationId) {
            return RdvngRestSpiderService.one("annotations/" + annotationId).doDELETE();
        };

        this.getAnnotation = function(annotationId) {
            return RdvngRestSpiderService.one("annotations/" + annotationId).doGET(null, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.getAllAnnotations = function(objectId) {
            return RdvngRestSpiderService.all("annotations/documentobjects/" + objectId).doGET();
        };

        this.addComment = function(annotationId, obj) {
            return RdvngRestSpiderService.one("annotations/" + annotationId + "/comments").doPOST(obj, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.replyComment = function(reply) {
            return RdvngRestSpiderService.one("annotations/" + reply.annotationId + "/comments/" + reply.parentId + "").doPOST({ comment: reply.comment }, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.editComment = function(commentId, obj) {
            return RdvngRestSpiderService.one("comments/" + commentId).doPOST(obj, null, {}, {
                'Content-Type': 'application/json'
            });
        };

        this.deleteComment = function(comment) {
            return RdvngRestSpiderService.one("comments/" + comment.id).doDELETE();
        };

        this.reorderBulkPages = function(docs) {
            return RdvngRestSpiderService.one("documents/bulk").doPUT(docs, null, {}, {
                'Content-Type': 'application/json'
            });
        };
    }
]);

uiv.controller('DemoController', ['$scope', '$window', '$state', 'ViewerSetting',
    'RdvngDocumentModelService', 'uiViewerDatasource', '$http', 'ViewerModel', '$q', 'ViewerDocumentStore', '$timeout', 'ViewerUtilitis',
    function($scope, $window, $state, ViewerSetting, RdvngDocumentModelService, uiViewerDatasource, $http, ViewerModel, $q, ViewerDcumentStore, $timeout, ViewerUtilitis) {
        var vm = this;
        vm.viewerSettings = new ViewerSetting({
            actions: {
                business: {
                    delete: true,
                    split: { userSelectedOrder: true },
                    reorder: true,
                    annotation: {
                        create: true,
                        read: true,
                    },
                },
                viewer: {
                    continousNavigation: false
                }
            }
        });

        var ViewerSetting = vm.viewerSettings;

        //Get document
        $timeout(function() {
            $(".docs").on("click", "input", function(event) {
                if (event.target.checked) {
                    showDoc(event.target.value);
                }
            });
        }, 1000);

        var searchRequest = { "queryInfo": { "query": { "queryMode": "BASIC", "queryString": "-STATUS:'DELETED' AND * AND _exists_:pageSet ", "scoring": "DISABLE_WITH_CACHE" }, "sort": [{ "fieldName": "createdDtm", "order": "desc" }], "offset": 0, "limit": 40, "resultFields": ["id", "businessKey", "extendedMetadata", "pageSet.PNG.id", "pageSet.PNG.updatedDtm", "createdDtm", "docTypes", "pageSet.PNG.extendedMetadata.sizeInBytes", "pageSet.PNG.extendedMetadata.resolution", "status", "updatedDtm"] }, "searchType": "QUERY_THEN_FETCH" };
        var constantResolution = {
            high : {width: 3000, height: 2250},
            low : {width: 1496, height: 2181},
            thumbnail : {width: 70, height: 100}
        };
        var showDoc = function showDoc(docId) {
            RdvngDocumentModelService.getDocumentById(docId).then(
                function(response) {
                    var data = response.data;
                    var pages = [];
                    for (var i = 0, len = data.pageSet.THUMBNAIL.length; i < len; i++) {
                        pages.push(new ViewerModel.Page({
                            id: data.pageSet.PNG[i].id,
                            pageNumber: data.pageSet.PNG[i].pageNumber,
                            docId: docId,
                            isValidPage: true,
                            updatedDtm: data.pageSet.PNG[i].updatedDtm,
                            resolution: data.pageSet.PNG[i].internalMetadata.resolution
                        }));
                    }

                    vm.viewerDatasource.addDocument(data.id, new ViewerModel.Document({
                        id: data.id,
                        name: data.docTypes[0].label,
                        pages: pages,
                        isSelected: false,
                        isFocused: false,
                        isValidDoc: true,
                        updatedDtm: data.updatedDtm
                    }));
                },
                function(error) {

                }
            );
        };

        vm.showDocFromKhoj = function showDocFromKhoj() {
            RdvngDocumentModelService.getDocuments(searchRequest).then(
                function(response) {
                    var allDocuments = response.data.plain().documents;
                    var viewerData = [];
                    _.each(allDocuments, function(obj) {
                        var docId = (obj.id) ? obj.id : obj.docId;
                        var docType = (obj.docTypeName) ? obj.docTypeName.label : obj.docTypes[0].label;
                        var pages = [];
                        if (obj && obj.pageSet) {
                            var allPages = (obj.pageSet.PNG) ? obj.pageSet.PNG : obj.pageSet;
                            for (var i = 0, len = allPages.length; i < len; i++) {
                                if (allPages[i].internalMetadata) {
                                    allPages[i].resolution = (allPages[i].internalMetadata.resolution) ? allPages[i].internalMetadata.resolution : constantResolution;
                                } else {
                                    allPages[i].resolution = constantResolution;
                                }
                                if (allPages[i].resolution.low.width <= 0 || allPages[i].resolution.low.height <= 0) {
                                    console.info("improper document", docId);
                                    return;
                                }
                                pages.push(new ViewerModel.Page({
                                    id: allPages[i].id,
                                    pageNumber: i + 1,
                                    docId: docId,
                                    isValidPage: true,
                                    updatedDtm: allPages[i].updatedDtm,
                                    resolution: allPages[i].resolution
                                }));
                                isValidDocSet = (obj.status === 'IN_PROGRESS') ? false : true;
                            }
                        } else {
                            pages.push(new ViewerModel.Page({
                                    id: rdvngUtils.uniqueId(),
                                    pageNumber: 1,
                                    docId: docId,
                                    isValidPage: false,
                                    resolution: constantResolution
                                }));
                            isValidDocSet = false;
                            // return; // break _.every loop;
                        }

                        viewerData.push(new ViewerModel.Document({
                            id: docId,
                            name: docType,
                            pages: pages,
                            isValidDoc: isValidDocSet,
                            isSelected: false,
                            isFocused: false,
                            updatedDtm: obj.updatedDtm,
                            status: obj.status
                        }));

                    });
                    vm.viewerDatasource.addMultipleDocuments(viewerData);
                },
                function(error) {

                }
            );
        };

        vm.showInvalidDocument = function() {
            vm.viewerDatasource.addMultipleDocuments(null, null, ViewerSetting.viewerStates.INVALID_DOCUMENT);
        };

        vm.onDocumentNotFound = function() {
            vm.viewerDatasource.clearImageViewer(true);
        };

        vm.getImage = function(id, type) {
            var deferred = $q.defer();

            if (type === ViewerSetting.displayType.PAGE) {
                RdvngDocumentModelService.getPageById(id).then(
                    function(response) {
                        var r = new FileReader();
                        r.readAsDataURL(response.data);
                        r.onload = function() {
                            deferred.resolve(new ViewerModel.Image({
                                id: id,
                                type: type,
                                data: r.result
                            }))
                        };
                        r.onerror = function() {
                            deferred.reject(new ViewerModel.Error({
                                code: ViewerSetting.errorCodes.PAGE_INCORRECT,
                                message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.PAGE_INCORRECT]
                            }))
                        };
                    },
                    function(error) {
                        deferred.reject(new ViewerModel.Error({
                            code: ViewerSetting.errorCodes.PAGE_NOT_FOUND,
                            message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.PAGE_NOT_FOUND]
                        }))
                    });
            } else {
                RdvngDocumentModelService.getThumbById(id).then(
                    function(response) {
                        var r = new FileReader();
                        r.readAsDataURL(response.data);
                        r.onload = function() {
                            deferred.resolve(ViewerModel.Page({
                                id: id,
                                data: r.result
                            }));
                        };

                        r.onerror = function() {
                            deferred.reject(new ViewerModel.Error({
                                code: ViewerSetting.errorCodes.THUMB_INCORRECT,
                                message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.THUMB_INCORRECT]
                            }))
                        };
                    },
                    function(error) {
                        deferred.reject(new ViewerModel.Error({
                            code: ViewerSetting.errorCodes.THUMB_NOT_FOUND,
                            message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.THUMB_NOT_FOUND]
                        }))
                    });
            }
            return deferred.promise;
        };

        vm.viewerDatasource = new uiViewerDatasource({
            getImageAPI: vm.getImage
        });


        vm.showDocument = function(docId) {
            showDoc(docId);
        };
        //========================================================================
        //Delete method
        vm.deletePages = function(docs) {

            var deferred = $q.defer();
            var promises = [];

            _.each(docs, function(obj) {
                var pageIds = _.pluck(obj.pages, 'id');
                promises.push(RdvngDocumentModelService.deletePages(obj, pageIds));
            });

            $q.all(promises).then(function(result) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.PAGE_DELETE,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.PAGE_DELETE],
                    data: _.pluck(result, 'data')
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.PAGE_DELETE,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.PAGE_DELETE]
                }));
            });

            return deferred.promise;
        };

        //split method
        vm.splitDocument = function(docs) {

            var deferred = $q.defer();
            var promises = [];

            _.each(docs, function(doc) {
                var newDocuments = [];
                var payload = { id: doc.id, newDocuments: [] };
                for (var index = 0, len = doc.pages.length; index < len; index++) {
                    newDocuments.push({
                        id: doc.pages[index].id,
                        sequenceNumber: index + 1
                    });
                }
                payload.newDocuments.push(newDocuments);
                promises.push(RdvngDocumentModelService.splitDocument(doc.id, payload));
            });

            $q.all(promises).then(function(result) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.SPLIT_DOCUMENT,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.SPLIT_DOCUMENT],
                    data: _.pluck(result, 'data')
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.SPLIT_DOCUMENT,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.SPLIT_DOCUMENT]
                }));
            });
            return deferred.promise;
        };

        //merge multiple documents
        vm.mergeDocuments = function(docIds) {
            var docModel = {
                documentIds: docIds
            };
            RdvngDocumentModelService.mergeDocuments(docModel).then(function(response) {
                showDoc(response.data.documentId);
            }, function(error) {
                console.log(error);
            });
        };

        vm.reorderPages = function(pages, docId) {

            var deferred = $q.defer();

            RdvngDocumentModelService.reorderPages(pages, docId).then(function(response) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.REORDER_PAGES,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.REORDER_PAGES],
                    data: response.data.plain()
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.REORDER_PAGES,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.REORDER_PAGES]
                }));
            });
            return deferred.promise;
        };

        //cut copy paste method
        //reorder method
        vm.onUpdateDocuments = function(viewerDocumentObjects) {
            console.log(viewerDocumentObjects);
        };

        //download selective pages
        vm.downloadSelectivePages = function(docs) {

        };

        vm.downloadSourceDocument = function() {
            console.log("downloadSourceDocument");
        };
        //Events
        vm.onPageChange = function(currentPage, oldPage, currentDocument, oldDocument) {

        };

        vm.onDocumentChange = function(currentDocumentId, oldDocumentId) {};

        vm.onViewChange = function(selectedView) {
            console.log(selectedView)
        };

        vm.onZoomChange = function(currentZoom, oldZoom, pageId) {

        };

        vm.onRotationChange = function(currentRotation, oldRotation, pageId) {

        };

        vm.onAlignmentChange = function(currentAlign, oldAlign, pageId) {
            // align values:
            // 0 : default
            // 1 : fitToWidth
            // 2 : bestFit

        };

        var getComments = function(obj, annotationId, parentId) {
            for (var k in obj) {
                if (typeof obj[k] == "object" && obj[k]) {
                    obj[k] = new ViewerModel.Comment({
                        id: obj[k].id,
                        annotationId: annotationId,
                        comment: obj[k].comment || null,
                        parentId: parentId,
                        createdDtm: obj[k].createdDtm,
                        createdBy: obj[k].createdBy,
                        comments: obj[k].comments || []
                    });
                    getComments(obj[k].comments, annotationId, obj[k].id);
                } else {
                    //do something....
                }
            }
        };

        vm.createAnnotation = function(annotation) {
            var deferred = $q.defer();

            var annotationRequestObj = {
                documentObjectId: annotation.documentObjectId,
                annotationType: annotation.annotationType,
                content: annotation.content,
                comment: annotation.comments[0].comment || 'Created with no comments',
                imageWidth: annotation.imageWidth,
                imageHeight: annotation.imageHeight
            };

            RdvngDocumentModelService.createAnnotation(annotationRequestObj).then(function(response) {
                RdvngDocumentModelService.getAnnotation(response.data.id).then(function(responseDetails) {
                    var annotation = responseDetails.data.plain();
                    var annotationObj = new ViewerModel.Annotation({
                        id: annotation.id,
                        documentObjectId: annotation.documentObjectId,
                        annotationType: ViewerSetting.ANNOTATION_KEYS[annotation.type],
                        content: annotation.content,
                        createdBy: annotation.createdBy,
                        createdDtm: annotation.createdDtm,
                        comments: annotation.comments,
                        imageWidth: annotation.imageWidth,
                        imageHeight: annotation.imageHeight
                    });
                    getComments(annotationObj.comments, annotationObj.id, "");
                    deferred.resolve(new ViewerModel.Success({
                        code: ViewerSetting.successCodes.SAVE_ANNOTATION,
                        message: ViewerSetting.successMessages[ViewerSetting.successCodes.SAVE_ANNOTATION],
                        data: annotationObj
                    }));
                }, function(error) {
                    deferred.reject(new ViewerModel.Error({
                        code: ViewerSetting.errorCodes.SAVE_ANNOTATION,
                        message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.SAVE_ANNOTATION]
                    }));
                });

            }, function(error) {
                deferred.reject();
            });
            return deferred.promise;
        };

        vm.getAllAnnotations = function(documentObjectId) {
            var deferred = $q.defer();

            RdvngDocumentModelService.getAllAnnotations(documentObjectId).then(function(response) {
                var annotationArr = response.data.plain().annotations;
                var annotationObjArr = [];
                for (var i = 0, len = annotationArr.length; i < len; i++) {
                    var annotationObj = new ViewerModel.Annotation({
                        id: annotationArr[i].id,
                        documentObjectId: response.data.documentObjectId,
                        annotationType: ViewerSetting.ANNOTATION_KEYS[annotationArr[i].type],
                        content: annotationArr[i].content,
                        createdBy: annotationArr[i].createdBy,
                        createdDtm: annotationArr[i].createdDtm,
                        comments: annotationArr[i].comments,
                        imageWidth: annotationArr[i].imageWidth,
                        imageHeight: annotationArr[i].imageHeight
                    });
                    getComments(annotationObj.comments, annotationObj.id, "");
                    annotationObjArr.push(annotationObj);
                }
                deferred.resolve(annotationObjArr);
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.GET_ALL_ANNOTATIONS,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.GET_ALL_ANNOTATIONS]
                }));
            });

            return deferred.promise;
        };

        vm.deleteAnnotation = function(annotationId) {
            var deferred = $q.defer();

            RdvngDocumentModelService.deleteAnnotation(annotationId).then(function(response) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.DELETE_ANNOTATION,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.DELETE_ANNOTATION],
                    data: response
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.DELETE_ANNOTATION,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.DELETE_ANNOTATION]
                }));
            });

            return deferred.promise;
        };

        vm.replyComment = function(reply) {
            var deferred = $q.defer();
            RdvngDocumentModelService.replyComment(reply).then(function(response) {
                reply.id = response.data.id;
                reply.createdDtm = response.data.createdDtm;
                reply.createdBy = response.data.createdBy;
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.REPLY_COMMENT,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.REPLY_COMMENT],
                    data: reply
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.REPLY_COMMENT,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.REPLY_COMMENT]
                }));
            });
            return deferred.promise;
        };

        vm.deleteComment = function(comment) {
            var deferred = $q.defer();
            RdvngDocumentModelService.deleteComment(comment).then(function(response) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.DELETE_COMMENT,
                    message: ViewerSetting.successMessages[ViewerSetting.successCodes.DELETE_COMMENT],
                    data: comment
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.DELETE_COMMENT,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.DELETE_COMMENT]
                }));
            });
            return deferred.promise;
        };

        vm.reorderBulkPages = function(docs, crossDocType) {
            var payload = getDocPayload(docs);
            var deferred = $q.defer();
            RdvngDocumentModelService.reorderBulkPages(payload).then(function(response) {
                deferred.resolve(new ViewerModel.Success({
                    code: ViewerSetting.successCodes.REORDER_PAGES,
                    message: (crossDocType === 'reorder') ? ViewerSetting.successMessages[ViewerSetting.successCodes.REORDER_PAGES] :  ViewerSetting.successMessages[ViewerSetting.successCodes.CUT_PASTE],
                    data: response.data.plain()
                }));
            }, function(error) {
                deferred.reject(new ViewerModel.Error({
                    code: ViewerSetting.errorCodes.REORDER_PAGES,
                    message: ViewerSetting.errorMessages[ViewerSetting.errorCodes.REORDER_PAGES]
                }));
            });
            return deferred.promise;
        };

        var getDocPayload = function(docs) {
            var docArray = [];
            for (var i = 0; i < docs.length; i++) {
                var pages = [];
                var dPages = docs[i].pages;
                for (var j = 0; j < dPages.length; j++) {
                    var page = {
                        id: dPages[j].id,
                        updatedDtm: dPages[j].updatedDtm,
                        sequenceNumber: dPages[j].pageNumber
                    };
                    pages.push(page);
                }
                var doc = {
                    id: docs[i].id,
                    updatedDtm: docs[i].updatedDtm,
                    pages: pages
                };
                docArray.push(doc);
            }
            return { documents: docArray };
        };
    }
]);
