This directory should contain OpenVPN configuration files
each having an extension of .ovpn

When OpenVPN is started as a service, a separate OpenVPN
process will be instantiated for each configuration file.
